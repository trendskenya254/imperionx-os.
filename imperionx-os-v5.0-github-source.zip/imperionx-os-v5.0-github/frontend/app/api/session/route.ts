import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export const runtime = 'nodejs';
const API_HOST = process.env.IMPERIONX_API_INTERNAL || 'http://localhost:8000';
const API = API_HOST.includes('://') ? API_HOST : `http://${API_HOST}`;
const cookieBase = { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict' as const, path: '/api' };
export async function GET() {
  const jar = await cookies();
  let access = jar.get('ix_access')?.value;
  const refresh = jar.get('ix_refresh')?.value;
  const organization_id = jar.get('ix_org')?.value;
  const role = jar.get('ix_role')?.value;
  if (!access || !organization_id || !role) return NextResponse.json({ authenticated: false }, { status: 200, headers: { 'Cache-Control': 'no-store' } });
  let upstream = await fetch(`${API}/v1/auth/me`, { headers: { Authorization: `Bearer ${access}` }, cache: 'no-store' });
  let rotated: { access_token: string; refresh_token: string; expires_in: number; organization_id: string; role: string; user_id: string } | null = null;
  if (upstream.status === 401 && refresh) {
    const renewed = await fetch(`${API}/v1/auth/refresh`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: refresh }), cache: 'no-store' });
    if (renewed.ok) {
      rotated = await renewed.json(); access = rotated!.access_token;
      upstream = await fetch(`${API}/v1/auth/me`, { headers: { Authorization: `Bearer ${access}` }, cache: 'no-store' });
    }
  }
  if (!upstream.ok) {
    const response = NextResponse.json({ authenticated: false }, { status: 200 });
    if (upstream.status === 401) for (const name of ['ix_access', 'ix_refresh', 'ix_org', 'ix_role']) response.cookies.set(name, '', { ...cookieBase, maxAge: 0 });
    return response;
  }
  const user = await upstream.json();
  const membersResponse = await fetch(`${API}/v1/organizations/members`, { headers: { Authorization: `Bearer ${access}`, 'X-Organization-ID': organization_id }, cache: 'no-store' });
  let currentRole = role;
  if (membersResponse.ok) {
    const members = await membersResponse.json();
    currentRole = members.find((member: { user_id: string; role: string }) => member.user_id === user.id)?.role || role;
  }
  const response = NextResponse.json({ authenticated: true, user_id: user.id, organization_id, role: currentRole, mfa_enabled: Boolean(user.mfa_enabled) }, { headers: { 'Cache-Control': 'no-store' } });
  if (rotated) {
    response.cookies.set('ix_access', rotated.access_token, { ...cookieBase, maxAge: rotated.expires_in });
    response.cookies.set('ix_refresh', rotated.refresh_token, { ...cookieBase, maxAge: 60 * 60 * 24 * 30 });
  }
  return response;
}
