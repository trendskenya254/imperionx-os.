import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export const runtime = 'nodejs';
const API_HOST = process.env.IMPERIONX_API_INTERNAL || 'http://localhost:8000';
const API = API_HOST.includes('://') ? API_HOST : `http://${API_HOST}`;
const ACCESS = 'ix_access';
const REFRESH = 'ix_refresh';
const ORG = 'ix_org';
const ROLE = 'ix_role';
const secure = process.env.NODE_ENV === 'production';
const cookieBase = { httpOnly: true, secure, sameSite: 'strict' as const, path: '/api' };

type TokenPayload = { access_token: string; refresh_token: string; expires_in: number; organization_id: string; role: string; user_id: string };

function setSessionCookies(response: NextResponse, data: TokenPayload) {
  response.cookies.set(ACCESS, data.access_token, { ...cookieBase, maxAge: data.expires_in });
  response.cookies.set(REFRESH, data.refresh_token, { ...cookieBase, maxAge: 60 * 60 * 24 * 30 });
  response.cookies.set(ORG, data.organization_id, { ...cookieBase, maxAge: 60 * 60 * 24 * 30 });
  response.cookies.set(ROLE, data.role, { ...cookieBase, maxAge: 60 * 60 * 24 * 30 });
}
function setRotatedCookies(response: NextResponse, data: TokenPayload) {
  response.cookies.set(ACCESS, data.access_token, { ...cookieBase, maxAge: data.expires_in });
  response.cookies.set(REFRESH, data.refresh_token, { ...cookieBase, maxAge: 60 * 60 * 24 * 30 });
}
function clearSessionCookies(response: NextResponse) {
  for (const name of [ACCESS, REFRESH, ORG, ROLE]) response.cookies.set(name, '', { ...cookieBase, maxAge: 0 });
}
function jsonError(status: number, detail: string) { return NextResponse.json({ detail }, { status, headers: { 'Cache-Control': 'no-store' } }); }
function isMutation(method: string) { return !['GET', 'HEAD', 'OPTIONS'].includes(method.toUpperCase()); }
function originAllowed(request: NextRequest) {
  const origin = request.headers.get('origin');
  if (!origin || origin !== request.nextUrl.origin) return false;
  const fetchSite = request.headers.get('sec-fetch-site');
  return fetchSite !== 'cross-site';
}
async function backend(path: string, method: string, body: string | undefined, access?: string, org?: string, extraHeaders: Record<string, string> = {}) {
  return fetch(`${API}/${path}`, {
    method,
    headers: {
      ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      ...(access ? { Authorization: `Bearer ${access}` } : {}),
      ...(org ? { 'X-Organization-ID': org } : {}),
      ...extraHeaders,
    },
    body,
    cache: 'no-store',
    redirect: 'manual',
  });
}
async function rotate(refresh: string) {
  const response = await backend('v1/auth/refresh', 'POST', JSON.stringify({ refresh_token: refresh }));
  if (!response.ok) return null;
  return await response.json() as TokenPayload;
}

async function handle(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  if (isMutation(request.method) && !originAllowed(request)) return jsonError(403, 'Cross-origin request rejected');
  const { path: parts } = await context.params;
  const path = parts.join('/');
  const jar = await cookies();
  const incomingBody = ['GET', 'HEAD'].includes(request.method) ? undefined : await request.text();

  if (path === 'v1/auth/login' || path === 'v1/auth/mfa/verify-login') {
    const upstream = await backend(path, request.method, incomingBody);
    const payload = await upstream.json().catch(() => ({}));
    if (!upstream.ok || payload.mfa_required) return NextResponse.json(payload, { status: upstream.status, headers: { 'Cache-Control': 'no-store' } });
    const response = NextResponse.json({ user_id: payload.user_id, organization_id: payload.organization_id, role: payload.role, mfa_enabled: path === 'v1/auth/mfa/verify-login' }, { status: upstream.status, headers: { 'Cache-Control': 'no-store' } });
    setSessionCookies(response, payload as TokenPayload);
    return response;
  }

  if (path === 'v1/auth/refresh') {
    const refresh = jar.get(REFRESH)?.value;
    const rotated = refresh ? await rotate(refresh) : null;
    if (!rotated) {
      const response = jsonError(401, 'Session refresh failed. Please sign in again.');
      clearSessionCookies(response);
      return response;
    }
    const response = NextResponse.json({ user_id: rotated.user_id, organization_id: jar.get(ORG)?.value || rotated.organization_id, role: jar.get(ROLE)?.value || rotated.role });
    setRotatedCookies(response, rotated);
    return response;
  }

  if (path === 'v1/auth/logout') {
    const access = jar.get(ACCESS)?.value;
    let upstreamStatus = 204;
    if (access) {
      const upstream = await backend(path, 'POST', incomingBody, access);
      upstreamStatus = upstream.status;
    }
    const response = new NextResponse(null, { status: upstreamStatus === 401 ? 204 : upstreamStatus });
    clearSessionCookies(response);
    return response;
  }

  let access = jar.get(ACCESS)?.value;
  const refresh = jar.get(REFRESH)?.value;
  const org = jar.get(ORG)?.value;
  let rotated: TokenPayload | null = null;
  if (!access && refresh) {
    rotated = await rotate(refresh);
    access = rotated?.access_token;
  }
  const idempotencyKey = request.headers.get('idempotency-key');
  const forwardedHeaders: Record<string, string> = idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {};
  let upstream = await backend(path, request.method, incomingBody, access, org, forwardedHeaders);
  if (upstream.status === 401 && refresh && !rotated) {
    rotated = await rotate(refresh);
    if (rotated) {
      access = rotated.access_token;
      upstream = await backend(path, request.method, incomingBody, access, org, forwardedHeaders);
    }
  }
  const content = upstream.status === 204 ? null : await upstream.arrayBuffer();
  const response = new NextResponse(content, { status: upstream.status, headers: {
    ...(upstream.headers.get('content-type') ? { 'Content-Type': upstream.headers.get('content-type')! } : {}),
    'Cache-Control': 'no-store',
  } });
  if (rotated) setRotatedCookies(response, rotated);
  if (upstream.status === 401 && refresh && !rotated) clearSessionCookies(response);
  return response;
}

export const GET = handle;
export const POST = handle;
export const PATCH = handle;
export const PUT = handle;
export const DELETE = handle;
