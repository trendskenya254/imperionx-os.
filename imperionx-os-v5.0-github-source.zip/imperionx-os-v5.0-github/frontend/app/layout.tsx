import type { Metadata } from 'next';
import './styles.css';
export const metadata: Metadata = {
  title: 'IMPERIONX OS | Business Command',
  description: 'Customer operations, team workload and business performance workspace'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
