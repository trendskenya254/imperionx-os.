"""Wait until the database schema is at the Alembic head before starting a worker."""
from __future__ import annotations
import sys
import time
from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import inspect, text
from sqlalchemy.exc import SQLAlchemyError
from app.db import engine


def main() -> int:
    backend_root = Path(__file__).resolve().parents[1]
    config = Config(str(backend_root / "alembic.ini"))
    config.set_main_option("script_location", str(backend_root / "migrations"))
    expected = set(ScriptDirectory.from_config(config).get_heads())
    if not expected:
        print("No Alembic migration heads found", file=sys.stderr)
        return 2
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        try:
            inspector = inspect(engine)
            if inspector.has_table("alembic_version"):
                with engine.connect() as connection:
                    current = set(connection.execute(text("SELECT version_num FROM alembic_version")).scalars())
                if current == expected:
                    print("Database schema is at the current migration head")
                    return 0
        except SQLAlchemyError:
            pass
        time.sleep(5)
    print("Timed out waiting for database migrations to reach head", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
