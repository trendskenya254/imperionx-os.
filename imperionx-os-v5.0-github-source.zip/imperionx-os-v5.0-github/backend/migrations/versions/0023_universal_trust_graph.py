"""Add explicit opt-in for second-degree network discovery."""
from alembic import op
import sqlalchemy as sa

revision = "0023_universal_trust_graph"
down_revision = "0022_reputation_integrity"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("business_public_profiles", sa.Column(
        "network_discoverable", sa.Boolean(), nullable=False, server_default=sa.false()
    ))
    op.create_index("ix_business_public_profiles_network_discoverable",
                    "business_public_profiles", ["network_discoverable"])

def downgrade():
    op.drop_index("ix_business_public_profiles_network_discoverable", table_name="business_public_profiles")
    op.drop_column("business_public_profiles", "network_discoverable")
