"""Add inquiry assignment for business operations."""
from alembic import op
import sqlalchemy as sa

revision = "0007_inquiry_operations"
down_revision = "0006_org_invitations"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("inquiries") as batch:
        batch.add_column(sa.Column("assigned_to_user_id", sa.String(length=36), nullable=True))
        batch.create_foreign_key("fk_inquiries_assigned_to_user_id_users", "users", ["assigned_to_user_id"], ["id"])
        batch.create_index("ix_inquiries_assigned_to_user_id", ["assigned_to_user_id"])

def downgrade():
    with op.batch_alter_table("inquiries") as batch:
        batch.drop_index("ix_inquiries_assigned_to_user_id")
        batch.drop_constraint("fk_inquiries_assigned_to_user_id_users", type_="foreignkey")
        batch.drop_column("assigned_to_user_id")
