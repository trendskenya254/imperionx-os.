"""Add dispatch lifecycle metadata to webhook outbox."""
from alembic import op
import sqlalchemy as sa

revision = "0017_webhook_event_runtime"
down_revision = "0016_integration_platform"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("webhook_deliveries", sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("webhook_deliveries", sa.Column("delivered_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("webhook_deliveries", sa.Column("dead_lettered_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("webhook_deliveries", sa.Column("response_status", sa.Integer(), nullable=True))
    op.create_index("ix_webhook_deliveries_status_next_attempt", "webhook_deliveries", ["status", "next_attempt_at"])


def downgrade():
    op.drop_index("ix_webhook_deliveries_status_next_attempt", table_name="webhook_deliveries")
    op.drop_column("webhook_deliveries", "response_status")
    op.drop_column("webhook_deliveries", "dead_lettered_at")
    op.drop_column("webhook_deliveries", "delivered_at")
    op.drop_column("webhook_deliveries", "next_attempt_at")
