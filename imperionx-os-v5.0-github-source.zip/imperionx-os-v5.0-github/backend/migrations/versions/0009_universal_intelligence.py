"""Add product/service labels for universal business intelligence."""
from alembic import op
import sqlalchemy as sa

revision = "0009_universal_intelligence"
down_revision = "0008_sales_performance"
branch_labels = None
depends_on = None

def upgrade():
    # SQLite INTEGER is already a signed 64-bit storage class; PostgreSQL needs BIGINT
    # because the API deliberately permits amounts above the 32-bit INTEGER ceiling.
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.alter_column("sale_records", "amount_minor", existing_type=sa.Integer(), type_=sa.BigInteger(), existing_nullable=False)
    op.add_column("sale_records", sa.Column("product_or_service", sa.String(length=200), nullable=True))
    op.create_index("ix_sale_records_product_or_service", "sale_records", ["product_or_service"])

def downgrade():
    op.drop_index("ix_sale_records_product_or_service", table_name="sale_records")
    op.drop_column("sale_records", "product_or_service")
