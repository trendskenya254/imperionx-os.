"""Add privacy-preserving public lead submission throttling."""
from alembic import op
import sqlalchemy as sa

revision = "0013_public_lead_limits"
down_revision = "0012_business_network"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "public_lead_rate_limits",
        sa.Column("key_hash", sa.String(length=64), primary_key=True),
        sa.Column("window_started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="1"),
    )

def downgrade():
    op.drop_table("public_lead_rate_limits")
