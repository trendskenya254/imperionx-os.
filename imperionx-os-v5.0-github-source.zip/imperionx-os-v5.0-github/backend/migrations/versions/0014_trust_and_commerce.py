"""Add evidence-reviewed business verification and quote-led commerce."""
from alembic import op
import sqlalchemy as sa

revision = "0014_trust_commerce"
down_revision = "0013_public_lead_limits"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "business_verifications",
        sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), primary_key=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="not_submitted"),
        sa.Column("evidence_type", sa.String(80)), sa.Column("evidence_reference", sa.String(500)),
        sa.Column("applicant_note", sa.String(1000)),
        sa.Column("reviewer_user_id", sa.String(36), sa.ForeignKey("users.id")),
        sa.Column("reviewer_note", sa.String(1000)),
        sa.Column("submitted_at", sa.DateTime(timezone=True)), sa.Column("reviewed_at", sa.DateTime(timezone=True)),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "business_purchase_requests",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("connection_id", sa.String(36), sa.ForeignKey("business_connections.id"), nullable=False),
        sa.Column("buyer_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("supplier_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("title", sa.String(200), nullable=False), sa.Column("description", sa.Text(), nullable=False),
        sa.Column("quantity", sa.String(100)), sa.Column("status", sa.String(20), nullable=False, server_default="open"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_business_purchase_requests_connection_id", "business_purchase_requests", ["connection_id"])
    op.create_index("ix_business_purchase_requests_buyer_organization_id", "business_purchase_requests", ["buyer_organization_id"])
    op.create_index("ix_business_purchase_requests_supplier_organization_id", "business_purchase_requests", ["supplier_organization_id"])
    op.create_table(
        "business_quotes",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("purchase_request_id", sa.String(36), sa.ForeignKey("business_purchase_requests.id"), nullable=False),
        sa.Column("supplier_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("amount_minor", sa.BigInteger(), nullable=False), sa.Column("currency", sa.String(3), nullable=False),
        sa.Column("terms", sa.String(2000)), sa.Column("validity_days", sa.Integer(), nullable=False, server_default="14"),
        sa.Column("status", sa.String(20), nullable=False, server_default="submitted"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_business_quotes_purchase_request_id", "business_quotes", ["purchase_request_id"])
    op.create_index("ix_business_quotes_supplier_organization_id", "business_quotes", ["supplier_organization_id"])
    op.create_table(
        "business_transactions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("purchase_request_id", sa.String(36), sa.ForeignKey("business_purchase_requests.id"), nullable=False),
        sa.Column("quote_id", sa.String(36), sa.ForeignKey("business_quotes.id"), nullable=False, unique=True),
        sa.Column("buyer_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("supplier_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("amount_minor", sa.BigInteger(), nullable=False), sa.Column("currency", sa.String(3), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="accepted"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_business_transactions_purchase_request_id", "business_transactions", ["purchase_request_id"])
    op.create_index("ix_business_transactions_buyer_organization_id", "business_transactions", ["buyer_organization_id"])
    op.create_index("ix_business_transactions_supplier_organization_id", "business_transactions", ["supplier_organization_id"])

def downgrade():
    op.drop_index("ix_business_transactions_supplier_organization_id", table_name="business_transactions")
    op.drop_index("ix_business_transactions_buyer_organization_id", table_name="business_transactions")
    op.drop_index("ix_business_transactions_purchase_request_id", table_name="business_transactions")
    op.drop_table("business_transactions")
    op.drop_index("ix_business_quotes_supplier_organization_id", table_name="business_quotes")
    op.drop_index("ix_business_quotes_purchase_request_id", table_name="business_quotes")
    op.drop_table("business_quotes")
    op.drop_index("ix_business_purchase_requests_supplier_organization_id", table_name="business_purchase_requests")
    op.drop_index("ix_business_purchase_requests_buyer_organization_id", table_name="business_purchase_requests")
    op.drop_index("ix_business_purchase_requests_connection_id", table_name="business_purchase_requests")
    op.drop_table("business_purchase_requests")
    op.drop_table("business_verifications")
