"""Add public offers and seeks for explainable business matching."""
from alembic import op
import sqlalchemy as sa

revision = "0024_business_discovery_matching"
down_revision = "0023_universal_trust_graph"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("business_public_profiles", sa.Column("offers", sa.JSON(), nullable=False, server_default="[]"))
    op.add_column("business_public_profiles", sa.Column("seeks", sa.JSON(), nullable=False, server_default="[]"))
    op.create_index("ix_business_public_profiles_published_org", "business_public_profiles", ["is_published", "organization_id"])


def downgrade():
    op.drop_index("ix_business_public_profiles_published_org", table_name="business_public_profiles")
    op.drop_column("business_public_profiles", "seeks")
    op.drop_column("business_public_profiles", "offers")
