"""Add safe worker claim metadata for webhook delivery."""
from alembic import op
import sqlalchemy as sa

revision = "0018_webhook_delivery_engine"
down_revision = "0017_webhook_event_runtime"
branch_labels = None
depends_on = None

def upgrade():
    op.create_index("ix_webhook_deliveries_status_created", "webhook_deliveries", ["status", "created_at"])

def downgrade():
    op.drop_index("ix_webhook_deliveries_status_created", table_name="webhook_deliveries")
