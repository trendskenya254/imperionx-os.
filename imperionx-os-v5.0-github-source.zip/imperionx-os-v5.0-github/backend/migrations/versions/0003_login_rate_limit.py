"""Persist failed login attempts for per-account and per-IP throttling."""
from alembic import op
import sqlalchemy as sa

revision = "0003_login_rate_limit"
down_revision = "0002_refresh_rotation"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "login_attempts",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("subject_key", sa.String(length=64), nullable=False),
        sa.Column("attempted_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_login_attempts_subject_key", "login_attempts", ["subject_key"])
    op.create_index("ix_login_attempts_attempted_at", "login_attempts", ["attempted_at"])

def downgrade():
    op.drop_index("ix_login_attempts_attempted_at", table_name="login_attempts")
    op.drop_index("ix_login_attempts_subject_key", table_name="login_attempts")
    op.drop_table("login_attempts")
