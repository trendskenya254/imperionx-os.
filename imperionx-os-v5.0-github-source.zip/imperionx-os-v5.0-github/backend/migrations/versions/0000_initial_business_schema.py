"""Initial IMPERIONX business workspace schema."""
from alembic import op
import sqlalchemy as sa
revision = "0000_initial_business_schema"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("organizations", sa.Column("id", sa.String(36), primary_key=True), sa.Column("name", sa.String(200), nullable=False), sa.Column("industry", sa.String(120)), sa.Column("country_code", sa.String(2)), sa.Column("created_at", sa.DateTime(timezone=True)))
    op.create_table("workflows", sa.Column("id", sa.String(36), primary_key=True), sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False), sa.Column("name", sa.String(200), nullable=False), sa.Column("description", sa.Text()), sa.Column("trigger_type", sa.String(50)), sa.Column("action_type", sa.String(80)), sa.Column("config", sa.JSON()), sa.Column("created_at", sa.DateTime(timezone=True)))
    op.create_index("ix_workflows_organization_id", "workflows", ["organization_id"])
    op.create_table("inquiries", sa.Column("id", sa.String(36), primary_key=True), sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False), sa.Column("source", sa.String(40)), sa.Column("customer_name", sa.String(200)), sa.Column("customer_contact", sa.String(320)), sa.Column("subject", sa.String(300)), sa.Column("message", sa.Text(), nullable=False), sa.Column("status", sa.String(40)), sa.Column("idempotency_key", sa.String(128)), sa.Column("created_at", sa.DateTime(timezone=True)), sa.Column("updated_at", sa.DateTime(timezone=True)), sa.UniqueConstraint("organization_id", "idempotency_key", name="uq_inquiry_org_idempotency"))
    op.create_index("ix_inquiries_organization_id", "inquiries", ["organization_id"])
    op.create_table("workflow_runs", sa.Column("id", sa.String(36), primary_key=True), sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False), sa.Column("workflow_id", sa.String(36), sa.ForeignKey("workflows.id"), nullable=False), sa.Column("inquiry_id", sa.String(36), sa.ForeignKey("inquiries.id")), sa.Column("status", sa.String(40)), sa.Column("input_data", sa.JSON()), sa.Column("proposed_action", sa.JSON()), sa.Column("decision_note", sa.Text()), sa.Column("created_at", sa.DateTime(timezone=True)), sa.Column("updated_at", sa.DateTime(timezone=True)))
    op.create_index("ix_workflow_runs_organization_id", "workflow_runs", ["organization_id"])
    op.create_index("ix_workflow_runs_workflow_id", "workflow_runs", ["workflow_id"])
    op.create_index("ix_workflow_runs_inquiry_id", "workflow_runs", ["inquiry_id"])

def downgrade():
    op.drop_table("workflow_runs"); op.drop_table("inquiries"); op.drop_table("workflows"); op.drop_table("organizations")
