"""Add tenant-scoped pilot enrollment and feedback."""
from alembic import op
import sqlalchemy as sa

revision = "0010_pilot_management"
down_revision = "0009_universal_intelligence"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "pilot_enrollments",
        sa.Column("organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), primary_key=True),
        sa.Column("cohort", sa.String(length=80), nullable=False, server_default="founding-pilot"),
        sa.Column("status", sa.String(length=30), nullable=False, server_default="interested"),
        sa.Column("primary_goal", sa.String(length=240), nullable=True),
        sa.Column("baseline_minutes_per_day", sa.Integer(), nullable=True),
        sa.Column("target_minutes_saved_per_day", sa.Integer(), nullable=True),
        sa.Column("activated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "pilot_feedback",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("submitted_by_user_id", sa.String(length=36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("category", sa.String(length=30), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("severity", sa.String(length=20), nullable=False, server_default="normal"),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="open"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_pilot_feedback_organization_id", "pilot_feedback", ["organization_id"])
    op.create_index("ix_pilot_feedback_submitted_by_user_id", "pilot_feedback", ["submitted_by_user_id"])

def downgrade():
    op.drop_index("ix_pilot_feedback_submitted_by_user_id", table_name="pilot_feedback")
    op.drop_index("ix_pilot_feedback_organization_id", table_name="pilot_feedback")
    op.drop_table("pilot_feedback")
    op.drop_table("pilot_enrollments")
