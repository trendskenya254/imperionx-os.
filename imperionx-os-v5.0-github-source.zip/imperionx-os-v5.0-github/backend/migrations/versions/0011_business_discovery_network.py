"""Add opt-in public business discovery, leads and connection requests."""
from alembic import op
import sqlalchemy as sa

revision = "0011_business_discovery"
down_revision = "0010_pilot_management"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "business_public_profiles",
        sa.Column("organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), primary_key=True),
        sa.Column("slug", sa.String(length=100), nullable=False),
        sa.Column("tagline", sa.String(length=180)),
        sa.Column("description", sa.Text()),
        sa.Column("website_url", sa.String(length=500)),
        sa.Column("city", sa.String(length=120)),
        sa.Column("public_email", sa.String(length=320)),
        sa.Column("is_published", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("slug", name="uq_business_public_profiles_slug"),
    )
    op.create_index("ix_business_public_profiles_slug", "business_public_profiles", ["slug"], unique=True)
    op.create_table(
        "business_connections",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("requester_organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("target_organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("message", sa.String(length=1000)),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="pending"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("requester_organization_id", "target_organization_id", name="uq_business_connection_pair"),
    )
    op.create_index("ix_business_connections_requester_organization_id", "business_connections", ["requester_organization_id"])
    op.create_index("ix_business_connections_target_organization_id", "business_connections", ["target_organization_id"])
    op.create_table(
        "public_business_leads",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("contact_name", sa.String(length=160), nullable=False),
        sa.Column("contact_email", sa.String(length=320), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("consent_to_contact", sa.Boolean(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="new"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_public_business_leads_organization_id", "public_business_leads", ["organization_id"])

def downgrade():
    op.drop_index("ix_public_business_leads_organization_id", table_name="public_business_leads")
    op.drop_table("public_business_leads")
    op.drop_index("ix_business_connections_target_organization_id", table_name="business_connections")
    op.drop_index("ix_business_connections_requester_organization_id", table_name="business_connections")
    op.drop_table("business_connections")
    op.drop_index("ix_business_public_profiles_slug", table_name="business_public_profiles")
    op.drop_table("business_public_profiles")
