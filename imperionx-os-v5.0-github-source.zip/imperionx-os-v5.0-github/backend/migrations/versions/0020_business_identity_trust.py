"""Add evidence provenance and revocable business trust credentials."""
from alembic import op
import sqlalchemy as sa

revision = "0020_business_identity_trust"
down_revision = "0019_webhook_observability"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "business_verification_evidence",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("submitted_by_user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("evidence_type", sa.String(80), nullable=False),
        sa.Column("evidence_reference", sa.String(500), nullable=False),
        sa.Column("issuer_name", sa.String(200), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("access_scope", sa.String(20), nullable=False, server_default="review_only"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_business_verification_evidence_organization_id", "business_verification_evidence", ["organization_id"])
    op.create_table(
        "business_trust_credentials",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("credential_type", sa.String(80), nullable=False),
        sa.Column("issuer", sa.String(160), nullable=False),
        sa.Column("claims", sa.JSON(), nullable=False),
        sa.Column("payload_digest", sa.String(64), nullable=False),
        sa.Column("signature", sa.String(64), nullable=False),
        sa.Column("issued_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("revoked_by_user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("revocation_reason", sa.String(500), nullable=True),
    )
    op.create_index("ix_business_trust_credentials_organization_id", "business_trust_credentials", ["organization_id"])

def downgrade():
    op.drop_index("ix_business_trust_credentials_organization_id", table_name="business_trust_credentials")
    op.drop_table("business_trust_credentials")
    op.drop_index("ix_business_verification_evidence_organization_id", table_name="business_verification_evidence")
    op.drop_table("business_verification_evidence")
