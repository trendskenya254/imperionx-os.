"""Add transaction-linked bilateral feedback and reputation aggregates."""
from alembic import op
import sqlalchemy as sa

revision = "0021_transaction_reputation"
down_revision = "0020_business_identity_trust"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "business_transaction_feedback",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("transaction_id", sa.String(36), sa.ForeignKey("business_transactions.id"), nullable=False),
        sa.Column("reviewer_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("subject_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("communication_rating", sa.Integer(), nullable=False),
        sa.Column("quality_rating", sa.Integer(), nullable=False),
        sa.Column("timeliness_rating", sa.Integer(), nullable=False),
        sa.Column("comment", sa.String(1000), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("transaction_id", "reviewer_organization_id", name="uq_transaction_feedback_reviewer"),
    )
    op.create_index("ix_business_transaction_feedback_transaction_id", "business_transaction_feedback", ["transaction_id"])
    op.create_index("ix_business_transaction_feedback_reviewer_organization_id", "business_transaction_feedback", ["reviewer_organization_id"])
    op.create_index("ix_business_transaction_feedback_subject_organization_id", "business_transaction_feedback", ["subject_organization_id"])

def downgrade():
    op.drop_index("ix_business_transaction_feedback_subject_organization_id", table_name="business_transaction_feedback")
    op.drop_index("ix_business_transaction_feedback_reviewer_organization_id", table_name="business_transaction_feedback")
    op.drop_index("ix_business_transaction_feedback_transaction_id", table_name="business_transaction_feedback")
    op.drop_table("business_transaction_feedback")
