"""Add tenant-scoped sales records for performance reporting."""
from alembic import op
import sqlalchemy as sa

revision = "0008_sales_performance"
down_revision = "0007_inquiry_operations"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "sale_records",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("inquiry_id", sa.String(length=36), sa.ForeignKey("inquiries.id"), nullable=True),
        sa.Column("description", sa.String(length=300), nullable=False),
        sa.Column("amount_minor", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(length=3), nullable=False),
        sa.Column("recorded_by_user_id", sa.String(length=36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("organization_id", "inquiry_id", name="uq_sale_org_inquiry"),
    )
    op.create_index("ix_sale_records_organization_id", "sale_records", ["organization_id"])
    op.create_index("ix_sale_records_inquiry_id", "sale_records", ["inquiry_id"])
    op.create_index("ix_sale_records_created_at", "sale_records", ["created_at"])

def downgrade():
    op.drop_index("ix_sale_records_created_at", table_name="sale_records")
    op.drop_index("ix_sale_records_inquiry_id", table_name="sale_records")
    op.drop_index("ix_sale_records_organization_id", table_name="sale_records")
    op.drop_table("sale_records")
