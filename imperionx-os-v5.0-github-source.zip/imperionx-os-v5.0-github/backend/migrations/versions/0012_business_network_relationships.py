"""Add business capabilities, controlled connection decisions and referrals."""
from alembic import op
import sqlalchemy as sa

revision = "0012_business_network"
down_revision = "0011_business_discovery"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("business_public_profiles") as batch:
        batch.add_column(sa.Column("capabilities", sa.JSON(), nullable=False, server_default="[]"))
    with op.batch_alter_table("business_connections") as batch:
        batch.add_column(sa.Column("shared_fields", sa.JSON(), nullable=False, server_default="[]"))
        batch.add_column(sa.Column("decided_by_user_id", sa.String(length=36), sa.ForeignKey("users.id", name="fk_business_connection_decider"), nullable=True))
        batch.add_column(sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True))
    op.create_table(
        "business_referrals",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("connection_id", sa.String(length=36), sa.ForeignKey("business_connections.id"), nullable=False),
        sa.Column("referrer_organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("referred_organization_id", sa.String(length=36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("description", sa.String(length=1000), nullable=False),
        sa.Column("external_reference", sa.String(length=200)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    for col in ("connection_id", "referrer_organization_id", "referred_organization_id"):
        op.create_index(f"ix_business_referrals_{col}", "business_referrals", [col])

def downgrade():
    for col in ("connection_id", "referrer_organization_id", "referred_organization_id"):
        op.drop_index(f"ix_business_referrals_{col}", table_name="business_referrals")
    op.drop_table("business_referrals")
    op.drop_column("business_connections", "decided_at")
    op.drop_column("business_connections", "decided_by_user_id")
    op.drop_column("business_connections", "shared_fields")
    op.drop_column("business_public_profiles", "capabilities")
