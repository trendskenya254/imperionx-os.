"""Add refresh token rotation and session-family tracking."""
from alembic import op
import sqlalchemy as sa

revision = "0002_refresh_rotation"
down_revision = "0001_security_identity"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("auth_sessions") as batch:
        batch.add_column(sa.Column("refresh_token_hash", sa.String(64), nullable=True))
        batch.add_column(sa.Column("refresh_expires_at", sa.DateTime(timezone=True), nullable=True))
        batch.add_column(sa.Column("family_id", sa.String(36), nullable=True))
    # Existing sessions cannot be refreshed; mark them revoked and require re-login.
    op.execute("UPDATE auth_sessions SET refresh_token_hash = token_hash, refresh_expires_at = expires_at, family_id = id, revoked_at = CURRENT_TIMESTAMP WHERE refresh_token_hash IS NULL")
    with op.batch_alter_table("auth_sessions") as batch:
        batch.alter_column("refresh_token_hash", existing_type=sa.String(64), nullable=False)
        batch.alter_column("refresh_expires_at", existing_type=sa.DateTime(timezone=True), nullable=False)
        batch.alter_column("family_id", existing_type=sa.String(36), nullable=False)
        batch.create_index("ix_auth_sessions_refresh_token_hash", ["refresh_token_hash"], unique=True)
        batch.create_index("ix_auth_sessions_family_id", ["family_id"])

def downgrade():
    with op.batch_alter_table("auth_sessions") as batch:
        batch.drop_index("ix_auth_sessions_family_id")
        batch.drop_index("ix_auth_sessions_refresh_token_hash")
        batch.drop_column("family_id")
        batch.drop_column("refresh_expires_at")
        batch.drop_column("refresh_token_hash")
