"""Add commerce fulfillment, disputes and performance intelligence."""
from alembic import op
import sqlalchemy as sa

revision = "0015_commerce_intelligence"
down_revision = "0014_trust_commerce"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "business_fulfillment_events",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("transaction_id", sa.String(36), sa.ForeignKey("business_transactions.id"), nullable=False),
        sa.Column("supplier_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("milestone", sa.String(20), nullable=False),
        sa.Column("note", sa.String(1000)),
        sa.Column("tracking_reference", sa.String(200)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("transaction_id", "milestone", name="uq_fulfillment_transaction_milestone"),
    )
    op.create_index("ix_business_fulfillment_events_transaction_id", "business_fulfillment_events", ["transaction_id"])
    op.create_index("ix_business_fulfillment_events_supplier_organization_id", "business_fulfillment_events", ["supplier_organization_id"])
    op.create_table(
        "business_disputes",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("transaction_id", sa.String(36), sa.ForeignKey("business_transactions.id"), nullable=False),
        sa.Column("opened_by_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("counterparty_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("category", sa.String(40), nullable=False),
        sa.Column("description", sa.String(3000), nullable=False),
        sa.Column("status", sa.String(30), nullable=False, server_default="open"),
        sa.Column("reviewer_user_id", sa.String(36), sa.ForeignKey("users.id")),
        sa.Column("resolution_note", sa.String(1500)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("resolved_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_business_disputes_transaction_id", "business_disputes", ["transaction_id"])
    op.create_index("ix_business_disputes_opened_by_organization_id", "business_disputes", ["opened_by_organization_id"])
    op.create_index("ix_business_disputes_counterparty_organization_id", "business_disputes", ["counterparty_organization_id"])

def downgrade():
    op.drop_index("ix_business_disputes_counterparty_organization_id", table_name="business_disputes")
    op.drop_index("ix_business_disputes_opened_by_organization_id", table_name="business_disputes")
    op.drop_index("ix_business_disputes_transaction_id", table_name="business_disputes")
    op.drop_table("business_disputes")
    op.drop_index("ix_business_fulfillment_events_supplier_organization_id", table_name="business_fulfillment_events")
    op.drop_index("ix_business_fulfillment_events_transaction_id", table_name="business_fulfillment_events")
    op.drop_table("business_fulfillment_events")
