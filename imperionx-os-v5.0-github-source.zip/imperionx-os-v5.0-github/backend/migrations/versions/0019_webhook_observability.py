"""Add append-only webhook attempt history and worker heartbeats."""
from alembic import op
import sqlalchemy as sa

revision = "0019_webhook_observability"
down_revision = "0018_webhook_delivery_engine"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "webhook_delivery_attempts",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("delivery_id", sa.String(36), sa.ForeignKey("webhook_deliveries.id", ondelete="CASCADE"), nullable=False),
        sa.Column("organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("attempt_number", sa.Integer(), nullable=False),
        sa.Column("outcome", sa.String(24), nullable=False),
        sa.Column("response_status", sa.Integer(), nullable=True),
        sa.Column("error_code", sa.String(120), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("delivery_id", "attempt_number", name="uq_webhook_attempt_delivery_number"),
    )
    op.create_index("ix_webhook_delivery_attempts_delivery_id", "webhook_delivery_attempts", ["delivery_id"])
    op.create_index("ix_webhook_delivery_attempts_organization_id", "webhook_delivery_attempts", ["organization_id"])
    op.create_index("ix_webhook_delivery_attempts_created_at", "webhook_delivery_attempts", ["created_at"])
    op.create_table(
        "webhook_worker_heartbeats",
        sa.Column("worker_id", sa.String(160), primary_key=True),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("processed_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("failure_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("version", sa.String(20), nullable=False, server_default="3.4.0"),
    )
    op.create_index("ix_webhook_worker_heartbeats_last_seen_at", "webhook_worker_heartbeats", ["last_seen_at"])

def downgrade():
    op.drop_index("ix_webhook_worker_heartbeats_last_seen_at", table_name="webhook_worker_heartbeats")
    op.drop_table("webhook_worker_heartbeats")
    op.drop_index("ix_webhook_delivery_attempts_created_at", table_name="webhook_delivery_attempts")
    op.drop_index("ix_webhook_delivery_attempts_organization_id", table_name="webhook_delivery_attempts")
    op.drop_index("ix_webhook_delivery_attempts_delivery_id", table_name="webhook_delivery_attempts")
    op.drop_table("webhook_delivery_attempts")
