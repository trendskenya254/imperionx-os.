"""Add moderated feedback challenges and one-level appeals."""
from alembic import op
import sqlalchemy as sa

revision = "0022_reputation_integrity"
down_revision = "0021_transaction_reputation"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("business_transaction_feedback", sa.Column("moderation_status", sa.String(20), nullable=False, server_default="published"))
    op.create_table(
        "business_feedback_challenges",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("feedback_id", sa.String(36), sa.ForeignKey("business_transaction_feedback.id"), nullable=False),
        sa.Column("challenger_organization_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=False),
        sa.Column("reason", sa.String(40), nullable=False),
        sa.Column("explanation", sa.String(2000), nullable=False),
        sa.Column("evidence_reference", sa.String(500), nullable=True),
        sa.Column("evidence_sha256", sa.String(64), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("reviewer_user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("decision_note", sa.String(1500), nullable=True),
        sa.Column("appeal_note", sa.String(1500), nullable=True),
        sa.Column("appealed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("appeal_reviewer_user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("appeal_decision_note", sa.String(1500), nullable=True),
        sa.Column("appeal_status", sa.String(20), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("feedback_id", "challenger_organization_id", name="uq_feedback_challenger_org"),
    )
    op.create_index("ix_business_feedback_challenges_feedback_id", "business_feedback_challenges", ["feedback_id"])
    op.create_index("ix_business_feedback_challenges_challenger_organization_id", "business_feedback_challenges", ["challenger_organization_id"])

def downgrade():
    op.drop_index("ix_business_feedback_challenges_challenger_organization_id", table_name="business_feedback_challenges")
    op.drop_index("ix_business_feedback_challenges_feedback_id", table_name="business_feedback_challenges")
    op.drop_table("business_feedback_challenges")
    op.drop_column("business_transaction_feedback", "moderation_status")
