from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.pool import StaticPool
from app.config import settings

# SQLite is the zero-setup local/test default. Docker overrides DATABASE_URL with PostgreSQL.
_connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
_engine_options = {"pool_pre_ping": True, "connect_args": _connect_args}
if not settings.database_url.startswith("sqlite"):
    _engine_options.update({
        "pool_size": settings.db_pool_size,
        "max_overflow": settings.db_max_overflow,
        "pool_timeout": settings.db_pool_timeout_seconds,
        "pool_recycle": settings.db_pool_recycle_seconds,
    })
if settings.database_url in ("sqlite://", "sqlite:///:memory:"):
    _engine_options["poolclass"] = StaticPool
engine = create_engine(settings.database_url, **_engine_options)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
