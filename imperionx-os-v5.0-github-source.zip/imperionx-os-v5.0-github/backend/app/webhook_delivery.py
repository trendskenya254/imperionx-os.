"""Fail-closed outbound webhook transport and bounded delivery worker.

The worker resolves DNS for every attempt, rejects the entire answer set if any
address is non-global, then pins the TCP connection to one validated IP while
retaining TLS SNI and certificate hostname verification for the original host.
Redirects are never followed.
"""
from __future__ import annotations

import argparse
import http.client
import ipaddress
import json
import logging
import os
import platform
import uuid
import random
import signal
import threading
import socket
import ssl
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit

from sqlalchemy import select, or_

from app.config import settings
from app.db import SessionLocal
from app.models import WebhookDelivery, WebhookSubscription, WebhookDeliveryAttempt, WebhookWorkerHeartbeat
from app.security import decrypt_mfa_secret

log = logging.getLogger("imperionx.webhooks")
WORKER_ID = os.getenv("WEBHOOK_WORKER_ID", f"{platform.node()}-{os.getpid()}-{uuid.uuid4().hex[:8]}")
MAX_RESPONSE_BYTES = 16 * 1024
MAX_ATTEMPTS = 8
CONNECT_TIMEOUT_SECONDS = 5
READ_TIMEOUT_SECONDS = 10
MAX_BACKOFF_SECONDS = 6 * 60 * 60
PROCESSING_STALE_SECONDS = 120
_STOP_REQUESTED = threading.Event()

def _request_stop(signum, frame):
    _STOP_REQUESTED.set()


class UnsafeWebhookTarget(ValueError):
    pass


def resolve_public_target(url: str, resolver=socket.getaddrinfo) -> tuple[str, int, str, list[str]]:
    parsed = urlsplit(url)
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username is not None
            or parsed.password is not None or parsed.port not in (None, 443)
            or parsed.fragment or len(url) > 1000):
        raise UnsafeWebhookTarget("endpoint must be a valid HTTPS URL on port 443")
    host = parsed.hostname.rstrip(".").encode("idna").decode("ascii").lower()
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal")):
        raise UnsafeWebhookTarget("local hostnames are not permitted")
    try:
        literal = ipaddress.ip_address(host)
        addresses = [str(literal)]
    except ValueError:
        try:
            answers = resolver(host, 443, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise OSError("DNS resolution failed") from exc
        addresses = sorted({item[4][0].split("%", 1)[0] for item in answers})
    if not addresses:
        raise UnsafeWebhookTarget("hostname did not resolve")
    # Reject mixed public/private DNS answers too; do not merely select a public one.
    for value in addresses:
        try:
            address = ipaddress.ip_address(value)
        except ValueError as exc:
            raise UnsafeWebhookTarget("invalid DNS address") from exc
        if not address.is_global:
            raise UnsafeWebhookTarget("endpoint resolves to a non-public address")
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    return host, 443, path, addresses


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host: str, ip: str, timeout: float):
        super().__init__(host, 443, timeout=timeout, context=ssl.create_default_context())
        self._pinned_ip = ip

    def connect(self):
        raw = socket.create_connection((self._pinned_ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(raw, server_hostname=self.host)


def post_webhook(url: str, body: bytes, headers: dict[str, str], resolver=socket.getaddrinfo) -> tuple[int, int]:
    host, port, path, addresses = resolve_public_target(url, resolver=resolver)
    # Try only validated public addresses. No proxy environment variables are used.
    last_error = None
    for address in addresses:
        connection = _PinnedHTTPSConnection(host, address, CONNECT_TIMEOUT_SECONDS)
        try:
            connection.request("POST", path, body=body, headers=headers)
            response = connection.getresponse()
            payload = response.read(MAX_RESPONSE_BYTES + 1)
            if len(payload) > MAX_RESPONSE_BYTES:
                raise OSError("webhook response exceeded size limit")
            return response.status, len(payload)
        except (OSError, ssl.SSLError, http.client.HTTPException) as exc:
            last_error = exc
        finally:
            connection.close()
    raise OSError(f"all validated endpoint addresses failed: {type(last_error).__name__ if last_error else 'connection error'}")


def retry_delay(attempt: int) -> int:
    # Capped exponential backoff with bounded jitter to avoid synchronized retry storms.
    base = min(30 * (2 ** max(0, attempt - 1)), MAX_BACKOFF_SECONDS)
    return min(MAX_BACKOFF_SECONDS, max(1, int(base * random.uniform(0.8, 1.2))))


def _claim_one(db, now):
    stale = now - timedelta(seconds=PROCESSING_STALE_SECONDS)
    query = (select(WebhookDelivery)
             .where(or_(WebhookDelivery.status == "queued",
                        (WebhookDelivery.status == "retry"),
                        ((WebhookDelivery.status == "processing") & (WebhookDelivery.updated_at < stale))),
                    or_(WebhookDelivery.next_attempt_at.is_(None), WebhookDelivery.next_attempt_at <= now))
             .order_by(WebhookDelivery.created_at)
             .limit(1)
             .with_for_update(skip_locked=True))
    row = db.scalar(query)
    if not row:
        return None
    row.status = "processing"
    row.updated_at = now
    db.commit()
    return row.id


def _touch_heartbeat(session, now, processed=False, failed=False, status="running"):
    row = session.get(WebhookWorkerHeartbeat, WORKER_ID)
    if row is None:
        row = WebhookWorkerHeartbeat(worker_id=WORKER_ID, status=status, started_at=now,
                                      last_seen_at=now, processed_count=0, failure_count=0, version="5.0.0")
        session.add(row)
    row.status = status
    row.last_seen_at = now
    if processed:
        row.processed_count += 1
    if failed:
        row.failure_count += 1


def deliver_one(db=None, sender=post_webhook) -> bool:
    """Deliver one due item. Returns False when the queue has no due item."""
    own_session = db is None
    session = db or SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        delivery_id = _claim_one(session, now)
        if not delivery_id:
            return False
        delivery = session.get(WebhookDelivery, delivery_id)
        if not delivery:
            _touch_heartbeat(session, now, processed=True)
            session.commit()
            return True
        started = time.monotonic()
        attempt_number = delivery.attempts + 1
        subscription = session.get(WebhookSubscription, delivery.subscription_id)
        if not subscription or not subscription.active:
            delivery.status = "dead_lettered"
            delivery.dead_lettered_at = now
            delivery.last_error = "subscription_inactive_or_missing"
            session.commit()
            return True
        if not settings.mfa_encryption_key:
            delivery.status = "retry"
            delivery.last_error = "worker_encryption_key_unavailable"
            delivery.next_attempt_at = now + timedelta(minutes=5)
            session.commit()
            return True
        try:
            secret = decrypt_mfa_secret(subscription.secret_encrypted, settings.mfa_encryption_key)
            body = json.dumps(delivery.payload, sort_keys=True, separators=(",", ":")).encode()
            # Verify persisted signature before sending, guarding accidental/tampered queue data.
            import hashlib, hmac
            expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected, delivery.signature):
                raise ValueError("stored_signature_invalid")
            status, _ = sender(subscription.endpoint_url, body, {
                "Content-Type": "application/json",
                "User-Agent": "IMPERIONX-Webhook/3.5",
                "X-ImperionX-Event": delivery.event_type,
                "X-ImperionX-Delivery": delivery.id,
                "X-ImperionX-Signature": delivery.signature,
                "Idempotency-Key": delivery.idempotency_key,
            })
            delivery.attempts += 1
            delivery.response_status = status
            delivery.last_error = None if 200 <= status < 300 else f"http_{status}"
            if 200 <= status < 300:
                delivery.status = "delivered"
                delivery.delivered_at = datetime.now(timezone.utc)
                delivery.next_attempt_at = None
            elif delivery.attempts >= MAX_ATTEMPTS:
                delivery.status = "dead_lettered"
                delivery.dead_lettered_at = datetime.now(timezone.utc)
                delivery.next_attempt_at = None
            else:
                delivery.status = "retry"
                delivery.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=retry_delay(delivery.attempts))
        except (UnsafeWebhookTarget, ValueError) as exc:
            delivery.attempts += 1
            delivery.status = "dead_lettered"
            delivery.dead_lettered_at = datetime.now(timezone.utc)
            delivery.next_attempt_at = None
            delivery.last_error = str(exc)[:500]
        except Exception as exc:  # network and transient transport errors
            delivery.attempts += 1
            delivery.last_error = f"delivery_error:{type(exc).__name__}"[:500]
            if delivery.attempts >= MAX_ATTEMPTS:
                delivery.status = "dead_lettered"
                delivery.dead_lettered_at = datetime.now(timezone.utc)
                delivery.next_attempt_at = None
            else:
                delivery.status = "retry"
                delivery.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=retry_delay(delivery.attempts))
        duration_ms = max(0, int((time.monotonic() - started) * 1000))
        error_code = None
        if delivery.last_error:
            error_code = delivery.last_error.split(":", 1)[0][:120]
        session.add(WebhookDeliveryAttempt(
            delivery_id=delivery.id, organization_id=delivery.organization_id,
            attempt_number=attempt_number, outcome=delivery.status,
            response_status=delivery.response_status, error_code=error_code,
            duration_ms=duration_ms,
        ))
        _touch_heartbeat(session, datetime.now(timezone.utc), processed=True,
                         failed=delivery.status in ("retry", "dead_lettered"))
        session.commit()
        return True
    finally:
        if own_session:
            session.close()


def run_worker(once: bool = False, idle_seconds: float = 2.0):
    if not settings.webhook_delivery_enabled:
        raise RuntimeError("Webhook delivery is disabled; set WEBHOOK_DELIVERY_ENABLED=true only after security review")
    previous_handlers = {}
    if not once:
        for sig in (signal.SIGTERM, signal.SIGINT):
            previous_handlers[sig] = signal.getsignal(sig)
            signal.signal(sig, _request_stop)
    _STOP_REQUESTED.clear()
    try:
        with SessionLocal() as session:
            _touch_heartbeat(session, datetime.now(timezone.utc), status="running")
            session.commit()
        while not _STOP_REQUESTED.is_set():
            worked = deliver_one()
            if once:
                return
            if not worked:
                with SessionLocal() as session:
                    _touch_heartbeat(session, datetime.now(timezone.utc), status="idle")
                    session.commit()
                _STOP_REQUESTED.wait(idle_seconds)
    finally:
        with SessionLocal() as session:
            _touch_heartbeat(session, datetime.now(timezone.utc), status="stopped")
            session.commit()
        for sig, handler in previous_handlers.items():
            signal.signal(sig, handler)


def main():
    parser = argparse.ArgumentParser(description="IMPERIONX OS secure webhook delivery worker")
    parser.add_argument("--once", action="store_true", help="process at most one due delivery")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    run_worker(once=args.once)


if __name__ == "__main__":
    main()
