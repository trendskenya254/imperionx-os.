from pydantic import BaseModel, Field, ConfigDict
from typing import Any
from datetime import datetime

class OrganizationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    industry: str | None = None
    country_code: str | None = Field(default=None, min_length=2, max_length=2)

class OrganizationOut(BaseModel):
    id: str
    name: str
    industry: str | None
    country_code: str | None
    model_config = ConfigDict(from_attributes=True)

class WorkflowCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    trigger_type: str = "manual"
    action_type: str = "draft_response"
    config: dict[str, Any] = Field(default_factory=dict)

class WorkflowOut(BaseModel):
    id: str
    organization_id: str
    name: str
    description: str | None
    trigger_type: str
    action_type: str
    config: dict
    model_config = ConfigDict(from_attributes=True)

class RunCreate(BaseModel):
    input_data: dict[str, Any] = Field(default_factory=dict)

class RunOut(BaseModel):
    id: str
    organization_id: str
    workflow_id: str
    inquiry_id: str | None = None
    status: str
    input_data: dict
    proposed_action: dict
    decision_note: str | None
    model_config = ConfigDict(from_attributes=True)

class DecisionInput(BaseModel):
    note: str | None = None


class InquiryCreate(BaseModel):
    message: str = Field(min_length=3, max_length=10000)
    source: str = Field(default="manual", max_length=40)
    customer_name: str | None = Field(default=None, max_length=200)
    customer_contact: str | None = Field(default=None, max_length=320)
    subject: str | None = Field(default=None, max_length=300)

class InquiryOut(BaseModel):
    id: str
    organization_id: str
    source: str
    customer_name: str | None
    customer_contact: str | None
    subject: str | None
    message: str
    status: str
    assigned_to_user_id: str | None = None
    model_config = ConfigDict(from_attributes=True)

class InquiryAssignment(BaseModel):
    user_id: str | None = None

class InquiryStatusUpdate(BaseModel):
    status: str = Field(pattern="^(new|in_progress|waiting_customer|resolved|closed)$")


class RegisterInput(BaseModel):
    email: str = Field(min_length=5, max_length=320)
    password: str = Field(min_length=12, max_length=128)
    full_name: str = Field(min_length=2, max_length=200)
    organization_name: str = Field(min_length=2, max_length=200)
    industry: str | None = None
    country_code: str | None = Field(default=None, min_length=2, max_length=2)

class AccountTokenInput(BaseModel):
    token: str = Field(min_length=32, max_length=256)

class PasswordResetRequest(BaseModel):
    email: str = Field(min_length=5, max_length=320)

class PasswordResetConfirm(BaseModel):
    token: str = Field(min_length=32, max_length=256)
    new_password: str = Field(min_length=12, max_length=128)

class LoginInput(BaseModel):
    email: str = Field(min_length=5, max_length=320)
    password: str = Field(min_length=1, max_length=128)

class RefreshInput(BaseModel):
    refresh_token: str = Field(min_length=32, max_length=256)

class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user_id: str
    organization_id: str
    role: str

class MemberCreate(BaseModel):
    email: str = Field(min_length=5, max_length=320)
    role: str = Field(pattern="^(owner|admin|manager|member)$")

class MemberOut(BaseModel):
    user_id: str
    email: str
    full_name: str
    role: str

class AuditOut(BaseModel):
    id: str
    actor_user_id: str | None
    action: str
    resource_type: str
    resource_id: str | None
    details: dict
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class MfaCodeInput(BaseModel):
    code: str = Field(min_length=6, max_length=32)

class MfaLoginInput(BaseModel):
    challenge_token: str = Field(min_length=32, max_length=256)
    code: str = Field(min_length=6, max_length=32)


class InvitationCreate(BaseModel):
    email: str = Field(min_length=5, max_length=320)
    role: str = Field(pattern="^(admin|manager|member)$")

class InvitationAccept(BaseModel):
    token: str = Field(min_length=32, max_length=256)

class InvitationOut(BaseModel):
    id: str
    email: str
    role: str
    expires_at: datetime
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class SaleCreate(BaseModel):
    description: str = Field(min_length=2, max_length=300)
    product_or_service: str | None = Field(default=None, min_length=2, max_length=200)
    amount_minor: int = Field(gt=0, le=100_000_000_000)
    currency: str = Field(pattern="^[A-Z]{3}$")
    inquiry_id: str | None = None

class SaleOut(BaseModel):
    id: str
    organization_id: str
    inquiry_id: str | None
    description: str
    product_or_service: str | None = None
    amount_minor: int
    currency: str
    recorded_by_user_id: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
