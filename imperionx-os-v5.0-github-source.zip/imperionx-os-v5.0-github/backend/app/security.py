"""Small dependency-free password and opaque bearer-token utilities."""
import hashlib, hmac, secrets
from datetime import datetime, timedelta, timezone

SESSION_TTL_SECONDS = 60 * 15
REFRESH_TTL_SECONDS = 60 * 60 * 24 * 30

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${salt.hex()}${digest.hex()}"

def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, salt_hex, digest_hex = encoded.split("$", 2)
        if scheme != "scrypt": return False
        actual = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1)
        return hmac.compare_digest(actual.hex(), digest_hex)
    except (ValueError, TypeError):
        return False

def issue_token() -> tuple[str, str, datetime]:
    token = secrets.token_urlsafe(36)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    expires = datetime.now(timezone.utc) + timedelta(seconds=SESSION_TTL_SECONDS)
    return token, token_hash, expires

def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def issue_refresh_token() -> tuple[str, str, datetime]:
    token = secrets.token_urlsafe(48)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    expires = datetime.now(timezone.utc) + timedelta(seconds=REFRESH_TTL_SECONDS)
    return token, token_hash, expires


def issue_account_token(ttl_minutes: int = 30) -> tuple[str, str, datetime]:
    token = secrets.token_urlsafe(36)
    return token, token_digest(token), datetime.now(timezone.utc) + timedelta(minutes=ttl_minutes)


# RFC 6238 TOTP implementation (30-second step, six digits, SHA-1).
import base64, struct, time
from cryptography.fernet import Fernet

def new_totp_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")

def totp_code(secret: str, timestamp: int | None = None) -> str:
    counter = int((timestamp if timestamp is not None else time.time()) // 30)
    key = base64.b32decode(secret + "=" * ((8 - len(secret) % 8) % 8))
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    number = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7fffffff) % 1_000_000
    return f"{number:06d}"

def verify_totp(secret: str, code: str, timestamp: int | None = None) -> bool:
    current = int(timestamp if timestamp is not None else time.time())
    return any(hmac.compare_digest(totp_code(secret, current + drift * 30), str(code)) for drift in (-1, 0, 1))

def encrypt_mfa_secret(secret: str, key: str) -> str:
    return Fernet(key.encode() if isinstance(key, str) else key).encrypt(secret.encode()).decode()

def decrypt_mfa_secret(encrypted: str, key: str) -> str:
    return Fernet(key.encode() if isinstance(key, str) else key).decrypt(encrypted.encode()).decode()


def matching_totp_step(secret: str, code: str, timestamp: int | None = None) -> int | None:
    current = int(timestamp if timestamp is not None else time.time())
    for drift in (-1, 0, 1):
        step = current // 30 + drift
        if hmac.compare_digest(totp_code(secret, step * 30), str(code)):
            return step
    return None
