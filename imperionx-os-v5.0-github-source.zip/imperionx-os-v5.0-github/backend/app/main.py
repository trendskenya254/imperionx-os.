from contextlib import asynccontextmanager
import json, logging, time
from datetime import datetime, timezone, timedelta
from uuid import uuid4
import hashlib, hmac, secrets, base64, ipaddress, os
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, text, func
from sqlalchemy.exc import IntegrityError
from app.config import settings, validate_production_settings
from app.db import Base, engine, get_db
from app.models import Organization, Workflow, WorkflowRun, Inquiry, User, Membership, AuthSession, AuditEvent, LoginAttempt, AccountToken, MfaChallenge, MfaRecoveryCode, OrganizationInvitation, SaleRecord, PilotEnrollment, PilotFeedback, BusinessPublicProfile, BusinessConnection, BusinessReferral, PublicBusinessLead, PublicLeadRateLimit, BusinessVerification, BusinessVerificationEvidence, BusinessTrustCredential, BusinessPurchaseRequest, BusinessQuote, BusinessTransaction, BusinessFulfillmentEvent, BusinessDispute, BusinessTransactionFeedback, BusinessFeedbackChallenge, IntegrationCredential, WebhookSubscription, WebhookDelivery, WebhookDeliveryAttempt, WebhookWorkerHeartbeat
from app.schemas import (
    WorkflowCreate, WorkflowOut,
    RunCreate, RunOut, DecisionInput, InquiryCreate, InquiryOut, RegisterInput, LoginInput, TokenOut, MemberCreate, MemberOut, AuditOut, RefreshInput, AccountTokenInput, PasswordResetRequest, PasswordResetConfirm, MfaCodeInput, MfaLoginInput, InvitationCreate, InvitationAccept, InvitationOut, InquiryAssignment, InquiryStatusUpdate, SaleCreate, SaleOut
)
from app.security import hash_password, verify_password, issue_token, issue_refresh_token, token_digest, SESSION_TTL_SECONDS, REFRESH_TTL_SECONDS
from app.ai import build_ai_gateway
ai_adapter = build_ai_gateway(settings.ai_provider, settings.ai_base_url, settings.ai_api_key, settings.ai_model)
from app.emailer import deliver_email
from app.security import issue_account_token, new_totp_secret, totp_code, verify_totp, encrypt_mfa_secret, decrypt_mfa_secret, matching_totp_step

class JsonLogFormatter(logging.Formatter):
    def format(self, record):
        message = record.getMessage()
        try:
            payload = json.loads(message)
        except (TypeError, ValueError):
            payload = {"message": message}
        return json.dumps({"timestamp": datetime.now(timezone.utc).isoformat(),
                           "level": record.levelname, "logger": record.name, **payload})

_handler = logging.StreamHandler()
_handler.setFormatter(JsonLogFormatter())
_access_logger = logging.getLogger("imperionx.access")
if not _access_logger.handlers:
    _access_logger.addHandler(_handler)
_access_logger.setLevel(logging.INFO)
_access_logger.propagate = False

@asynccontextmanager
async def lifespan(app: FastAPI):
    validate_production_settings()
    yield

_docs_enabled = settings.app_env.lower() != "production"
app = FastAPI(title=settings.app_name, version="5.0.0",
              description="API-first business automation network starter.", lifespan=lifespan,
              docs_url="/docs" if _docs_enabled else None,
              redoc_url="/redoc" if _docs_enabled else None,
              openapi_url="/openapi.json" if _docs_enabled else None)

@app.middleware("http")
async def request_observability(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    started = time.perf_counter()
    status_code = 500
    try:
        response = await call_next(request)
        status_code = response.status_code
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Cache-Control"] = "no-store"
        if settings.app_env.lower() == "production":
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
        return response
    finally:
        elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
        _access_logger.info(json.dumps({"event": "http_request", "request_id": request_id,
            "method": request.method, "path": request.url.path,
            "status_code": status_code, "duration_ms": elapsed_ms}))

def get_current_user(authorization: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Bearer authentication required", headers={"WWW-Authenticate": "Bearer"})
    raw_token = authorization.split(" ", 1)[1].strip()
    session = db.scalar(select(AuthSession).where(
        AuthSession.token_hash == token_digest(raw_token),
        AuthSession.revoked_at.is_(None),
        AuthSession.expires_at > datetime.now(timezone.utc),
    ))
    if not session:
        raise HTTPException(401, "Invalid or expired session", headers={"WWW-Authenticate": "Bearer"})
    user = db.get(User, session.user_id)
    if not user or not user.is_active:
        raise HTTPException(401, "User account is inactive")
    return user

def require_org(
    x_organization_id: str | None = Header(default=None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not x_organization_id:
        raise HTTPException(400, "X-Organization-ID header is required")
    membership = db.scalar(select(Membership).where(
        Membership.organization_id == x_organization_id, Membership.user_id == user.id
    ))
    if not membership:
        raise HTTPException(403, "You are not a member of this organization")
    return {"organization_id": x_organization_id, "user": user, "role": membership.role}

def require_role(*allowed_roles: str):
    def dependency(context=Depends(require_org)):
        if context["role"] not in allowed_roles:
            raise HTTPException(403, "Your organization role cannot perform this action")
        if context["role"] in ("owner", "admin") and not context["user"].mfa_enabled:
            raise HTTPException(403, "MFA enrollment is required for owners and administrators")
        return context
    return dependency

def audit(db: Session, org_id: str, actor_id: str | None, action: str, resource_type: str, resource_id: str | None = None, details: dict | None = None):
    db.add(AuditEvent(organization_id=org_id, actor_user_id=actor_id, action=action, resource_type=resource_type, resource_id=resource_id, details=details or {}))

def require_platform_reviewer(user: User = Depends(get_current_user)):
    reviewer_ids = {x.strip() for x in os.getenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", "").split(",") if x.strip()}
    if not reviewer_ids or user.id not in reviewer_ids:
        raise HTTPException(403, "Platform reviewer access is not configured for this account")
    if not user.mfa_enabled:
        raise HTTPException(403, "Platform reviewers must have MFA enabled")
    return user

@app.get("/health")
def health():
    """Liveness probe: confirms the API process is responding."""
    return {"status": "ok", "service": "imperionx-os", "version": "5.0.0"}

@app.get("/ready")
def readiness():
    """Readiness probe: confirms the configured database can answer a query."""
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
    except Exception:
        return JSONResponse(status_code=503, content={"status": "not_ready", "dependency": "database"})
    return {"status": "ready", "service": "imperionx-os", "version": "5.0.0"}

def create_account_token(db: Session, user: User, purpose: str) -> str:
    # Invalidate any still-live token of the same purpose before issuing a new one.
    now = datetime.now(timezone.utc)
    for old in db.scalars(select(AccountToken).where(
        AccountToken.user_id == user.id, AccountToken.purpose == purpose,
        AccountToken.used_at.is_(None)
    )).all():
        old.used_at = now
    raw, digest, expires = issue_account_token()
    db.add(AccountToken(user_id=user.id, purpose=purpose, token_hash=digest, expires_at=expires))
    return raw

def send_account_email(user: User, purpose: str, raw_token: str) -> bool:
    if purpose == "verify_email":
        subject = "Verify your IMPERIONX OS email"
        path = "/verify-email"
        intro = "Verify your email address to activate your account."
    else:
        subject = "Reset your IMPERIONX OS password"
        path = "/reset-password"
        intro = "Use this one-time link to reset your password."
    link = f"{settings.public_base_url.rstrip('/')}{path}#token={raw_token}"
    body = f"{intro}\n\n{link}\n\nThis link expires in 30 minutes. If you did not request this, you can ignore this email."
    try:
        return deliver_email(user.email, subject, body)
    except Exception:
        # Never expose provider errors or the token in API responses.
        return False

@app.post("/v1/auth/register", status_code=202)
def register(payload: RegisterInput, db: Session = Depends(get_db)):
    email = payload.email.strip().lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "An account with this email already exists")
    user = User(email=email, full_name=payload.full_name.strip(), password_hash=hash_password(payload.password), email_verified=False)
    org = Organization(name=payload.organization_name.strip(), industry=payload.industry, country_code=payload.country_code)
    db.add_all([user, org]); db.flush()
    membership = Membership(user_id=user.id, organization_id=org.id, role="owner")
    db.add(membership)
    raw_token = create_account_token(db, user, "verify_email")
    audit(db, org.id, user.id, "organization.created", "organization", org.id)
    db.commit()
    delivered = send_account_email(user, "verify_email", raw_token)
    return {"status": "verification_pending", "message": "If the email can be delivered, a verification link will arrive. Verify your email before logging in.", "email_sent": delivered}

@app.post("/v1/auth/verify-email")
def verify_email(payload: AccountTokenInput, db: Session = Depends(get_db)):
    token = db.scalar(select(AccountToken).where(AccountToken.token_hash == token_digest(payload.token), AccountToken.purpose == "verify_email"))
    now = datetime.now(timezone.utc)
    if not token or token.used_at is not None or (token.expires_at.replace(tzinfo=timezone.utc) if token.expires_at.tzinfo is None else token.expires_at) <= now:
        raise HTTPException(400, "Verification link is invalid or expired")
    user = db.get(User, token.user_id)
    if not user or not user.is_active:
        raise HTTPException(400, "Verification link is invalid or expired")
    token.used_at = now
    user.email_verified = True
    db.commit()
    return {"status": "verified", "message": "Email verified. You can now log in."}

@app.post("/v1/auth/resend-verification", status_code=202)
def resend_verification(payload: PasswordResetRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email.strip().lower()))
    if user and user.is_active and not user.email_verified:
        raw = create_account_token(db, user, "verify_email")
        db.commit()
        send_account_email(user, "verify_email", raw)
    return {"message": "If the account exists and needs verification, a new link will be sent when email delivery is available."}

@app.post("/v1/auth/password-reset/request", status_code=202)
def request_password_reset(payload: PasswordResetRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email.strip().lower()))
    if user and user.is_active and user.email_verified:
        raw = create_account_token(db, user, "password_reset")
        db.commit()
        send_account_email(user, "password_reset", raw)
    return {"message": "If a verified account exists for that address, password reset instructions will be sent."}

@app.post("/v1/auth/password-reset/confirm")
def confirm_password_reset(payload: PasswordResetConfirm, db: Session = Depends(get_db)):
    token = db.scalar(select(AccountToken).where(AccountToken.token_hash == token_digest(payload.token), AccountToken.purpose == "password_reset"))
    now = datetime.now(timezone.utc)
    if not token or token.used_at is not None or (token.expires_at.replace(tzinfo=timezone.utc) if token.expires_at.tzinfo is None else token.expires_at) <= now:
        raise HTTPException(400, "Password reset link is invalid or expired")
    user = db.get(User, token.user_id)
    if not user or not user.is_active or not user.email_verified:
        raise HTTPException(400, "Password reset link is invalid or expired")
    user.password_hash = hash_password(payload.new_password)
    token.used_at = now
    for session in db.scalars(select(AuthSession).where(AuthSession.user_id == user.id, AuthSession.revoked_at.is_(None))).all():
        session.revoked_at = now
    for other in db.scalars(select(AccountToken).where(AccountToken.user_id == user.id, AccountToken.purpose == "password_reset", AccountToken.used_at.is_(None))).all():
        other.used_at = now
    db.commit()
    return {"status": "password_reset", "message": "Password updated. Please log in again."}

def create_authenticated_session(db: Session, user: User, membership: Membership):
    token, digest, expires = issue_token()
    refresh_token, refresh_digest, refresh_expires = issue_refresh_token()
    db.add(AuthSession(user_id=user.id, token_hash=digest, expires_at=expires, refresh_token_hash=refresh_digest, refresh_expires_at=refresh_expires, family_id=str(uuid4())))
    audit(db, membership.organization_id, user.id, "auth.login", "user", user.id)
    db.commit()
    return TokenOut(access_token=token, refresh_token=refresh_token, expires_in=SESSION_TTL_SECONDS, user_id=user.id, organization_id=membership.organization_id, role=membership.role).model_dump()

@app.post("/v1/auth/mfa/enroll")
def mfa_enroll(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not settings.mfa_encryption_key:
        raise HTTPException(503, "MFA encryption key is not configured")
    if user.mfa_enabled:
        raise HTTPException(409, "MFA is already enabled")
    secret = new_totp_secret()
    user.pending_mfa_secret = encrypt_mfa_secret(secret, settings.mfa_encryption_key)
    db.commit()
    label = user.email.replace(":", "")
    issuer = "IMPERIONX OS"
    uri = f"otpauth://totp/{issuer}:{label}?secret={secret}&issuer={issuer.replace(' ', '%20')}&algorithm=SHA1&digits=6&period=30"
    return {"secret": secret, "otpauth_uri": uri, "message": "Add this account to an authenticator app, then confirm with a current code. Store the secret securely."}

@app.post("/v1/auth/mfa/enable")
def mfa_enable(payload: MfaCodeInput, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not settings.mfa_encryption_key:
        raise HTTPException(503, "MFA encryption key is not configured")
    if not user.pending_mfa_secret:
        raise HTTPException(400, "Start MFA enrollment first")
    secret = decrypt_mfa_secret(user.pending_mfa_secret, settings.mfa_encryption_key)
    matched_step = matching_totp_step(secret, payload.code)
    if matched_step is None:
        raise HTTPException(400, "Invalid authenticator code")
    user.mfa_last_totp_step = matched_step
    user.mfa_secret = user.pending_mfa_secret
    user.pending_mfa_secret = None
    user.mfa_enabled = True
    raw_codes = [secrets.token_urlsafe(9) for _ in range(10)]
    for code in raw_codes:
        db.add(MfaRecoveryCode(user_id=user.id, code_hash=token_digest(code)))
    db.commit()
    return {"status": "enabled", "recovery_codes": raw_codes, "warning": "These codes are shown once. Store them offline; each can be used once."}

@app.post("/v1/auth/mfa/disable")
def mfa_disable(payload: MfaCodeInput, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not user.mfa_enabled or not user.mfa_secret or not settings.mfa_encryption_key:
        raise HTTPException(400, "MFA is not enabled")
    secret = decrypt_mfa_secret(user.mfa_secret, settings.mfa_encryption_key)
    if not verify_totp(secret, payload.code):
        raise HTTPException(400, "Invalid authenticator code")
    user.mfa_enabled = False
    user.mfa_secret = None
    user.pending_mfa_secret = None
    user.mfa_last_totp_step = None
    for session in db.scalars(select(AuthSession).where(AuthSession.user_id == user.id, AuthSession.revoked_at.is_(None))).all():
        session.revoked_at = datetime.now(timezone.utc)
    for code in db.scalars(select(MfaRecoveryCode).where(MfaRecoveryCode.user_id == user.id, MfaRecoveryCode.used_at.is_(None))).all():
        code.used_at = datetime.now(timezone.utc)
    db.commit()
    return {"status": "disabled", "message": "MFA disabled and existing sessions revoked. Owners and administrators must re-enable MFA before privileged actions."}

@app.post("/v1/auth/mfa/verify-login")
def mfa_verify_login(payload: MfaLoginInput, db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    challenge = db.scalar(select(MfaChallenge).where(MfaChallenge.token_hash == token_digest(payload.challenge_token)).with_for_update())
    if not challenge or challenge.used_at is not None or challenge.attempts >= 5:
        raise HTTPException(401, "MFA challenge is invalid or expired")
    expiry = challenge.expires_at.replace(tzinfo=timezone.utc) if challenge.expires_at.tzinfo is None else challenge.expires_at
    if expiry <= now:
        raise HTTPException(401, "MFA challenge is invalid or expired")
    user = db.get(User, challenge.user_id)
    valid = False
    if user and user.is_active and user.mfa_enabled and user.mfa_secret and settings.mfa_encryption_key:
        secret = decrypt_mfa_secret(user.mfa_secret, settings.mfa_encryption_key)
        matched_step = matching_totp_step(secret, payload.code)
        valid = matched_step is not None and (user.mfa_last_totp_step is None or matched_step > user.mfa_last_totp_step)
        if valid:
            user.mfa_last_totp_step = matched_step
        if not valid:
            recovery = db.scalar(select(MfaRecoveryCode).where(MfaRecoveryCode.user_id == user.id, MfaRecoveryCode.code_hash == token_digest(payload.code), MfaRecoveryCode.used_at.is_(None)))
            if recovery:
                recovery.used_at = now
                valid = True
    challenge.attempts += 1
    if not valid:
        db.commit()
        raise HTTPException(401, "Invalid MFA code")
    challenge.used_at = now
    membership = db.scalar(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at))
    if not membership:
        db.commit()
        raise HTTPException(403, "No organization membership is assigned")
    result = create_authenticated_session(db, user, membership)
    return result

@app.post("/v1/auth/login")
def login(payload: LoginInput, request: Request, db: Session = Depends(get_db)):
    normalized_email = payload.email.strip().lower()
    client_ip = request.client.host if request.client else "unknown"
    subject_key = hashlib.sha256(f"{normalized_email}|{client_ip}".encode()).hexdigest()
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(minutes=15)
    recent_attempts = db.scalars(select(LoginAttempt).where(LoginAttempt.subject_key == subject_key, LoginAttempt.attempted_at >= cutoff)).all()
    if len(recent_attempts) >= 10:
        raise HTTPException(429, "Too many failed login attempts. Try again in 15 minutes.", headers={"Retry-After": "900"})
    user = db.scalar(select(User).where(User.email == normalized_email))
    if not user or not user.is_active or not verify_password(payload.password, user.password_hash):
        db.add(LoginAttempt(subject_key=subject_key, attempted_at=now)); db.commit()
        raise HTTPException(401, "Invalid email or password")
    if not user.email_verified:
        raise HTTPException(403, "Email verification is required before login")
    membership = db.scalar(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at))
    if not membership:
        raise HTTPException(403, "No organization membership is assigned")
    if user.mfa_enabled:
        if not settings.mfa_encryption_key:
            raise HTTPException(503, "MFA encryption key is not configured")
        raw_challenge = secrets.token_urlsafe(36)
        db.add(MfaChallenge(user_id=user.id, token_hash=token_digest(raw_challenge), expires_at=now + timedelta(minutes=5)))
        db.commit()
        return {"mfa_required": True, "challenge_token": raw_challenge, "expires_in": 300}
    return create_authenticated_session(db, user, membership)

@app.post("/v1/auth/refresh", response_model=TokenOut)
def refresh_session(payload: RefreshInput, db: Session = Depends(get_db)):
    raw_refresh = payload.refresh_token
    if not isinstance(raw_refresh, str) or len(raw_refresh) < 32:
        raise HTTPException(401, "Valid refresh token required")
    now = datetime.now(timezone.utc)
    session = db.scalar(select(AuthSession).where(AuthSession.refresh_token_hash == token_digest(raw_refresh)))
    if not session:
        raise HTTPException(401, "Invalid or expired refresh token")
    # Reuse of a rotated token revokes every session in its family.
    if session.revoked_at is not None:
        for item in db.scalars(select(AuthSession).where(AuthSession.family_id == session.family_id, AuthSession.revoked_at.is_(None))).all():
            item.revoked_at = now
        db.commit()
        raise HTTPException(401, "Refresh token reuse detected; session family revoked")
    refresh_expiry = session.refresh_expires_at
    if refresh_expiry.tzinfo is None:
        refresh_expiry = refresh_expiry.replace(tzinfo=timezone.utc)
    if refresh_expiry <= now:
        session.revoked_at = now; db.commit()
        raise HTTPException(401, "Refresh token expired")
    user = db.get(User, session.user_id)
    if not user or not user.is_active:
        session.revoked_at = now; db.commit()
        raise HTTPException(401, "User account is inactive")
    membership = db.scalar(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at))
    if not membership:
        session.revoked_at = now; db.commit()
        raise HTTPException(403, "No organization membership is assigned")
    session.revoked_at = now
    access, access_hash, access_expires = issue_token()
    refresh, refresh_hash, refresh_expires = issue_refresh_token()
    db.add(AuthSession(user_id=user.id, token_hash=access_hash, expires_at=access_expires, refresh_token_hash=refresh_hash, refresh_expires_at=refresh_expires, family_id=session.family_id))
    audit(db, membership.organization_id, user.id, "auth.refresh", "user", user.id)
    db.commit()
    return TokenOut(access_token=access, refresh_token=refresh, expires_in=SESSION_TTL_SECONDS, user_id=user.id, organization_id=membership.organization_id, role=membership.role)

@app.post("/v1/auth/logout", status_code=204)
def logout(user: User = Depends(get_current_user), authorization: str = Header(...), db: Session = Depends(get_db)):
    raw_token = authorization.split(" ", 1)[1].strip()
    session = db.scalar(select(AuthSession).where(AuthSession.token_hash == token_digest(raw_token), AuthSession.user_id == user.id))
    if session:
        now = datetime.now(timezone.utc)
        for family_session in db.scalars(select(AuthSession).where(AuthSession.family_id == session.family_id, AuthSession.revoked_at.is_(None))).all():
            family_session.revoked_at = now
        db.commit()
    return None

@app.get("/v1/auth/me")
def who_am_i(user: User = Depends(get_current_user)):
    return {"id": user.id, "email": user.email, "full_name": user.full_name, "mfa_enabled": user.mfa_enabled}

@app.post("/v1/organizations/members", response_model=MemberOut, status_code=201)
def add_member(payload: MemberCreate, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    if context["role"] == "admin" and payload.role in ("owner", "admin"):
        raise HTTPException(403, "Admins may add managers or members; only the owner may grant admin privileges")
    target = db.scalar(select(User).where(User.email == payload.email.strip().lower()))
    if not target:
        raise HTTPException(404, "User must register before being added to an organization")
    if db.scalar(select(Membership).where(Membership.user_id == target.id, Membership.organization_id == org_id)):
        raise HTTPException(409, "User is already a member")
    membership = Membership(user_id=target.id, organization_id=org_id, role=payload.role)
    db.add(membership); db.flush(); audit(db, org_id, actor.id, "membership.created", "membership", membership.id, {"role": payload.role})
    db.commit()
    return MemberOut(user_id=target.id, email=target.email, full_name=target.full_name, role=membership.role)

@app.post("/v1/organizations/invitations", response_model=InvitationOut, status_code=202)
def create_organization_invitation(payload: InvitationCreate, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    email = payload.email.strip().lower()
    if context["role"] == "admin" and payload.role == "admin":
        raise HTTPException(403, "Only the owner may invite administrators")
    existing_user = db.scalar(select(User).where(User.email == email))
    if existing_user and db.scalar(select(Membership).where(Membership.organization_id == org_id, Membership.user_id == existing_user.id)):
        raise HTTPException(409, "This user is already a member")
    now = datetime.now(timezone.utc)
    # Revoke earlier pending invitations for the same organization and email.
    for old in db.scalars(select(OrganizationInvitation).where(
        OrganizationInvitation.organization_id == org_id, OrganizationInvitation.email == email,
        OrganizationInvitation.accepted_at.is_(None), OrganizationInvitation.revoked_at.is_(None)
    )).all():
        old.revoked_at = now
    raw = secrets.token_urlsafe(32)
    invitation = OrganizationInvitation(organization_id=org_id, invited_by_user_id=actor.id, email=email,
        role=payload.role, token_hash=token_digest(raw), expires_at=now + timedelta(days=7))
    db.add(invitation)
    audit(db, org_id, actor.id, "organization.invitation_created", "invitation", invitation.id, {"role": payload.role})
    db.commit()
    org = db.get(Organization, org_id)
    link = f"{settings.public_base_url.rstrip('/')}/accept-invitation#token={raw}"
    body = f"You have been invited to join {org.name} on IMPERIONX OS as {payload.role}.\n\nAccept this invitation: {link}\n\nThis link expires in 7 days. If you were not expecting this invitation, ignore this email."
    try:
        deliver_email(email, "Invitation to join an IMPERIONX OS organization", body)
    except Exception:
        # Keep the invitation valid; delivery can be retried by issuing a replacement.
        pass
    return invitation

@app.post("/v1/organizations/invitations/accept")
def accept_organization_invitation(payload: InvitationAccept, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not user.email_verified:
        raise HTTPException(403, "Verify your email before accepting organization invitations")
    invitation = db.scalar(select(OrganizationInvitation).where(OrganizationInvitation.token_hash == token_digest(payload.token)))
    now = datetime.now(timezone.utc)
    if not invitation or invitation.accepted_at is not None or invitation.revoked_at is not None or (invitation.expires_at.replace(tzinfo=timezone.utc) if invitation.expires_at.tzinfo is None else invitation.expires_at) <= now:
        raise HTTPException(400, "Invitation is invalid, expired, or already used")
    if invitation.email != user.email.strip().lower():
        raise HTTPException(403, "This invitation was issued to a different email address")
    if db.scalar(select(Membership).where(Membership.organization_id == invitation.organization_id, Membership.user_id == user.id)):
        invitation.accepted_at = now
        db.commit()
        raise HTTPException(409, "You are already a member of this organization")
    membership = Membership(user_id=user.id, organization_id=invitation.organization_id, role=invitation.role)
    db.add(membership)
    invitation.accepted_at = now
    audit(db, invitation.organization_id, user.id, "organization.invitation_accepted", "membership", membership.id, {"role": invitation.role})
    db.commit()
    return {"status": "accepted", "organization_id": invitation.organization_id, "role": invitation.role}

@app.get("/v1/organizations/invitations", response_model=list[InvitationOut])
def list_organization_invitations(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    return db.scalars(select(OrganizationInvitation).where(
        OrganizationInvitation.organization_id == context["organization_id"],
        OrganizationInvitation.accepted_at.is_(None), OrganizationInvitation.revoked_at.is_(None),
        OrganizationInvitation.expires_at > now
    ).order_by(OrganizationInvitation.created_at.desc()).limit(100)).all()

@app.get("/v1/organizations/members", response_model=list[MemberOut])
def list_members(context=Depends(require_role("owner", "admin", "manager", "member")), db: Session = Depends(get_db)):
    rows = db.execute(select(User, Membership).join(Membership, Membership.user_id == User.id).where(Membership.organization_id == context["organization_id"])).all()
    return [MemberOut(user_id=u.id, email=u.email, full_name=u.full_name, role=m.role) for u, m in rows]

@app.patch("/v1/organizations/members/{member_user_id}/role", response_model=MemberOut)
def update_member_role(member_user_id: str, payload: MemberCreate, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    membership = db.scalar(select(Membership).where(
        Membership.organization_id == org_id, Membership.user_id == member_user_id
    ))
    if not membership:
        raise HTTPException(404, "Organization member not found")
    if member_user_id == actor.id:
        raise HTTPException(409, "You cannot change your own role")
    if context["role"] == "admin" and payload.role in ("owner", "admin"):
        raise HTTPException(403, "Only the owner may grant owner or admin privileges")
    if membership.role == "owner" and context["role"] != "owner":
        raise HTTPException(403, "Only the owner may change the owner's role")
    if payload.role == "owner":
        if context["role"] != "owner":
            raise HTTPException(403, "Only the current owner may transfer ownership")
        current_owner = db.scalar(select(Membership).where(
            Membership.organization_id == org_id, Membership.user_id == actor.id
        ))
        if not current_owner or current_owner.role != "owner":
            raise HTTPException(403, "Current owner membership is required")
        current_owner.role = "admin"
    membership.role = payload.role
    target = db.get(User, member_user_id)
    audit(db, org_id, actor.id, "membership.role_changed", "membership", membership.id, {"role": payload.role})
    db.commit()
    return MemberOut(user_id=target.id, email=target.email, full_name=target.full_name, role=membership.role)



# Public discovery: only explicitly published profile fields are exposed.
def _public_profile(org: Organization, profile: BusinessPublicProfile):
    return {"organization_id": org.id, "name": org.name, "industry": org.industry,
            "country_code": org.country_code, "slug": profile.slug, "tagline": profile.tagline,
            "description": profile.description, "website_url": profile.website_url,
            "city": profile.city, "public_email": profile.public_email, "capabilities": profile.capabilities or [],
            "offers": profile.offers or [], "seeks": profile.seeks or []}

@app.put("/v1/business/profile")
def update_business_public_profile(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    """Configure a public-facing profile; publication is explicit and opt-in."""
    org_id = context["organization_id"]
    org = db.get(Organization, org_id)
    slug = payload.get("slug")
    if not isinstance(slug, str) or not (3 <= len(slug.strip()) <= 100):
        raise HTTPException(400, "slug must contain 3 to 100 characters")
    slug = slug.strip().lower()
    if not all(c.isalnum() or c == "-" for c in slug) or slug.startswith("-") or slug.endswith("-"):
        raise HTTPException(400, "slug may contain lowercase letters, numbers and internal hyphens")
    existing = db.scalar(select(BusinessPublicProfile).where(BusinessPublicProfile.slug == slug, BusinessPublicProfile.organization_id != org_id))
    if existing:
        raise HTTPException(409, "This public profile slug is already in use")
    fields = {"tagline": 180, "description": 3000, "website_url": 500, "city": 120, "public_email": 320}
    clean = {}
    for key, limit in fields.items():
        value = payload.get(key)
        if value is not None and (not isinstance(value, str) or len(value.strip()) > limit):
            raise HTTPException(400, f"{key} must be text of at most {limit} characters")
        clean[key] = value.strip() if isinstance(value, str) and value.strip() else None
    website = clean["website_url"]
    if website and not (website.startswith("https://") or website.startswith("http://")):
        raise HTTPException(400, "website_url must use http or https")
    published = payload.get("is_published", False)
    if not isinstance(published, bool):
        raise HTTPException(400, "is_published must be boolean")
    profile = db.get(BusinessPublicProfile, org_id)
    if not profile:
        profile = BusinessPublicProfile(organization_id=org_id, slug=slug)
        db.add(profile)
    profile.slug = slug
    for key, value in clean.items(): setattr(profile, key, value)
    capabilities = payload.get("capabilities", (profile.capabilities or []) if profile else [])
    if not isinstance(capabilities, list) or len(capabilities) > 20 or any(not isinstance(x, str) or not (2 <= len(x.strip()) <= 60) for x in capabilities):
        raise HTTPException(400, "capabilities must be a list of up to 20 labels, each 2-60 characters")
    profile.capabilities = list(dict.fromkeys(x.strip() for x in capabilities))
    for field in ("offers", "seeks"):
        values = payload.get(field, getattr(profile, field, []) or [])
        if not isinstance(values, list) or len(values) > 30 or any(not isinstance(x, str) or not (2 <= len(x.strip()) <= 80) for x in values):
            raise HTTPException(400, f"{field} must be a list of up to 30 labels, each 2-80 characters")
        setattr(profile, field, list(dict.fromkeys(x.strip() for x in values)))
    profile.is_published = published
    audit(db, org_id, context["user"].id, "business.public_profile_updated", "business_public_profile", org_id, {"is_published": published})
    db.commit(); db.refresh(profile)
    return _public_profile(org, profile) | {"is_published": profile.is_published}

@app.get("/v1/business/profile")
def get_business_public_profile(context=Depends(require_org), db: Session = Depends(get_db)):
    profile = db.get(BusinessPublicProfile, context["organization_id"])
    if not profile:
        return {"configured": False, "is_published": False}
    return _public_profile(db.get(Organization, context["organization_id"]), profile) | {"is_published": profile.is_published, "network_discoverable": profile.network_discoverable, "offers": profile.offers or [], "seeks": profile.seeks or []}

@app.get("/v1/discovery/businesses")
def discover_businesses(q: str | None = None, industry: str | None = None, country_code: str | None = None,
                        limit: int = 20, offset: int = 0, db: Session = Depends(get_db)):
    """Search only opt-in published profiles; never returns private tenant data."""
    if limit < 1 or limit > 50 or offset < 0 or offset > 10000:
        raise HTTPException(400, "limit must be 1-50 and offset 0-10000")
    stmt = select(BusinessPublicProfile, Organization).join(Organization, Organization.id == BusinessPublicProfile.organization_id).where(BusinessPublicProfile.is_published.is_(True))
    if q:
        term = q.strip()[:100]
        if term:
            pattern = f"%{term}%"
            stmt = stmt.where((Organization.name.ilike(pattern)) | (Organization.industry.ilike(pattern)) | (BusinessPublicProfile.tagline.ilike(pattern)) | (BusinessPublicProfile.description.ilike(pattern)))
    if industry: stmt = stmt.where(Organization.industry.ilike(industry.strip()[:120]))
    if country_code: stmt = stmt.where(Organization.country_code == country_code.strip().upper()[:2])
    rows = db.execute(stmt.order_by(Organization.name.asc()).offset(offset).limit(limit)).all()
    return {"items": [_public_profile(org, profile) for profile, org in rows], "limit": limit, "offset": offset}

@app.get("/v1/discovery/matches")
def discover_business_matches(direction: str = "find_suppliers", industry: str | None = None,
                              country_code: str | None = None, q: str | None = None,
                              limit: int = 20, offset: int = 0,
                              context=Depends(require_org), db: Session = Depends(get_db)):
    """Explainable buyer/supplier/partner matching using explicitly published business profiles."""
    if direction not in ("find_suppliers", "find_buyers", "find_partners"):
        raise HTTPException(400, "direction must be find_suppliers, find_buyers or find_partners")
    if limit < 1 or limit > 50 or offset < 0 or offset > 10000:
        raise HTTPException(400, "limit must be 1-50 and offset 0-10000")
    if q is not None and (not isinstance(q, str) or len(q.strip()) > 100):
        raise HTTPException(400, "q must be at most 100 characters")
    org_id = context["organization_id"]
    own_profile = db.get(BusinessPublicProfile, org_id)
    own_organization = db.get(Organization, org_id)
    if not own_profile:
        raise HTTPException(409, "Configure your business profile and matching preferences first")
    if direction == "find_suppliers":
        desired = set((own_profile.seeks or []) + (own_profile.capabilities or []))
        own_offers = set((own_profile.offers or []) + (own_profile.capabilities or []))
    elif direction == "find_buyers":
        desired = set((own_profile.offers or []) + (own_profile.capabilities or []))
        own_offers = set((own_profile.offers or []) + (own_profile.capabilities or []))
    else:
        desired = set((own_profile.offers or []) + (own_profile.seeks or []) + (own_profile.capabilities or []))
        own_offers = desired
    if not desired and not (q and q.strip()):
        raise HTTPException(409, "Add capabilities, offers or seeks to your business profile to generate matches")
    stmt = select(BusinessPublicProfile, Organization).join(
        Organization, Organization.id == BusinessPublicProfile.organization_id
    ).where(BusinessPublicProfile.is_published.is_(True), BusinessPublicProfile.organization_id != org_id)
    if industry:
        stmt = stmt.where(Organization.industry.ilike(industry.strip()[:120]))
    if country_code:
        stmt = stmt.where(Organization.country_code == country_code.strip().upper()[:2])
    rows = db.execute(stmt.order_by(Organization.name.asc()).limit(5001)).all()
    candidate_scan_truncated = len(rows) > 5000
    rows = rows[:5000]
    needle = q.strip().casefold() if q else None
    desired_folded = {label.casefold() for label in desired}
    own_offers_folded = {label.casefold() for label in own_offers}
    matches = []
    for profile, organization in rows:
        if needle and not any(needle in value.casefold() for value in
            [organization.name or "", organization.industry or "", profile.tagline or ""] +
            (profile.capabilities or []) + (profile.offers or []) + (profile.seeks or [])):
            continue
        candidate_labels = set(profile.offers or []) | set(profile.capabilities or [])
        if direction == "find_suppliers":
            overlap_keys = desired_folded.intersection(label.casefold() for label in candidate_labels)
        elif direction == "find_buyers":
            overlap_keys = own_offers_folded.intersection(label.casefold() for label in (set(profile.seeks or []) | set(profile.capabilities or [])))
        else:
            overlap_keys = desired_folded.intersection(label.casefold() for label in (candidate_labels | set(profile.seeks or [])))
        candidate_display = {label.casefold(): label for label in candidate_labels | set(profile.seeks or [])}
        overlap = sorted(candidate_display[key] for key in overlap_keys)
        if not overlap and not needle:
            continue
        reasons = [f"Capability match: {label}" for label in overlap[:8]]
        if needle and not overlap:
            reasons.append("Text match in published profile")
        if own_organization and own_organization.country_code and organization.country_code == own_organization.country_code:
            reasons.append("Same country")
        if own_organization and own_organization.industry and organization.industry and organization.industry.casefold() == own_organization.industry.casefold():
            reasons.append("Same industry")
        matches.append({"organization_id": organization.id, "name": organization.name,
            "industry": organization.industry, "country_code": organization.country_code,
            "slug": profile.slug, "tagline": profile.tagline,
            "capabilities": profile.capabilities or [], "offers": profile.offers or [],
            "seeks": profile.seeks or [], "matching_capabilities": overlap,
            "match_reasons": reasons,
            "relevance": "strong" if len(overlap) >= 2 else "potential",
            "introduction_endpoint": "/v1/business/connections"})
    matches.sort(key=lambda item: (-len(item["matching_capabilities"]), item["name"].casefold()))
    total = len(matches)
    return {"api_version": "5.0.0", "direction": direction,
        "items": matches[offset:offset + limit], "total": total,
        "limit": limit, "offset": offset,
        "candidate_scan_truncated": candidate_scan_truncated,
        "matching_method": "Transparent overlap of published capabilities, offers and seeks; relevance is descriptive, not a trust score.",
        "privacy": "Only published profile fields are returned. Private contact details and non-published organizations are excluded. Introductions require a separate connection request and recipient approval."}

@app.get("/v1/discovery/businesses/{slug}")
def get_public_business(slug: str, db: Session = Depends(get_db)):
    row = db.execute(select(BusinessPublicProfile, Organization).join(Organization, Organization.id == BusinessPublicProfile.organization_id).where(BusinessPublicProfile.slug == slug, BusinessPublicProfile.is_published.is_(True))).first()
    if not row: raise HTTPException(404, "Published business profile not found")
    profile, org = row
    return _public_profile(org, profile)

@app.post("/v1/discovery/businesses/{slug}/leads", status_code=201)
def create_public_business_lead(slug: str, payload: dict, request: Request, db: Session = Depends(get_db)):
    """Public lead form. Explicit consent is mandatory; contact details are private to the target business."""
    profile = db.scalar(select(BusinessPublicProfile).where(BusinessPublicProfile.slug == slug, BusinessPublicProfile.is_published.is_(True)))
    if not profile: raise HTTPException(404, "Published business profile not found")
    name, email, message = payload.get("contact_name"), payload.get("contact_email"), payload.get("message")
    if not isinstance(name, str) or not (2 <= len(name.strip()) <= 160): raise HTTPException(400, "contact_name is required")
    if not isinstance(email, str) or len(email.strip()) > 320 or "@" not in email: raise HTTPException(400, "valid contact_email is required")
    if not isinstance(message, str) or not (3 <= len(message.strip()) <= 4000): raise HTTPException(400, "message must contain 3 to 4000 characters")
    if payload.get("consent_to_contact") is not True: raise HTTPException(400, "Explicit consent to be contacted is required")
    # Store only a one-way digest of the client address and profile slug. Configure trusted proxy
    # handling at the edge; never trust arbitrary X-Forwarded-For values in application code.
    client_host = request.client.host if request.client else "unknown"
    trusted_proxies = {x.strip() for x in os.getenv("IMPERIONX_TRUSTED_PROXY_IPS", "").split(",") if x.strip()}
    forwarded = request.headers.get("x-forwarded-for", "")
    if client_host in trusted_proxies and forwarded:
        candidate = forwarded.split(",", 1)[0].strip()
        try:
            client_host = str(ipaddress.ip_address(candidate))
        except ValueError:
            pass
    rate_secret = (settings.public_rate_limit_hmac_key or "imperionx-development-only-rate-limit-key").encode()
    rate_key = hmac.new(rate_secret, f"{client_host}:{slug}".encode(), hashlib.sha256).hexdigest()
    now = datetime.now(timezone.utc)
    db.query(PublicLeadRateLimit).filter(PublicLeadRateLimit.window_started_at < now - timedelta(days=1)).delete(synchronize_session=False)
    limiter = db.get(PublicLeadRateLimit, rate_key)
    window_start = limiter.window_started_at if limiter and limiter.window_started_at.tzinfo else (limiter.window_started_at.replace(tzinfo=timezone.utc) if limiter else now)
    if limiter and (now - window_start).total_seconds() < 900:
        if limiter.attempts >= 5:
            raise HTTPException(429, "Too many submissions. Please try again later.", headers={"Retry-After": "900"})
        limiter.attempts += 1
    else:
        if limiter:
            limiter.window_started_at = now; limiter.attempts = 1
        else:
            db.add(PublicLeadRateLimit(key_hash=rate_key, window_started_at=now, attempts=1))
    lead = PublicBusinessLead(organization_id=profile.organization_id, contact_name=name.strip(), contact_email=email.strip().lower(), message=message.strip(), consent_to_contact=True)
    db.add(lead); db.commit(); db.refresh(lead)
    return {"id": lead.id, "status": lead.status, "message": "Your inquiry has been submitted to the business."}

@app.get("/v1/business/leads")
def list_business_leads(context=Depends(require_org), db: Session = Depends(get_db)):
    rows = db.scalars(select(PublicBusinessLead).where(PublicBusinessLead.organization_id == context["organization_id"]).order_by(PublicBusinessLead.created_at.desc()).limit(100)).all()
    return [{"id": x.id, "contact_name": x.contact_name, "contact_email": x.contact_email, "message": x.message,
             "consent_to_contact": x.consent_to_contact, "status": x.status, "created_at": x.created_at.isoformat()} for x in rows]

@app.post("/v1/business/connections", status_code=201)
def request_business_connection(payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    target_slug = payload.get("target_slug")
    if not isinstance(target_slug, str): raise HTTPException(400, "target_slug is required")
    target = db.scalar(select(BusinessPublicProfile).where(BusinessPublicProfile.slug == target_slug, BusinessPublicProfile.is_published.is_(True)))
    if not target: raise HTTPException(404, "Published target business not found")
    source_id = context["organization_id"]
    if target.organization_id == source_id: raise HTTPException(400, "A business cannot connect to itself")
    message = payload.get("message")
    if message is not None and (not isinstance(message, str) or len(message.strip()) > 1000): raise HTTPException(400, "message must be at most 1000 characters")
    prior = db.scalar(select(BusinessConnection).where(BusinessConnection.requester_organization_id == source_id, BusinessConnection.target_organization_id == target.organization_id))
    if prior: raise HTTPException(409, "A connection request already exists")
    connection = BusinessConnection(requester_organization_id=source_id, target_organization_id=target.organization_id, message=message.strip() if message else None)
    db.add(connection); audit(db, source_id, context["user"].id, "business.connection_requested", "business_connection", connection.id)
    db.commit(); db.refresh(connection)
    return {"id": connection.id, "status": connection.status, "target_slug": target.slug}

@app.post("/v1/business/connections/{connection_id}/decision")
def decide_business_connection(connection_id: str, payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    connection = db.get(BusinessConnection, connection_id)
    org_id = context["organization_id"]
    if not connection or connection.target_organization_id != org_id:
        raise HTTPException(404, "Incoming connection request not found")
    if connection.status != "pending":
        raise HTTPException(409, "Only pending requests can be decided")
    decision = payload.get("decision")
    if decision not in ("accepted", "rejected"):
        raise HTTPException(400, "decision must be accepted or rejected")
    allowed_fields = {"tagline", "description", "website_url", "city", "public_email", "capabilities"}
    shared_fields = payload.get("shared_fields", [])
    if not isinstance(shared_fields, list) or any(not isinstance(x, str) or x not in allowed_fields for x in shared_fields) or len(set(shared_fields)) != len(shared_fields):
        raise HTTPException(400, "shared_fields contains an unsupported or duplicate field")
    if decision == "rejected" and shared_fields:
        raise HTTPException(400, "Rejected connections cannot share profile fields")
    connection.status = decision
    connection.shared_fields = shared_fields if decision == "accepted" else []
    connection.decided_by_user_id = context["user"].id
    connection.decided_at = datetime.now(timezone.utc)
    audit(db, org_id, context["user"].id, f"business.connection_{decision}", "business_connection", connection.id, {"shared_fields": connection.shared_fields})
    if decision == "accepted":
        enqueue_webhook_event(db, [connection.requester_organization_id, connection.target_organization_id],
            "network.connection.accepted", {"connection_id": connection.id})
    db.commit()
    return {"id": connection.id, "status": connection.status, "shared_fields": connection.shared_fields, "decided_at": connection.decided_at.isoformat()}

@app.get("/v1/business/connections")
def list_business_connections(context=Depends(require_org), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    rows = db.scalars(select(BusinessConnection).where((BusinessConnection.requester_organization_id == org_id) | (BusinessConnection.target_organization_id == org_id)).order_by(BusinessConnection.created_at.desc()).limit(100)).all()
    results = []
    for x in rows:
        item = {"id": x.id, "requester_organization_id": x.requester_organization_id, "target_organization_id": x.target_organization_id,
                "message": x.message, "status": x.status, "shared_fields": x.shared_fields or [], "created_at": x.created_at.isoformat(),
                "decided_at": x.decided_at.isoformat() if x.decided_at else None}
        if x.requester_organization_id == org_id and x.status == "accepted" and x.shared_fields:
            profile = db.get(BusinessPublicProfile, x.target_organization_id); target_org = db.get(Organization, x.target_organization_id)
            if profile and target_org:
                public = _public_profile(target_org, profile)
                item["shared_profile"] = {k: public[k] for k in x.shared_fields if k in public}
        results.append(item)
    return results

@app.post("/v1/business/referrals", status_code=201)
def create_business_referral(payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    connection_id, description = payload.get("connection_id"), payload.get("description")
    external_reference = payload.get("external_reference")
    if not isinstance(description, str) or not (3 <= len(description.strip()) <= 1000):
        raise HTTPException(400, "description must contain 3-1000 characters")
    if external_reference is not None and (not isinstance(external_reference, str) or len(external_reference.strip()) > 200):
        raise HTTPException(400, "external_reference must be at most 200 characters")
    connection = db.get(BusinessConnection, connection_id) if isinstance(connection_id, str) else None
    org_id = context["organization_id"]
    if not connection or connection.status != "accepted" or org_id not in (connection.requester_organization_id, connection.target_organization_id):
        raise HTTPException(404, "Accepted business connection not found")
    referred = connection.target_organization_id if org_id == connection.requester_organization_id else connection.requester_organization_id
    referral = BusinessReferral(connection_id=connection.id, referrer_organization_id=org_id, referred_organization_id=referred,
                                description=description.strip(), external_reference=external_reference.strip() if external_reference else None)
    db.add(referral); audit(db, org_id, context["user"].id, "business.referral_created", "business_referral", referral.id)
    db.commit(); db.refresh(referral)
    return {"id": referral.id, "connection_id": referral.connection_id, "status": "recorded", "created_at": referral.created_at.isoformat()}

@app.get("/v1/business/referrals")
def list_business_referrals(context=Depends(require_org), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    rows = db.scalars(select(BusinessReferral).where((BusinessReferral.referrer_organization_id == org_id) | (BusinessReferral.referred_organization_id == org_id)).order_by(BusinessReferral.created_at.desc()).limit(100)).all()
    return [{"id": x.id, "connection_id": x.connection_id, "referrer_organization_id": x.referrer_organization_id,
             "referred_organization_id": x.referred_organization_id, "description": x.description,
             "external_reference": x.external_reference, "created_at": x.created_at.isoformat()} for x in rows]

@app.post("/v1/business/verification", status_code=201)
def submit_business_verification(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    evidence_type = payload.get("evidence_type")
    evidence_reference = payload.get("evidence_reference")
    note = payload.get("note")
    if not isinstance(evidence_type, str) or not (2 <= len(evidence_type.strip()) <= 80):
        raise HTTPException(400, "evidence_type must contain 2-80 characters")
    if evidence_reference is not None and (not isinstance(evidence_reference, str) or len(evidence_reference.strip()) > 500):
        raise HTTPException(400, "evidence_reference must be at most 500 characters")
    if note is not None and (not isinstance(note, str) or len(note.strip()) > 1000):
        raise HTTPException(400, "note must be at most 1000 characters")
    org_id = context["organization_id"]; record = db.get(BusinessVerification, org_id)
    if record and record.status == "pending": raise HTTPException(409, "A verification review is already pending")
    if not record:
        record = BusinessVerification(organization_id=org_id); db.add(record)
    record.status = "pending"; record.evidence_type = evidence_type.strip()
    record.evidence_reference = evidence_reference.strip() if evidence_reference else None
    record.applicant_note = note.strip() if note else None
    record.reviewer_user_id = None; record.reviewer_note = None
    record.submitted_at = datetime.now(timezone.utc); record.reviewed_at = None
    audit(db, org_id, context["user"].id, "business.verification_submitted", "business_verification", org_id)
    db.commit(); return {"organization_id": org_id, "status": record.status, "submitted_at": record.submitted_at.isoformat()}

@app.get("/v1/business/verification")
def get_business_verification(context=Depends(require_org), db: Session = Depends(get_db)):
    record = db.get(BusinessVerification, context["organization_id"])
    if not record: return {"organization_id": context["organization_id"], "status": "not_submitted"}
    return {"organization_id": record.organization_id, "status": record.status, "evidence_type": record.evidence_type,
            "reviewer_note": record.reviewer_note, "submitted_at": record.submitted_at.isoformat() if record.submitted_at else None,
            "reviewed_at": record.reviewed_at.isoformat() if record.reviewed_at else None}

@app.get("/v1/platform/verifications")
def list_platform_verifications(reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    rows = db.scalars(select(BusinessVerification).where(BusinessVerification.status == "pending").order_by(BusinessVerification.submitted_at.asc()).limit(100)).all()
    return [{"organization_id": x.organization_id, "organization_name": db.get(Organization, x.organization_id).name,
             "status": x.status, "evidence_type": x.evidence_type, "evidence_reference": x.evidence_reference,
             "applicant_note": x.applicant_note, "submitted_at": x.submitted_at.isoformat() if x.submitted_at else None} for x in rows]

@app.post("/v1/platform/verifications/{organization_id}/decision")
def decide_platform_verification(organization_id: str, payload: dict, reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    record = db.get(BusinessVerification, organization_id)
    if not record or record.status != "pending": raise HTTPException(404, "Pending verification request not found")
    if db.scalar(select(Membership).where(Membership.organization_id == organization_id, Membership.user_id == reviewer.id)):
        raise HTTPException(403, "Reviewers cannot review a business they belong to")
    decision = payload.get("decision"); note = payload.get("note")
    if decision not in ("verified", "rejected"): raise HTTPException(400, "decision must be verified or rejected")
    if not isinstance(note, str) or not (3 <= len(note.strip()) <= 1000): raise HTTPException(400, "A review note of 3-1000 characters is required")
    record.status = decision; record.reviewer_user_id = reviewer.id; record.reviewer_note = note.strip()
    record.reviewed_at = datetime.now(timezone.utc)
    audit(db, organization_id, reviewer.id, f"business.verification_{decision}", "business_verification", organization_id)
    db.commit(); return {"organization_id": organization_id, "status": record.status, "reviewed_at": record.reviewed_at.isoformat()}

@app.post("/v1/business/verification/evidence", status_code=201)
def add_business_verification_evidence(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    evidence_type = payload.get("evidence_type")
    reference = payload.get("evidence_reference")
    issuer = payload.get("issuer_name")
    scope = payload.get("access_scope", "review_only")
    if not isinstance(evidence_type, str) or not 2 <= len(evidence_type.strip()) <= 80:
        raise HTTPException(400, "evidence_type must contain 2-80 characters")
    if not isinstance(reference, str) or not reference.strip() or len(reference.strip()) > 500:
        raise HTTPException(400, "evidence_reference must contain 1-500 characters")
    if issuer is not None and (not isinstance(issuer, str) or len(issuer.strip()) > 200):
        raise HTTPException(400, "issuer_name must be at most 200 characters")
    if scope not in ("review_only", "organization_admins"):
        raise HTTPException(400, "access_scope must be review_only or organization_admins")
    expires_at = None
    if payload.get("expires_at"):
        try:
            expires_at = datetime.fromisoformat(payload["expires_at"].replace("Z", "+00:00"))
            if expires_at.tzinfo is None: raise ValueError()
        except (ValueError, AttributeError):
            raise HTTPException(400, "expires_at must be an ISO-8601 timestamp with timezone")
    org_id = context["organization_id"]
    item = BusinessVerificationEvidence(organization_id=org_id, submitted_by_user_id=context["user"].id,
        evidence_type=evidence_type.strip(), evidence_reference=reference.strip(),
        issuer_name=issuer.strip() if issuer else None, expires_at=expires_at, access_scope=scope)
    db.add(item)
    audit(db, org_id, context["user"].id, "business.verification_evidence_added", "business_verification_evidence", item.id,
          {"evidence_type": item.evidence_type, "access_scope": scope})
    db.commit(); db.refresh(item)
    return {"id": item.id, "evidence_type": item.evidence_type, "issuer_name": item.issuer_name,
            "expires_at": item.expires_at.isoformat() if item.expires_at else None, "access_scope": item.access_scope,
            "created_at": item.created_at.isoformat()}

@app.get("/v1/business/verification/evidence")
def list_business_verification_evidence(context=Depends(require_org), db: Session = Depends(get_db)):
    rows = db.scalars(select(BusinessVerificationEvidence).where(
        BusinessVerificationEvidence.organization_id == context["organization_id"]).order_by(BusinessVerificationEvidence.created_at.desc()).limit(100)).all()
    return [{"id": x.id, "evidence_type": x.evidence_type, "issuer_name": x.issuer_name,
             "expires_at": x.expires_at.isoformat() if x.expires_at else None, "access_scope": x.access_scope,
             "created_at": x.created_at.isoformat()} for x in rows]

@app.get("/v1/platform/verifications/{organization_id}/evidence")
def list_platform_verification_evidence(organization_id: str, reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    if not db.get(Organization, organization_id):
        raise HTTPException(404, "Organization not found")
    if db.scalar(select(Membership).where(Membership.organization_id == organization_id, Membership.user_id == reviewer.id)):
        raise HTTPException(403, "Reviewers cannot inspect evidence for a business they belong to")
    rows = db.scalars(select(BusinessVerificationEvidence).where(
        BusinessVerificationEvidence.organization_id == organization_id).order_by(BusinessVerificationEvidence.created_at.desc()).limit(100)).all()
    return [{"id": x.id, "evidence_type": x.evidence_type, "evidence_reference": x.evidence_reference,
             "issuer_name": x.issuer_name, "expires_at": x.expires_at.isoformat() if x.expires_at else None,
             "access_scope": x.access_scope, "created_at": x.created_at.isoformat()} for x in rows]

@app.post("/v1/platform/verifications/{organization_id}/credentials", status_code=201)
def issue_business_trust_credential(organization_id: str, payload: dict, reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    record = db.get(BusinessVerification, organization_id)
    if not record or record.status != "verified":
        raise HTTPException(409, "Organization must be verified before credential issuance")
    if db.scalar(select(Membership).where(Membership.organization_id == organization_id, Membership.user_id == reviewer.id)):
        raise HTTPException(403, "Reviewers cannot issue credentials for a business they belong to")
    key = settings.public_rate_limit_hmac_key
    if not key or len(key) < 32:
        raise HTTPException(503, "Trust credential signing is not configured")
    credential_type = payload.get("credential_type", "business_verification")
    if not isinstance(credential_type, str) or not 2 <= len(credential_type.strip()) <= 80:
        raise HTTPException(400, "credential_type must contain 2-80 characters")
    expires_at = None
    if payload.get("expires_at"):
        try:
            expires_at = datetime.fromisoformat(payload["expires_at"].replace("Z", "+00:00"))
            if expires_at.tzinfo is None: raise ValueError()
        except (ValueError, AttributeError):
            raise HTTPException(400, "expires_at must be an ISO-8601 timestamp with timezone")
        if expires_at <= datetime.now(timezone.utc): raise HTTPException(400, "expires_at must be in the future")
    issued_at = datetime.now(timezone.utc)
    claims = {"organization_id": organization_id, "verification_status": "verified", "credential_type": credential_type.strip()}
    canonical = json.dumps({"claims": claims, "issuer": "IMPERIONX OS", "issued_at": issued_at.isoformat(),
                            "expires_at": expires_at.isoformat() if expires_at else None}, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(canonical.encode()).hexdigest()
    signature = hmac.new(key.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    item = BusinessTrustCredential(organization_id=organization_id, credential_type=credential_type.strip(),
        issuer="IMPERIONX OS", claims=claims, payload_digest=digest, signature=signature,
        issued_at=issued_at, expires_at=expires_at)
    db.add(item)
    audit(db, organization_id, reviewer.id, "business.trust_credential_issued", "business_trust_credential", item.id,
          {"credential_type": item.credential_type, "payload_digest": digest})
    db.commit(); db.refresh(item)
    return {"id": item.id, "credential_type": item.credential_type, "claims": item.claims,
            "issuer": item.issuer, "payload_digest": item.payload_digest, "signature": item.signature,
            "issued_at": item.issued_at.isoformat(), "expires_at": item.expires_at.isoformat() if item.expires_at else None,
            "status": "active"}

@app.post("/v1/platform/trust-credentials/{credential_id}/revoke")
def revoke_business_trust_credential(credential_id: str, payload: dict, reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    item = db.get(BusinessTrustCredential, credential_id)
    if not item: raise HTTPException(404, "Trust credential not found")
    if item.revoked_at: raise HTTPException(409, "Trust credential is already revoked")
    reason = payload.get("reason")
    if not isinstance(reason, str) or not 3 <= len(reason.strip()) <= 500:
        raise HTTPException(400, "reason must contain 3-500 characters")
    item.revoked_at = datetime.now(timezone.utc); item.revoked_by_user_id = reviewer.id; item.revocation_reason = reason.strip()
    audit(db, item.organization_id, reviewer.id, "business.trust_credential_revoked", "business_trust_credential", item.id,
          {"reason": reason.strip()})
    db.commit()
    return {"id": item.id, "status": "revoked", "revoked_at": item.revoked_at.isoformat()}

@app.get("/v1/network/organizations/{organization_id}/trust")
def get_connected_organization_trust(organization_id: str, context=Depends(require_org), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    connection = db.scalar(select(BusinessConnection).where(BusinessConnection.status == "accepted",
        ((BusinessConnection.requester_organization_id == org_id) & (BusinessConnection.target_organization_id == organization_id)) |
        ((BusinessConnection.requester_organization_id == organization_id) & (BusinessConnection.target_organization_id == org_id))))
    if not connection: raise HTTPException(404, "Accepted business connection not found")
    verification = db.get(BusinessVerification, organization_id)
    now = datetime.now(timezone.utc)
    credentials = db.scalars(select(BusinessTrustCredential).where(
        BusinessTrustCredential.organization_id == organization_id, BusinessTrustCredential.revoked_at.is_(None)).order_by(BusinessTrustCredential.issued_at.desc()).limit(50)).all()
    active = []
    for item in credentials:
        expiry = item.expires_at
        if expiry is not None and expiry.tzinfo is None: expiry = expiry.replace(tzinfo=timezone.utc)
        if expiry is not None and expiry <= now: continue
        active.append({"id": item.id, "credential_type": item.credential_type, "claims": item.claims,
                       "issuer": item.issuer, "payload_digest": item.payload_digest, "signature": item.signature,
                       "issued_at": item.issued_at.isoformat(), "expires_at": item.expires_at.isoformat() if item.expires_at else None})
    return {"organization_id": organization_id, "verification_status": verification.status if verification else "not_submitted",
            "active_credentials": active, "trust_model": "factual_status_and_credentials_no_composite_score"}

@app.post("/v1/business/purchase-requests", status_code=201)
def create_business_purchase_request(payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    connection = db.get(BusinessConnection, payload.get("connection_id")) if isinstance(payload.get("connection_id"), str) else None
    org_id = context["organization_id"]
    if not connection or connection.status != "accepted" or org_id not in (connection.requester_organization_id, connection.target_organization_id):
        raise HTTPException(404, "Accepted business connection not found")
    title, description = payload.get("title"), payload.get("description"); quantity = payload.get("quantity")
    if not isinstance(title, str) or not (3 <= len(title.strip()) <= 200): raise HTTPException(400, "title must contain 3-200 characters")
    if not isinstance(description, str) or not (3 <= len(description.strip()) <= 4000): raise HTTPException(400, "description must contain 3-4000 characters")
    if quantity is not None and (not isinstance(quantity, str) or len(quantity.strip()) > 100): raise HTTPException(400, "quantity must be at most 100 characters")
    supplier = connection.target_organization_id if org_id == connection.requester_organization_id else connection.requester_organization_id
    item = BusinessPurchaseRequest(connection_id=connection.id, buyer_organization_id=org_id, supplier_organization_id=supplier, title=title.strip(), description=description.strip(), quantity=quantity.strip() if quantity else None)
    db.add(item); db.flush()
    audit(db, org_id, context["user"].id, "business.purchase_request_created", "business_purchase_request", item.id)
    enqueue_webhook_event(db, [org_id, supplier], "commerce.purchase_request.created",
        {"purchase_request_id": item.id, "buyer_organization_id": org_id, "supplier_organization_id": supplier})
    db.commit(); db.refresh(item); return {"id": item.id, "status": item.status, "supplier_organization_id": supplier}

@app.get("/v1/business/purchase-requests")
def list_business_purchase_requests(context=Depends(require_org), db: Session = Depends(get_db)):
    org_id=context["organization_id"]
    rows=db.scalars(select(BusinessPurchaseRequest).where((BusinessPurchaseRequest.buyer_organization_id==org_id)|(BusinessPurchaseRequest.supplier_organization_id==org_id)).order_by(BusinessPurchaseRequest.created_at.desc()).limit(100)).all()
    return [{"id":x.id,"buyer_organization_id":x.buyer_organization_id,"supplier_organization_id":x.supplier_organization_id,"title":x.title,"description":x.description,"quantity":x.quantity,"status":x.status,"created_at":x.created_at.isoformat()} for x in rows]

@app.post("/v1/business/purchase-requests/{request_id}/quotes", status_code=201)
def submit_business_quote(request_id: str, payload: dict, context=Depends(require_org), db: Session=Depends(get_db)):
    item=db.get(BusinessPurchaseRequest,request_id); org_id=context["organization_id"]
    if not item or item.supplier_organization_id!=org_id: raise HTTPException(404,"Purchase request not found")
    if item.status!="open": raise HTTPException(409,"Purchase request is no longer open")
    amount=payload.get("amount_minor"); currency=payload.get("currency"); terms=payload.get("terms"); validity=payload.get("validity_days",14)
    if not isinstance(amount,int) or isinstance(amount,bool) or amount<=0 or amount>9_000_000_000_000_000: raise HTTPException(400,"amount_minor must be a positive integer")
    if not isinstance(currency,str) or len(currency)!=3 or not (currency.isascii() and currency.isalpha()): raise HTTPException(400,"currency must be a three-letter code")
    if not isinstance(validity,int) or not 1<=validity<=90: raise HTTPException(400,"validity_days must be between 1 and 90")
    if terms is not None and (not isinstance(terms,str) or len(terms.strip())>2000): raise HTTPException(400,"terms must be at most 2000 characters")
    quote=BusinessQuote(purchase_request_id=item.id,supplier_organization_id=org_id,amount_minor=amount,currency=currency.upper(),terms=terms.strip() if terms else None,validity_days=validity)
    db.add(quote); db.flush()
    audit(db,org_id,context["user"].id,"business.quote_submitted","business_quote",quote.id)
    enqueue_webhook_event(db, [org_id, item.buyer_organization_id], "commerce.quote.submitted",
        {"quote_id": quote.id, "purchase_request_id": item.id, "supplier_organization_id": org_id})
    db.commit(); db.refresh(quote)
    return {"id":quote.id,"purchase_request_id":item.id,"amount_minor":quote.amount_minor,"currency":quote.currency,"status":quote.status}

@app.get("/v1/business/quotes")
def list_business_quotes(context=Depends(require_org), db: Session=Depends(get_db)):
    org_id=context["organization_id"]
    rows=db.scalars(select(BusinessQuote).join(BusinessPurchaseRequest, BusinessQuote.purchase_request_id==BusinessPurchaseRequest.id).where((BusinessQuote.supplier_organization_id==org_id)|(BusinessPurchaseRequest.buyer_organization_id==org_id)).order_by(BusinessQuote.created_at.desc()).limit(100)).all()
    return [{"id":q.id,"purchase_request_id":q.purchase_request_id,"supplier_organization_id":q.supplier_organization_id,"amount_minor":q.amount_minor,"currency":q.currency,"terms":q.terms,"validity_days":q.validity_days,"status":q.status,"created_at":q.created_at.isoformat(),"expires_at":(q.created_at + timedelta(days=q.validity_days)).isoformat()} for q in rows]

@app.post("/v1/business/purchase-requests/{request_id}/close")
def close_business_purchase_request(request_id: str, context=Depends(require_org), db: Session=Depends(get_db)):
    item = db.get(BusinessPurchaseRequest, request_id)
    org_id = context["organization_id"]
    if not item or item.buyer_organization_id != org_id:
        raise HTTPException(404, "Purchase request not found")
    if item.status != "open":
        raise HTTPException(409, "Only open purchase requests can be closed")
    item.status = "cancelled"
    db.flush()
    quotes = db.scalars(select(BusinessQuote).where(BusinessQuote.purchase_request_id == item.id,
        BusinessQuote.status == "submitted")).all()
    for quote in quotes:
        quote.status = "rejected"
    audit(db, org_id, context["user"].id, "business.purchase_request_closed", "business_purchase_request", item.id)
    enqueue_webhook_event(db, [item.buyer_organization_id, item.supplier_organization_id],
        "commerce.purchase_request.closed", {"purchase_request_id": item.id})
    db.commit()
    return {"id": item.id, "status": item.status, "quotes_closed": len(quotes)}

@app.post("/v1/business/quotes/{quote_id}/decision")
def decide_business_quote(quote_id: str, payload: dict, context=Depends(require_org), db: Session=Depends(get_db)):
    quote = db.get(BusinessQuote, quote_id)
    org_id = context["organization_id"]
    if not quote:
        raise HTTPException(404, "Quote not found")
    item = db.get(BusinessPurchaseRequest, quote.purchase_request_id)
    decision = payload.get("decision")
    if decision == "withdraw" and org_id == quote.supplier_organization_id:
        if quote.status != "submitted":
            raise HTTPException(409, "Only submitted quotes can be withdrawn")
        quote.status = "withdrawn"
        action = "business.quote_withdrawn"
    elif decision == "reject" and org_id == item.buyer_organization_id:
        if quote.status != "submitted" or item.status != "open":
            raise HTTPException(409, "Quote is no longer available for rejection")
        quote.status = "rejected"
        action = "business.quote_rejected"
    else:
        raise HTTPException(404, "Quote not found")
    audit(db, org_id, context["user"].id, action, "business_quote", quote.id)
    db.commit()
    return {"id": quote.id, "status": quote.status}

@app.post("/v1/business/quotes/{quote_id}/accept", status_code=201)
def accept_business_quote(quote_id: str, context=Depends(require_org), db: Session=Depends(get_db)):
    quote=db.get(BusinessQuote,quote_id); org_id=context["organization_id"]
    if not quote: raise HTTPException(404,"Quote not found")
    item=db.get(BusinessPurchaseRequest,quote.purchase_request_id)
    if item.buyer_organization_id!=org_id: raise HTTPException(404,"Quote not found")
    if quote.status!="submitted" or item.status!="open": raise HTTPException(409,"Quote or purchase request is no longer available")
    expiry = quote.created_at + timedelta(days=quote.validity_days)
    if expiry.tzinfo is None: expiry = expiry.replace(tzinfo=timezone.utc)
    if expiry <= datetime.now(timezone.utc):
        quote.status = "expired"
        db.commit()
        raise HTTPException(409, "Quote has expired")
    quote.status="accepted"; item.status="awarded"
    competing = db.scalars(select(BusinessQuote).where(BusinessQuote.purchase_request_id == item.id,
        BusinessQuote.id != quote.id, BusinessQuote.status == "submitted")).all()
    for other_quote in competing:
        other_quote.status = "rejected"
    transaction=BusinessTransaction(purchase_request_id=item.id,quote_id=quote.id,buyer_organization_id=item.buyer_organization_id,supplier_organization_id=item.supplier_organization_id,amount_minor=quote.amount_minor,currency=quote.currency,status="accepted")
    db.add(transaction); db.flush()
    audit(db,org_id,context["user"].id,"business.quote_accepted","business_transaction",transaction.id)
    enqueue_webhook_event(db, [item.buyer_organization_id, item.supplier_organization_id],
        "commerce.transaction.updated", {"transaction_id": transaction.id, "status": transaction.status})
    db.commit(); db.refresh(transaction)
    return {"id":transaction.id,"status":transaction.status,"amount_minor":transaction.amount_minor,"currency":transaction.currency,"funds_held_by_imperionx":False}

@app.get("/v1/business/transactions")
def list_business_transactions(context=Depends(require_org), db: Session=Depends(get_db)):
    org_id=context["organization_id"]
    rows=db.scalars(select(BusinessTransaction).where((BusinessTransaction.buyer_organization_id==org_id)|(BusinessTransaction.supplier_organization_id==org_id)).order_by(BusinessTransaction.created_at.desc()).limit(100)).all()
    return [{"id":t.id,"purchase_request_id":t.purchase_request_id,"buyer_organization_id":t.buyer_organization_id,"supplier_organization_id":t.supplier_organization_id,"amount_minor":t.amount_minor,"currency":t.currency,"status":t.status,"created_at":t.created_at.isoformat()} for t in rows]

@app.patch("/v1/business/transactions/{transaction_id}/status")
def update_business_transaction(transaction_id: str, payload: dict, context=Depends(require_org), db: Session=Depends(get_db)):
    item=db.get(BusinessTransaction,transaction_id); org_id=context["organization_id"]
    if not item or org_id not in (item.buyer_organization_id,item.supplier_organization_id): raise HTTPException(404,"Transaction not found")
    next_status=payload.get("status"); allowed={"accepted","in_progress","completed","cancelled"}
    if next_status not in allowed: raise HTTPException(400,"Invalid transaction status")
    if item.status in ("completed","cancelled"): raise HTTPException(409,"Closed transactions cannot be changed")
    open_dispute=db.scalar(select(BusinessDispute).where(BusinessDispute.transaction_id==transaction_id,BusinessDispute.status=="open"))
    if open_dispute and next_status in ("completed", "cancelled"):
        raise HTTPException(409,"Resolve the open dispute before closing the transaction")
    if next_status=="in_progress" and org_id!=item.supplier_organization_id: raise HTTPException(403,"Only the supplier can mark work in progress")
    if next_status=="completed" and org_id!=item.buyer_organization_id: raise HTTPException(403,"Only the buyer can confirm completion")
    if next_status not in ("in_progress","completed","cancelled"): raise HTTPException(400,"Unsupported status transition")
    if next_status=="completed" and item.status!="in_progress": raise HTTPException(409,"Only in-progress transactions can be completed")
    item.status=next_status; item.updated_at=datetime.now(timezone.utc)
    audit(db,org_id,context["user"].id,f"business.transaction_{next_status}","business_transaction",item.id); db.commit()
    return {"id":item.id,"status":item.status,"updated_at":item.updated_at.isoformat()}


@app.post("/v1/business/transactions/{transaction_id}/fulfillment", status_code=201)
def add_business_fulfillment_event(transaction_id: str, payload: dict, context=Depends(require_org), db: Session=Depends(get_db)):
    org_id=context["organization_id"]
    transaction=db.get(BusinessTransaction, transaction_id)
    if not transaction or transaction.supplier_organization_id != org_id:
        raise HTTPException(404, "Transaction not found")
    if transaction.status != "in_progress":
        raise HTTPException(409, "Fulfillment updates require an in-progress transaction")
    milestone=payload.get("milestone"); note=payload.get("note"); tracking=payload.get("tracking_reference")
    if milestone not in ("prepared", "dispatched", "delivered"):
        raise HTTPException(400, "milestone must be prepared, dispatched or delivered")
    prior=db.scalars(select(BusinessFulfillmentEvent).where(BusinessFulfillmentEvent.transaction_id==transaction_id).order_by(BusinessFulfillmentEvent.created_at.asc())).all()
    sequence=["prepared", "dispatched", "delivered"]
    expected=sequence[len(prior)] if len(prior)<len(sequence) else None
    if milestone != expected:
        raise HTTPException(409, f"Next fulfillment milestone must be {expected or 'none; delivery is already recorded'}")
    if note is not None and (not isinstance(note,str) or len(note.strip())>1000): raise HTTPException(400,"note must be at most 1000 characters")
    if tracking is not None and (not isinstance(tracking,str) or len(tracking.strip())>200): raise HTTPException(400,"tracking_reference must be at most 200 characters")
    event=BusinessFulfillmentEvent(transaction_id=transaction_id,supplier_organization_id=org_id,milestone=milestone,note=note.strip() if note else None,tracking_reference=tracking.strip() if tracking else None)
    db.add(event); audit(db,org_id,context["user"].id,f"business.fulfillment_{milestone}","business_fulfillment_event",event.id)
    db.commit(); db.refresh(event)
    return {"id":event.id,"transaction_id":transaction_id,"milestone":event.milestone,"created_at":event.created_at.isoformat()}

@app.get("/v1/business/transactions/{transaction_id}/fulfillment")
def list_business_fulfillment_events(transaction_id: str, context=Depends(require_org), db: Session=Depends(get_db)):
    org_id=context["organization_id"]
    transaction=db.get(BusinessTransaction,transaction_id)
    if not transaction or org_id not in (transaction.buyer_organization_id,transaction.supplier_organization_id): raise HTTPException(404,"Transaction not found")
    rows=db.scalars(select(BusinessFulfillmentEvent).where(BusinessFulfillmentEvent.transaction_id==transaction_id).order_by(BusinessFulfillmentEvent.created_at.asc())).all()
    return [{"id":x.id,"milestone":x.milestone,"note":x.note,"tracking_reference":x.tracking_reference,"created_at":x.created_at.isoformat()} for x in rows]

@app.post("/v1/business/transactions/{transaction_id}/disputes", status_code=201)
def open_business_dispute(transaction_id: str, payload: dict, context=Depends(require_org), db: Session=Depends(get_db)):
    org_id=context["organization_id"]; transaction=db.get(BusinessTransaction,transaction_id)
    if not transaction or org_id not in (transaction.buyer_organization_id,transaction.supplier_organization_id): raise HTTPException(404,"Transaction not found")
    if transaction.status not in ("accepted","in_progress"): raise HTTPException(409,"Disputes can only be opened before transaction closure")
    existing=db.scalar(select(BusinessDispute).where(BusinessDispute.transaction_id==transaction_id,BusinessDispute.status=="open"))
    if existing: raise HTTPException(409,"An open dispute already exists for this transaction")
    category=payload.get("category"); description=payload.get("description")
    if category not in ("quality","delivery","quantity","payment_terms","communication","other"): raise HTTPException(400,"Invalid dispute category")
    if not isinstance(description,str) or not (10<=len(description.strip())<=3000): raise HTTPException(400,"description must contain 10-3000 characters")
    counterparty=transaction.supplier_organization_id if org_id==transaction.buyer_organization_id else transaction.buyer_organization_id
    dispute=BusinessDispute(transaction_id=transaction_id,opened_by_organization_id=org_id,counterparty_organization_id=counterparty,category=category,description=description.strip())
    db.add(dispute); audit(db,org_id,context["user"].id,"business.dispute_opened","business_dispute",dispute.id); db.commit(); db.refresh(dispute)
    return {"id":dispute.id,"status":dispute.status,"transaction_id":transaction_id}

@app.get("/v1/business/disputes")
def list_business_disputes(context=Depends(require_org), db: Session=Depends(get_db)):
    org_id=context["organization_id"]
    rows=db.scalars(select(BusinessDispute).where((BusinessDispute.opened_by_organization_id==org_id)|(BusinessDispute.counterparty_organization_id==org_id)).order_by(BusinessDispute.created_at.desc()).limit(100)).all()
    return [{"id":x.id,"transaction_id":x.transaction_id,"opened_by_organization_id":x.opened_by_organization_id,"counterparty_organization_id":x.counterparty_organization_id,"category":x.category,"description":x.description,"status":x.status,"resolution_note":x.resolution_note,"created_at":x.created_at.isoformat()} for x in rows]

@app.get("/v1/platform/disputes")
def list_platform_disputes(reviewer=Depends(require_platform_reviewer), db: Session=Depends(get_db)):
    rows=db.scalars(select(BusinessDispute).where(BusinessDispute.status=="open").order_by(BusinessDispute.created_at.asc()).limit(100)).all()
    return [{"id":x.id,"transaction_id":x.transaction_id,"opened_by_organization_id":x.opened_by_organization_id,"counterparty_organization_id":x.counterparty_organization_id,"category":x.category,"description":x.description,"created_at":x.created_at.isoformat()} for x in rows]

@app.post("/v1/platform/disputes/{dispute_id}/decision")
def decide_platform_dispute(dispute_id: str, payload: dict, reviewer=Depends(require_platform_reviewer), db: Session=Depends(get_db)):
    dispute=db.get(BusinessDispute,dispute_id)
    if not dispute or dispute.status!="open": raise HTTPException(404,"Open dispute not found")
    if db.scalar(select(Membership).where(Membership.organization_id.in_([dispute.opened_by_organization_id,dispute.counterparty_organization_id]),Membership.user_id==reviewer.id)):
        raise HTTPException(403,"Reviewers cannot adjudicate a dispute involving their own business")
    decision=payload.get("decision"); note=payload.get("note")
    if decision not in ("resolved_buyer","resolved_supplier","closed_no_action"): raise HTTPException(400,"Invalid dispute decision")
    if not isinstance(note,str) or not (3<=len(note.strip())<=1500): raise HTTPException(400,"A resolution note of 3-1500 characters is required")
    dispute.status=decision; dispute.reviewer_user_id=reviewer.id; dispute.resolution_note=note.strip(); dispute.resolved_at=datetime.now(timezone.utc)
    audit(db,dispute.opened_by_organization_id,reviewer.id,f"business.dispute_{decision}","business_dispute",dispute.id)
    db.commit(); return {"id":dispute.id,"status":dispute.status,"resolved_at":dispute.resolved_at.isoformat()}

@app.post("/v1/business/transactions/{transaction_id}/feedback", status_code=201)
def submit_business_transaction_feedback(transaction_id: str, payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    transaction = db.get(BusinessTransaction, transaction_id)
    if not transaction or org_id not in (transaction.buyer_organization_id, transaction.supplier_organization_id):
        raise HTTPException(404, "Transaction not found")
    if transaction.status != "completed":
        raise HTTPException(409, "Feedback is available only after the buyer confirms transaction completion")
    subject = transaction.supplier_organization_id if org_id == transaction.buyer_organization_id else transaction.buyer_organization_id
    ratings = {}
    for field in ("communication_rating", "quality_rating", "timeliness_rating"):
        value = payload.get(field)
        if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 5:
            raise HTTPException(400, f"{field} must be an integer from 1 to 5")
        ratings[field] = value
    comment = payload.get("comment")
    if comment is not None and (not isinstance(comment, str) or len(comment.strip()) > 1000):
        raise HTTPException(400, "comment must be at most 1000 characters")
    existing = db.scalar(select(BusinessTransactionFeedback).where(
        BusinessTransactionFeedback.transaction_id == transaction_id,
        BusinessTransactionFeedback.reviewer_organization_id == org_id))
    if existing:
        raise HTTPException(409, "This organization has already submitted feedback for the transaction")
    row = BusinessTransactionFeedback(transaction_id=transaction_id, reviewer_organization_id=org_id,
        subject_organization_id=subject, **ratings, comment=comment.strip() if comment else None)
    db.add(row)
    audit(db, org_id, context["user"].id, "business.transaction_feedback_submitted", "business_transaction_feedback", row.id,
          {"subject_organization_id": subject, **ratings})
    db.commit(); db.refresh(row)
    return {"id": row.id, "transaction_id": transaction_id, "subject_organization_id": subject,
            **ratings, "created_at": row.created_at.isoformat()}


@app.post("/v1/business/feedback/{feedback_id}/challenge", status_code=201)
def challenge_business_feedback(feedback_id: str, payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    feedback = db.get(BusinessTransactionFeedback, feedback_id)
    if not feedback or org_id not in (feedback.reviewer_organization_id, feedback.subject_organization_id):
        raise HTTPException(404, "Feedback not found")
    if feedback.moderation_status != "published":
        raise HTTPException(409, "Feedback is already under review or not publicly visible")
    reason = payload.get("reason")
    explanation = payload.get("explanation")
    evidence_reference = payload.get("evidence_reference")
    evidence_sha256 = payload.get("evidence_sha256")
    if reason not in ("transaction_not_genuine", "factual_inaccuracy", "abusive_content", "conflict_of_interest", "other"):
        raise HTTPException(400, "Invalid challenge reason")
    if not isinstance(explanation, str) or not 10 <= len(explanation.strip()) <= 2000:
        raise HTTPException(400, "Explanation must contain 10-2000 characters")
    if evidence_reference is not None and (not isinstance(evidence_reference, str) or not 1 <= len(evidence_reference.strip()) <= 500):
        raise HTTPException(400, "Invalid evidence reference")
    if evidence_sha256 is not None and (not isinstance(evidence_sha256, str) or len(evidence_sha256) != 64 or any(c not in "0123456789abcdefABCDEF" for c in evidence_sha256)):
        raise HTTPException(400, "evidence_sha256 must be a 64-character hexadecimal digest")
    row = BusinessFeedbackChallenge(feedback_id=feedback.id, challenger_organization_id=org_id, reason=reason,
        explanation=explanation.strip(), evidence_reference=evidence_reference.strip() if evidence_reference else None,
        evidence_sha256=evidence_sha256.lower() if evidence_sha256 else None)
    try:
        feedback.moderation_status = "under_review"
        db.add(row)
        audit(db, org_id, context["user"].id, "business.feedback_challenged", "business_feedback_challenge", row.id,
              {"feedback_id": feedback.id, "reason": reason, "evidence_attached": bool(evidence_reference or evidence_sha256)})
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "This organization has already challenged this feedback")
    db.refresh(row)
    return {"id": row.id, "feedback_id": feedback.id, "status": row.status, "created_at": row.created_at.isoformat()}


@app.get("/v1/platform/feedback-challenges")
def list_platform_feedback_challenges(reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    rows = db.scalars(select(BusinessFeedbackChallenge).where(BusinessFeedbackChallenge.status == "pending").order_by(BusinessFeedbackChallenge.created_at.asc()).limit(100)).all()
    result = []
    for row in rows:
        feedback = db.get(BusinessTransactionFeedback, row.feedback_id)
        result.append({"id": row.id, "feedback_id": row.feedback_id, "transaction_id": feedback.transaction_id if feedback else None,
            "reviewer_organization_id": feedback.reviewer_organization_id if feedback else None,
            "subject_organization_id": feedback.subject_organization_id if feedback else None,
            "challenger_organization_id": row.challenger_organization_id, "reason": row.reason, "explanation": row.explanation,
            "evidence_reference": row.evidence_reference, "evidence_sha256": row.evidence_sha256, "created_at": row.created_at.isoformat()})
    return result


@app.post("/v1/platform/feedback-challenges/{challenge_id}/decision")
def decide_platform_feedback_challenge(challenge_id: str, payload: dict, reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    challenge = db.get(BusinessFeedbackChallenge, challenge_id)
    if not challenge or challenge.status != "pending":
        raise HTTPException(404, "Pending feedback challenge not found")
    feedback = db.get(BusinessTransactionFeedback, challenge.feedback_id)
    if not feedback:
        raise HTTPException(404, "Feedback not found")
    if db.scalar(select(Membership).where(Membership.organization_id.in_([feedback.reviewer_organization_id, feedback.subject_organization_id]), Membership.user_id == reviewer.id)):
        raise HTTPException(403, "Reviewers cannot adjudicate feedback involving their own business")
    decision, note = payload.get("decision"), payload.get("note")
    if decision not in ("upheld", "rejected"):
        raise HTTPException(400, "Decision must be upheld or rejected")
    if not isinstance(note, str) or not 3 <= len(note.strip()) <= 1500:
        raise HTTPException(400, "A decision note of 3-1500 characters is required")
    challenge.status = decision
    challenge.reviewer_user_id = reviewer.id
    challenge.decision_note = note.strip()
    challenge.resolved_at = datetime.now(timezone.utc)
    feedback.moderation_status = "hidden" if decision == "upheld" else "published"
    audit(db, challenge.challenger_organization_id, reviewer.id, f"business.feedback_challenge_{decision}", "business_feedback_challenge", challenge.id,
          {"feedback_id": feedback.id, "feedback_moderation_status": feedback.moderation_status})
    db.commit()
    return {"id": challenge.id, "status": challenge.status, "feedback_moderation_status": feedback.moderation_status}


@app.post("/v1/business/feedback-challenges/{challenge_id}/appeal", status_code=201)
def appeal_business_feedback_challenge(challenge_id: str, payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    challenge = db.get(BusinessFeedbackChallenge, challenge_id)
    org_id = context["organization_id"]
    feedback = db.get(BusinessTransactionFeedback, challenge.feedback_id) if challenge else None
    if not challenge or not feedback or org_id not in (feedback.reviewer_organization_id, feedback.subject_organization_id):
        raise HTTPException(404, "Feedback challenge not found")
    if challenge.status not in ("upheld", "rejected") or challenge.appealed_at is not None:
        raise HTTPException(409, "Only a resolved challenge may be appealed once")
    note = payload.get("note")
    if not isinstance(note, str) or not 10 <= len(note.strip()) <= 1500:
        raise HTTPException(400, "Appeal note must contain 10-1500 characters")
    challenge.appeal_note = note.strip()
    challenge.appealed_at = datetime.now(timezone.utc)
    challenge.appeal_status = "pending"
    audit(db, org_id, context["user"].id, "business.feedback_challenge_appealed", "business_feedback_challenge", challenge.id)
    db.commit()
    return {"id": challenge.id, "appeal_status": challenge.appeal_status, "appealed_at": challenge.appealed_at.isoformat()}


@app.get("/v1/platform/feedback-appeals")
def list_platform_feedback_appeals(reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    rows = db.scalars(select(BusinessFeedbackChallenge).where(BusinessFeedbackChallenge.appeal_status == "pending").order_by(BusinessFeedbackChallenge.appealed_at.asc()).limit(100)).all()
    result = []
    for row in rows:
        feedback = db.get(BusinessTransactionFeedback, row.feedback_id)
        result.append({"id": row.id, "feedback_id": row.feedback_id, "reason": row.reason, "appeal_note": row.appeal_note,
            "original_decision": row.status, "reviewer_organization_id": feedback.reviewer_organization_id if feedback else None,
            "subject_organization_id": feedback.subject_organization_id if feedback else None})
    return result


@app.post("/v1/platform/feedback-appeals/{challenge_id}/decision")
def decide_platform_feedback_appeal(challenge_id: str, payload: dict, reviewer=Depends(require_platform_reviewer), db: Session = Depends(get_db)):
    challenge = db.get(BusinessFeedbackChallenge, challenge_id)
    if not challenge or challenge.appeal_status != "pending":
        raise HTTPException(404, "Pending appeal not found")
    feedback = db.get(BusinessTransactionFeedback, challenge.feedback_id)
    if not feedback:
        raise HTTPException(404, "Feedback not found")
    if db.scalar(select(Membership).where(Membership.organization_id.in_([feedback.reviewer_organization_id, feedback.subject_organization_id]), Membership.user_id == reviewer.id)):
        raise HTTPException(403, "Reviewers cannot adjudicate feedback involving their own business")
    if reviewer.id == challenge.reviewer_user_id:
        raise HTTPException(403, "Appeals must be reviewed by a different platform reviewer")
    decision, note = payload.get("decision"), payload.get("note")
    if decision not in ("affirm", "overturn"):
        raise HTTPException(400, "Appeal decision must be affirm or overturn")
    if not isinstance(note, str) or not 3 <= len(note.strip()) <= 1500:
        raise HTTPException(400, "An appeal decision note of 3-1500 characters is required")
    challenge.appeal_status = decision
    challenge.appeal_reviewer_user_id = reviewer.id
    challenge.appeal_decision_note = note.strip()
    if decision == "overturn":
        challenge.status = "rejected" if challenge.status == "upheld" else "upheld"
        feedback.moderation_status = "published" if challenge.status == "rejected" else "hidden"
    audit(db, challenge.challenger_organization_id, reviewer.id, f"business.feedback_appeal_{decision}", "business_feedback_challenge", challenge.id,
          {"feedback_moderation_status": feedback.moderation_status})
    db.commit()
    return {"id": challenge.id, "appeal_status": challenge.appeal_status, "challenge_status": challenge.status,
            "feedback_moderation_status": feedback.moderation_status}


@app.get("/v1/business/organizations/{organization_id}/reputation")
def get_business_reputation(organization_id: str, context=Depends(require_org), db: Session = Depends(get_db)):
    viewer_id = context["organization_id"]
    if viewer_id == organization_id:
        raise HTTPException(400, "Use organization performance insights for your own organization")
    connection = db.scalar(select(BusinessConnection).where(
        BusinessConnection.status == "accepted",
        ((BusinessConnection.requester_organization_id == viewer_id) & (BusinessConnection.target_organization_id == organization_id)) |
        ((BusinessConnection.requester_organization_id == organization_id) & (BusinessConnection.target_organization_id == viewer_id))))
    if not connection:
        raise HTTPException(404, "Connected organization not found")
    rows = db.scalars(select(BusinessTransactionFeedback).where(
        BusinessTransactionFeedback.subject_organization_id == organization_id, BusinessTransactionFeedback.moderation_status == "published")).all()
    dimensions = ("communication_rating", "quality_rating", "timeliness_rating")
    summary = {}
    for field in dimensions:
        values = [getattr(row, field) for row in rows]
        summary[field] = {"average": round(sum(values) / len(values), 2) if values else None, "responses": len(values)}
    completed = db.scalar(select(func.count(BusinessTransaction.id)).where(
        BusinessTransaction.status == "completed",
        (BusinessTransaction.buyer_organization_id == organization_id) | (BusinessTransaction.supplier_organization_id == organization_id))) or 0
    # Comments and reviewer identities are never disclosed in the network reputation view.
    return {"organization_id": organization_id, "completed_transactions": completed,
            "verified_transaction_feedback_count": len(rows), "ratings": summary,
            "methodology": "transaction-linked bilateral feedback; dimension averages only; no composite score"}


@app.get("/v1/business/commerce/insights")
def business_commerce_insights(days: int=90, context=Depends(require_org), db: Session=Depends(get_db)):
    if not 1<=days<=365: raise HTTPException(400,"days must be between 1 and 365")
    org_id=context["organization_id"]; since=datetime.now(timezone.utc)-timedelta(days=days)
    rows=db.scalars(select(BusinessTransaction).where(((BusinessTransaction.buyer_organization_id==org_id)|(BusinessTransaction.supplier_organization_id==org_id)),BusinessTransaction.created_at>=since)).all()
    grouped={}
    for row in rows:
        bucket=grouped.setdefault(row.currency,{"currency":row.currency,"transactions":0,"volume_minor":0,"completed":0,"cancelled":0,"in_progress":0})
        bucket["transactions"]+=1; bucket["volume_minor"]+=row.amount_minor
        if row.status=="completed": bucket["completed"]+=1
        elif row.status=="cancelled": bucket["cancelled"]+=1
        elif row.status=="in_progress": bucket["in_progress"]+=1
    supplier_rows=[x for x in rows if x.supplier_organization_id==org_id]
    buyer_rows=[x for x in rows if x.buyer_organization_id==org_id]
    completed_supplier=sum(x.status=="completed" for x in supplier_rows)
    supplier_rate=round(100*completed_supplier/len(supplier_rows),2) if supplier_rows else 0.0
    return {"period_days":days,"transactions_by_currency":list(grouped.values()),"buyer":{"purchase_count":len(buyer_rows),"open_purchases":sum(x.status in ("accepted","in_progress") for x in buyer_rows)},"supplier":{"awarded_orders":len(supplier_rows),"completed_orders":completed_supplier,"completion_rate_percent":supplier_rate},"disputes_open":db.scalar(select(func.count()).select_from(BusinessDispute).where(BusinessDispute.status=="open",(BusinessDispute.opened_by_organization_id==org_id)|(BusinessDispute.counterparty_organization_id==org_id))) or 0,"currency_note":"Amounts are grouped by currency. No foreign-exchange conversion is performed."}

@app.put("/v1/business/network-discovery")
def update_network_discovery(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    """Explicitly opt a published business into second-degree network discovery."""
    enabled = payload.get("enabled")
    if not isinstance(enabled, bool):
        raise HTTPException(400, "enabled must be a boolean")
    org_id = context["organization_id"]
    profile = db.get(BusinessPublicProfile, org_id)
    if not profile:
        raise HTTPException(409, "Configure a business profile before changing network discovery")
    if enabled and not profile.is_published:
        raise HTTPException(409, "Publish the business profile before enabling network discovery")
    profile.network_discoverable = enabled
    audit(db, org_id, context["user"].id, "business.network_discovery_updated",
          "business_public_profile", org_id, {"network_discoverable": enabled})
    db.commit()
    return {"organization_id": org_id, "network_discoverable": enabled,
            "note": "Only basic published business identity may appear in second-degree discovery."}


@app.get("/v1/network/trust-graph")
def get_network_trust_graph(depth: int = 1, limit: int = 100,
                            context=Depends(require_org), db: Session = Depends(get_db)):
    """Return direct relationships and opt-in second-degree discovery without a trust score."""
    if depth not in (1, 2):
        raise HTTPException(400, "depth must be 1 or 2")
    if limit < 1 or limit > 200:
        raise HTTPException(400, "limit must be between 1 and 200")
    org_id = context["organization_id"]
    direct_connections = db.scalars(select(BusinessConnection).where(
        BusinessConnection.status == "accepted",
        (BusinessConnection.requester_organization_id == org_id) |
        (BusinessConnection.target_organization_id == org_id)
    ).order_by(BusinessConnection.created_at.desc()).limit(limit)).all()
    direct_ids = set()
    nodes, edges = [], []
    for connection in direct_connections:
        other_id = connection.target_organization_id if connection.requester_organization_id == org_id else connection.requester_organization_id
        direct_ids.add(other_id)
        other = db.get(Organization, other_id)
        if not other:
            continue
        verification = db.get(BusinessVerification, other_id)
        active_credentials = db.scalar(select(func.count()).select_from(BusinessTrustCredential).where(
            BusinessTrustCredential.organization_id == other_id,
            BusinessTrustCredential.revoked_at.is_(None),
            (BusinessTrustCredential.expires_at.is_(None) | (BusinessTrustCredential.expires_at > datetime.now(timezone.utc)))
        )) or 0
        bilateral_transactions = db.scalar(select(func.count()).select_from(BusinessTransaction).where(
            BusinessTransaction.status == "completed",
            ((BusinessTransaction.buyer_organization_id == org_id) & (BusinessTransaction.supplier_organization_id == other_id)) |
            ((BusinessTransaction.buyer_organization_id == other_id) & (BusinessTransaction.supplier_organization_id == org_id))
        )) or 0
        nodes.append({"organization_id": other.id, "name": other.name, "industry": other.industry,
                      "country_code": other.country_code, "relationship": "direct",
                      "verification_status": verification.status if verification else "not_submitted",
                      "active_trust_credentials": active_credentials,
                      "completed_transactions_between_us": bilateral_transactions})
        edges.append({"source": org_id, "target": other_id, "relationship": "accepted_connection",
                      "connection_id": connection.id})

    discovered = []
    if depth == 2 and direct_ids and len(nodes) < limit:
        second_hop_connections = db.scalars(select(BusinessConnection).where(
            BusinessConnection.status == "accepted",
            (BusinessConnection.requester_organization_id.in_(direct_ids)) |
            (BusinessConnection.target_organization_id.in_(direct_ids))
        ).order_by(BusinessConnection.created_at.desc()).limit(1000)).all()
        mutual_counts = {}
        for edge in second_hop_connections:
            left, right = edge.requester_organization_id, edge.target_organization_id
            if left in direct_ids and right != org_id and right not in direct_ids:
                mutual_counts[right] = mutual_counts.get(right, 0) + 1
            if right in direct_ids and left != org_id and left not in direct_ids:
                mutual_counts[left] = mutual_counts.get(left, 0) + 1
        for candidate_id, mutual_count in sorted(mutual_counts.items(), key=lambda item: (-item[1], item[0])):
            if len(nodes) >= limit:
                break
            candidate_profile = db.get(BusinessPublicProfile, candidate_id)
            if not candidate_profile or not candidate_profile.is_published or not candidate_profile.network_discoverable:
                continue
            candidate = db.get(Organization, candidate_id)
            if not candidate:
                continue
            nodes.append({"organization_id": candidate.id, "name": candidate.name,
                          "industry": candidate.industry, "country_code": candidate.country_code,
                          "public_slug": candidate_profile.slug, "tagline": candidate_profile.tagline,
                          "relationship": "second_degree", "mutual_connection_count": mutual_count})
            edges.append({"source": org_id, "target": candidate.id,
                          "relationship": "opt_in_network_discovery",
                          "mutual_connection_count": mutual_count})
            discovered.append(candidate.id)
    return {"api_version": "5.0.0", "organization_id": org_id, "depth": depth,
            "nodes": nodes, "edges": edges,
            "summary": {"direct_connections": len(direct_ids),
                        "second_degree_discoveries": len(discovered),
                        "discovery_requires_opt_in": True,
                        "composite_trust_score": None},
            "privacy": "Second-degree identities appear only when their published business has explicitly enabled network discovery. Mutual connection identities and private relationship paths are never disclosed."}


@app.get("/v1/network/overview")
def universal_network_overview(context=Depends(require_org), db: Session = Depends(get_db)):
    """Unified, tenant-scoped snapshot of network identity, relationships and commerce."""
    org_id = context["organization_id"]
    organization = db.get(Organization, org_id)
    profile = db.get(BusinessPublicProfile, org_id)
    verification = db.get(BusinessVerification, org_id)
    connections = db.scalars(select(BusinessConnection).where(
        (BusinessConnection.requester_organization_id == org_id) |
        (BusinessConnection.target_organization_id == org_id)
    ).order_by(BusinessConnection.created_at.desc()).limit(200)).all()
    accepted = [c for c in connections if c.status == "accepted"]
    pending_in = sum(c.status == "pending" and c.target_organization_id == org_id for c in connections)
    pending_out = sum(c.status == "pending" and c.requester_organization_id == org_id for c in connections)
    graph_nodes = []
    graph_edges = []
    for connection in accepted:
        other_id = connection.target_organization_id if connection.requester_organization_id == org_id else connection.requester_organization_id
        other = db.get(Organization, other_id)
        if not other:
            continue
        node = {"organization_id": other.id, "name": other.name, "industry": other.industry,
                "country_code": other.country_code, "connection_status": "accepted"}
        other_profile = db.get(BusinessPublicProfile, other_id)
        if other_profile and other_profile.is_published:
            node["public_slug"] = other_profile.slug
            node["tagline"] = other_profile.tagline
        graph_nodes.append(node)
        graph_edges.append({"connection_id": connection.id, "source": org_id,
                            "target": other_id, "status": "accepted",
                            "shared_fields": connection.shared_fields or []})
    purchase_count = db.scalar(select(func.count()).select_from(BusinessPurchaseRequest).where(
        (BusinessPurchaseRequest.buyer_organization_id == org_id) |
        (BusinessPurchaseRequest.supplier_organization_id == org_id))) or 0
    transaction_count = db.scalar(select(func.count()).select_from(BusinessTransaction).where(
        (BusinessTransaction.buyer_organization_id == org_id) |
        (BusinessTransaction.supplier_organization_id == org_id))) or 0
    open_disputes = db.scalar(select(func.count()).select_from(BusinessDispute).where(
        BusinessDispute.status == "open",
        (BusinessDispute.opened_by_organization_id == org_id) |
        (BusinessDispute.counterparty_organization_id == org_id))) or 0
    referral_count = db.scalar(select(func.count()).select_from(BusinessReferral).where(
        (BusinessReferral.referrer_organization_id == org_id) |
        (BusinessReferral.referred_organization_id == org_id))) or 0
    return {
        "api_version": "5.0.0",
        "business": {"organization_id": org_id, "name": organization.name if organization else None,
                     "industry": organization.industry if organization else None,
                     "country_code": organization.country_code if organization else None,
                     "profile_published": bool(profile and profile.is_published),
                     "profile_slug": profile.slug if profile and profile.is_published else None,
                     "verification_status": verification.status if verification else "not_submitted"},
        "network": {"accepted_connections": len(accepted), "pending_incoming": pending_in,
                    "pending_outgoing": pending_out, "referrals": referral_count,
                    "nodes": graph_nodes, "edges": graph_edges},
        "commerce": {"purchase_requests": purchase_count, "transactions": transaction_count,
                     "open_disputes": open_disputes,
                     "funds_held_by_platform": False,
                     "currency_conversion_performed": False},
        "scope": "This overview includes only this organization's records and accepted counterparties' basic business identity. Private contact data and unshared profile fields are excluded."
    }


# Integration platform: credentials are opaque, hashed at rest, scoped, and shown only once.
INTEGRATION_SCOPES = {"network:read", "commerce:read"}
WEBHOOK_EVENTS = {"network.connection.accepted", "commerce.purchase_request.created", "commerce.purchase_request.closed", "commerce.quote.submitted", "commerce.transaction.updated"}

def enqueue_webhook_event(db: Session, organization_ids: list[str], event_type: str, data: dict, event_id: str | None = None):
    """Persist a minimal, signed event for every matching active tenant subscription.

    Called in the same DB transaction as the domain change: event and business
    record therefore commit or roll back together. No outbound network I/O occurs.
    """
    event_id = event_id or str(uuid4())
    created_at = datetime.now(timezone.utc).isoformat()
    event = {"id": event_id, "type": event_type, "created_at": created_at, "data": data}
    body = json.dumps(event, sort_keys=True, separators=(",", ":"))
    for org_id in set(organization_ids):
        subscriptions = db.scalars(select(WebhookSubscription).where(
            WebhookSubscription.organization_id == org_id,
            WebhookSubscription.active.is_(True))).all()
        for subscription in subscriptions:
            if event_type not in (subscription.events or []):
                continue
            idem = f"{event_id}:{subscription.id}"
            exists = db.scalar(select(WebhookDelivery.id).where(
                WebhookDelivery.subscription_id == subscription.id,
                WebhookDelivery.idempotency_key == idem))
            if exists:
                continue
            secret = decrypt_mfa_secret(subscription.secret_encrypted, settings.mfa_encryption_key)
            signature = "sha256=" + hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
            db.add(WebhookDelivery(subscription_id=subscription.id, organization_id=org_id,
                event_type=event_type, idempotency_key=idem, payload=event, signature=signature, status="queued"))


def _credential_view(row):
    return {"id": row.id, "name": row.name, "key_prefix": row.key_prefix, "scopes": row.scopes, "expires_at": row.expires_at, "revoked_at": row.revoked_at, "last_used_at": row.last_used_at, "created_at": row.created_at}

def require_integration_key(x_api_key: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not x_api_key or not x_api_key.startswith("ixx_live_"):
        raise HTTPException(401, "A valid X-API-Key is required")
    row = db.scalar(select(IntegrationCredential).where(IntegrationCredential.key_hash == hashlib.sha256(x_api_key.encode()).hexdigest()))
    now = datetime.now(timezone.utc)
    expiry = row.expires_at.replace(tzinfo=timezone.utc) if row and row.expires_at.tzinfo is None else (row.expires_at if row else now)
    if not row or row.revoked_at is not None or expiry <= now:
        raise HTTPException(401, "Integration credential is invalid, expired or revoked")
    row.last_used_at = now
    db.commit()
    return {"organization_id": row.organization_id, "scopes": row.scopes, "credential_id": row.id, "db": db}

def require_integration_scope(scope: str):
    def dependency(context=Depends(require_integration_key)):
        if scope not in context["scopes"]:
            raise HTTPException(403, "Integration credential lacks the required scope")
        return context
    return dependency

@app.post("/v1/integrations/credentials", status_code=201)
def create_integration_credential(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    name = str(payload.get("name", "")).strip()
    scopes = payload.get("scopes", [])
    days = payload.get("expires_in_days", 90)
    if not name or len(name) > 120 or not isinstance(scopes, list) or not scopes or len(scopes) > len(INTEGRATION_SCOPES) or any(not isinstance(x, str) or x not in INTEGRATION_SCOPES for x in scopes) or len(set(scopes)) != len(scopes):
        raise HTTPException(400, "Provide a name and unique supported scopes")
    if not isinstance(days, int) or isinstance(days, bool) or days < 1 or days > 365:
        raise HTTPException(400, "Credential expiry must be between 1 and 365 days")
    raw = "ixx_live_" + secrets.token_urlsafe(32)
    row = IntegrationCredential(organization_id=context["organization_id"], name=name, key_prefix=raw[:16], key_hash=hashlib.sha256(raw.encode()).hexdigest(), scopes=scopes, expires_at=datetime.now(timezone.utc)+timedelta(days=days), created_by_user_id=context["user"].id)
    db.add(row); db.flush(); audit(db, context["organization_id"], context["user"].id, "integration.credential.created", "integration_credential", row.id, {"scopes": scopes})
    db.commit(); db.refresh(row)
    return {**_credential_view(row), "api_key": raw, "warning": "Copy this key now. It cannot be retrieved again."}

@app.get("/v1/integrations/credentials")
def list_integration_credentials(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    rows = db.scalars(select(IntegrationCredential).where(IntegrationCredential.organization_id == context["organization_id"]).order_by(IntegrationCredential.created_at.desc())).all()
    return [_credential_view(x) for x in rows]

@app.post("/v1/integrations/credentials/{credential_id}/revoke")
def revoke_integration_credential(credential_id: str, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    row = db.scalar(select(IntegrationCredential).where(IntegrationCredential.id == credential_id, IntegrationCredential.organization_id == context["organization_id"]))
    if not row: raise HTTPException(404, "Integration credential not found")
    if row.revoked_at is not None: raise HTTPException(409, "Credential is already revoked")
    row.revoked_at = datetime.now(timezone.utc); audit(db, context["organization_id"], context["user"].id, "integration.credential.revoked", "integration_credential", row.id); db.commit()
    return {"id": row.id, "status": "revoked"}

@app.get("/v1/integrations/network/overview")
def integration_network_overview(context=Depends(require_integration_scope("network:read")), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    profile = db.get(BusinessPublicProfile, org_id)
    accepted = db.scalars(select(BusinessConnection).where(BusinessConnection.status == "accepted", (BusinessConnection.requester_organization_id == org_id) | (BusinessConnection.target_organization_id == org_id))).all()
    return {"organization_id": org_id, "profile": {"published": bool(profile and profile.is_published), "slug": profile.slug if profile and profile.is_published else None}, "accepted_connections": len(accepted), "api_version": "5.0.0"}

@app.get("/v1/integrations/commerce/summary")
def integration_commerce_summary(context=Depends(require_integration_scope("commerce:read")), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    purchases = db.scalars(select(BusinessPurchaseRequest).where(BusinessPurchaseRequest.buyer_organization_id == org_id)).all()
    supplied = db.scalars(select(BusinessTransaction).where(BusinessTransaction.supplier_organization_id == org_id)).all()
    bought = db.scalars(select(BusinessTransaction).where(BusinessTransaction.buyer_organization_id == org_id)).all()
    return {"organization_id": org_id, "purchase_requests": len(purchases), "transactions_as_buyer": len(bought), "transactions_as_supplier": len(supplied), "open_disputes": db.scalar(select(func.count(BusinessDispute.id)).where((BusinessDispute.opened_by_organization_id == org_id) | (BusinessDispute.counterparty_organization_id == org_id), BusinessDispute.status == "open")) or 0, "funds_held_by_platform": False, "currency_conversion_performed": False}

@app.post("/v1/integrations/webhooks", status_code=201)
def create_webhook_subscription(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    name = str(payload.get("name", "")).strip(); url = str(payload.get("endpoint_url", "")).strip(); events = payload.get("events", [])
    from urllib.parse import urlparse
    try:
        parsed = urlparse(url)
        parsed_port = parsed.port
    except ValueError:
        raise HTTPException(400, "Invalid webhook endpoint URL")
    active_count = db.scalar(select(func.count(WebhookSubscription.id)).where(
        WebhookSubscription.organization_id == context["organization_id"],
        WebhookSubscription.active.is_(True))) or 0
    if active_count >= 10:
        raise HTTPException(429, "Organization webhook subscription limit reached (10 active)")
    if not name or len(name) > 120 or parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed_port not in (None, 443) or parsed.fragment or parsed.hostname.lower() in {"localhost", "localhost.localdomain"} or parsed.hostname.lower().endswith((".local", ".internal", ".localhost")):
        raise HTTPException(400, "Webhook endpoint must be a public HTTPS URL on the default port")
    try:
        ip = ipaddress.ip_address(parsed.hostname.strip("[]"))
        if not ip.is_global:
            raise HTTPException(400, "Webhook endpoint must not target a private or reserved IP address")
    except ValueError:
        if ":" in parsed.hostname or not all(part and len(part) <= 63 for part in parsed.hostname.split(".")):
            raise HTTPException(400, "Invalid webhook hostname")
    if not isinstance(events, list) or not events or len(events) > len(WEBHOOK_EVENTS) or any(not isinstance(x, str) or x not in WEBHOOK_EVENTS for x in events) or len(set(events)) != len(events):
        raise HTTPException(400, "Select supported unique webhook event types")
    if not settings.mfa_encryption_key: raise HTTPException(503, "Webhook encryption key is not configured")
    secret = secrets.token_urlsafe(32)
    row = WebhookSubscription(organization_id=context["organization_id"], name=name, endpoint_url=url, events=events, secret_encrypted=encrypt_mfa_secret(secret, settings.mfa_encryption_key), created_by_user_id=context["user"].id)
    db.add(row); db.flush(); audit(db, context["organization_id"], context["user"].id, "integration.webhook.created", "webhook_subscription", row.id, {"events": events}); db.commit(); db.refresh(row)
    return {"id": row.id, "name": row.name, "endpoint_url": row.endpoint_url, "events": row.events, "active": row.active, "signing_secret": secret, "warning": "Signing secret is shown once. Delivery remains queued until a secured delivery worker is deployed."}

@app.get("/v1/integrations/webhooks")
def list_webhook_subscriptions(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    rows = db.scalars(select(WebhookSubscription).where(WebhookSubscription.organization_id == context["organization_id"]).order_by(WebhookSubscription.created_at.desc())).all()
    return [{"id": x.id, "name": x.name, "endpoint_url": x.endpoint_url, "events": x.events, "active": x.active, "created_at": x.created_at, "revoked_at": x.revoked_at} for x in rows]

@app.post("/v1/integrations/webhooks/{subscription_id}/revoke")
def revoke_webhook_subscription(subscription_id: str, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    row = db.scalar(select(WebhookSubscription).where(WebhookSubscription.id == subscription_id, WebhookSubscription.organization_id == context["organization_id"]))
    if not row: raise HTTPException(404, "Webhook subscription not found")
    if not row.active: raise HTTPException(409, "Webhook subscription is already inactive")
    row.active = False; row.revoked_at = datetime.now(timezone.utc); audit(db, context["organization_id"], context["user"].id, "integration.webhook.revoked", "webhook_subscription", row.id); db.commit()
    return {"id": row.id, "status": "revoked"}

@app.post("/v1/integrations/webhooks/{subscription_id}/test-event", status_code=202)
def queue_webhook_test_event(subscription_id: str, payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    row = db.scalar(select(WebhookSubscription).where(WebhookSubscription.id == subscription_id, WebhookSubscription.organization_id == context["organization_id"], WebhookSubscription.active.is_(True)))
    if not row: raise HTTPException(404, "Active webhook subscription not found")
    event_type = str(payload.get("event_type", ""))
    if event_type not in row.events: raise HTTPException(400, "Event type is not subscribed")
    idem = str(payload.get("idempotency_key", "")).strip() or str(uuid4())
    if len(idem) > 160: raise HTTPException(400, "Idempotency key is too long")
    existing = db.scalar(select(WebhookDelivery).where(WebhookDelivery.subscription_id == row.id, WebhookDelivery.idempotency_key == idem))
    if existing: return {"id": existing.id, "status": existing.status, "duplicate": True}
    event = {"id": str(uuid4()), "type": event_type, "created_at": datetime.now(timezone.utc).isoformat(), "data": {"test": True, "organization_id": context["organization_id"]}}
    secret = decrypt_mfa_secret(row.secret_encrypted, settings.mfa_encryption_key)
    body = json.dumps(event, sort_keys=True, separators=(",", ":"))
    signature = "sha256=" + hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
    delivery = WebhookDelivery(subscription_id=row.id, organization_id=context["organization_id"], event_type=event_type, idempotency_key=idem, payload=event, signature=signature, status="queued")
    db.add(delivery)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        existing = db.scalar(select(WebhookDelivery).where(WebhookDelivery.subscription_id == row.id, WebhookDelivery.idempotency_key == idem))
        if existing: return {"id": existing.id, "status": existing.status, "duplicate": True}
        raise HTTPException(409, "Webhook event could not be queued")
    audit(db, context["organization_id"], context["user"].id, "integration.webhook.event_queued", "webhook_delivery", delivery.id, {"event_type": event_type}); db.commit()
    return {"id": delivery.id, "status": "queued", "signature": signature, "delivery_enabled": bool(settings.webhook_delivery_enabled), "note": "Persisted to the delivery queue; outbound delivery is performed only by the separately deployed worker."}

@app.post("/v1/integrations/webhooks/deliveries/{delivery_id}/replay", status_code=202)
def replay_webhook_delivery(delivery_id: str, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    row = db.scalar(select(WebhookDelivery).where(
        WebhookDelivery.id == delivery_id,
        WebhookDelivery.organization_id == context["organization_id"]))
    if not row:
        raise HTTPException(404, "Webhook delivery not found")
    if row.status != "dead_lettered":
        raise HTTPException(409, "Only dead-lettered deliveries can be replayed")
    subscription = db.scalar(select(WebhookSubscription).where(
        WebhookSubscription.id == row.subscription_id,
        WebhookSubscription.organization_id == context["organization_id"],
        WebhookSubscription.active.is_(True)))
    if not subscription:
        raise HTTPException(409, "Webhook subscription is inactive")
    row.status = "queued"
    row.attempts = 0
    row.last_error = None
    row.response_status = None
    row.dead_lettered_at = None
    row.next_attempt_at = None
    audit(db, context["organization_id"], context["user"].id,
          "integration.webhook.delivery_replayed", "webhook_delivery", row.id)
    db.commit()
    return {"id": row.id, "status": row.status, "replayed": True}

@app.get("/v1/integrations/webhooks/deliveries")
def list_webhook_deliveries(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    rows = db.scalars(select(WebhookDelivery).where(WebhookDelivery.organization_id == context["organization_id"]).order_by(WebhookDelivery.created_at.desc()).limit(100)).all()
    return [{"id": x.id, "subscription_id": x.subscription_id, "event_type": x.event_type,
             "status": x.status, "attempts": x.attempts, "response_status": x.response_status,
             "last_error": x.last_error, "next_attempt_at": x.next_attempt_at,
             "delivered_at": x.delivered_at, "dead_lettered_at": x.dead_lettered_at,
             "created_at": x.created_at} for x in rows]

@app.get("/v1/integrations/webhooks/health")
def webhook_delivery_health(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    rows = db.execute(select(WebhookDelivery.status, func.count(WebhookDelivery.id)).where(
        WebhookDelivery.organization_id == context["organization_id"]
    ).group_by(WebhookDelivery.status)).all()
    counts = {status: count for status, count in rows}
    return {"organization_id": context["organization_id"],
            "queued": counts.get("queued", 0), "processing": counts.get("processing", 0),
            "retry": counts.get("retry", 0), "delivered": counts.get("delivered", 0),
            "dead_lettered": counts.get("dead_lettered", 0),
            "delivery_enabled": bool(settings.webhook_delivery_enabled)}

@app.get("/v1/integrations/webhooks/deliveries/{delivery_id}/attempts")
def list_webhook_delivery_attempts(delivery_id: str, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    delivery = db.scalar(select(WebhookDelivery).where(
        WebhookDelivery.id == delivery_id,
        WebhookDelivery.organization_id == context["organization_id"]))
    if not delivery:
        raise HTTPException(404, "Webhook delivery not found")
    rows = db.scalars(select(WebhookDeliveryAttempt).where(
        WebhookDeliveryAttempt.delivery_id == delivery_id,
        WebhookDeliveryAttempt.organization_id == context["organization_id"]
    ).order_by(WebhookDeliveryAttempt.attempt_number.asc()).limit(50)).all()
    return [{"attempt_number": x.attempt_number, "outcome": x.outcome,
             "response_status": x.response_status, "error_code": x.error_code,
             "duration_ms": x.duration_ms, "created_at": x.created_at} for x in rows]

@app.get("/v1/integrations/webhooks/metrics")
def webhook_delivery_metrics(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    org_id = context["organization_id"]
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=24)
    status_rows = db.execute(select(WebhookDelivery.status, func.count(WebhookDelivery.id)).where(
        WebhookDelivery.organization_id == org_id).group_by(WebhookDelivery.status)).all()
    attempts_24h = db.scalar(select(func.count(WebhookDeliveryAttempt.id)).where(
        WebhookDeliveryAttempt.organization_id == org_id,
        WebhookDeliveryAttempt.created_at >= cutoff)) or 0
    delivered_24h = db.scalar(select(func.count(WebhookDelivery.id)).where(
        WebhookDelivery.organization_id == org_id,
        WebhookDelivery.status == "delivered", WebhookDelivery.delivered_at >= cutoff)) or 0
    dead_24h = db.scalar(select(func.count(WebhookDelivery.id)).where(
        WebhookDelivery.organization_id == org_id,
        WebhookDelivery.status == "dead_lettered", WebhookDelivery.dead_lettered_at >= cutoff)) or 0
    counts = {status: count for status, count in status_rows}
    active_workers = db.scalar(select(func.count(WebhookWorkerHeartbeat.worker_id)).where(
        WebhookWorkerHeartbeat.status.in_(["running", "idle"]),
        WebhookWorkerHeartbeat.last_seen_at >= now - timedelta(seconds=90))) or 0
    return {"organization_id": org_id, "as_of": now, "window_hours": 24,
            "queue": {key: counts.get(key, 0) for key in ("queued", "processing", "retry", "delivered", "dead_lettered")},
            "last_24h": {"attempts": attempts_24h, "delivered": delivered_24h, "dead_lettered": dead_24h},
            "worker_presence": "active" if active_workers else "not_observed",
            "delivery_enabled": bool(settings.webhook_delivery_enabled)}

@app.get("/v1/audit", response_model=list[AuditOut])
def list_audit(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    return db.scalars(select(AuditEvent).where(AuditEvent.organization_id == context["organization_id"]).order_by(AuditEvent.created_at.desc()).limit(100)).all()


@app.get("/v1/pilot/enrollment")
def pilot_enrollment(context=Depends(require_org), db: Session = Depends(get_db)):
    """Return this organization's pilot participation record."""
    org_id = context["organization_id"]
    record = db.get(PilotEnrollment, org_id)
    if not record:
        record = PilotEnrollment(organization_id=org_id)
        db.add(record)
        db.commit()
        db.refresh(record)
    return {"organization_id": org_id, "cohort": record.cohort, "status": record.status,
            "primary_goal": record.primary_goal, "baseline_minutes_per_day": record.baseline_minutes_per_day,
            "target_minutes_saved_per_day": record.target_minutes_saved_per_day,
            "activated_at": record.activated_at.isoformat() if record.activated_at else None}


@app.put("/v1/pilot/enrollment")
def update_pilot_enrollment(payload: dict, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    """Owners/admins update pilot goals and participation state; no cross-tenant access."""
    allowed = {"interested", "onboarding", "active", "paused", "completed"}
    status = payload.get("status", "interested")
    if status not in allowed:
        raise HTTPException(400, "Invalid pilot status")
    goal = payload.get("primary_goal")
    if goal is not None and (not isinstance(goal, str) or len(goal.strip()) > 240):
        raise HTTPException(400, "primary_goal must be at most 240 characters")
    baseline = payload.get("baseline_minutes_per_day")
    target = payload.get("target_minutes_saved_per_day")
    for field, value in (("baseline_minutes_per_day", baseline), ("target_minutes_saved_per_day", target)):
        if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 0 or value > 1440):
            raise HTTPException(400, f"{field} must be an integer from 0 to 1440")
    org_id = context["organization_id"]
    record = db.get(PilotEnrollment, org_id)
    if not record:
        record = PilotEnrollment(organization_id=org_id)
        db.add(record)
    record.status = status
    record.primary_goal = goal.strip() if goal else None
    record.baseline_minutes_per_day = baseline
    record.target_minutes_saved_per_day = target
    if status == "active" and record.activated_at is None:
        record.activated_at = datetime.now(timezone.utc)
    audit(db, org_id, context["user"].id, "pilot.enrollment_updated", "pilot_enrollment", org_id, {"status": status})
    db.commit()
    return {"organization_id": org_id, "cohort": record.cohort, "status": record.status,
            "primary_goal": record.primary_goal, "baseline_minutes_per_day": record.baseline_minutes_per_day,
            "target_minutes_saved_per_day": record.target_minutes_saved_per_day,
            "activated_at": record.activated_at.isoformat() if record.activated_at else None}


@app.post("/v1/pilot/feedback", status_code=201)
def submit_pilot_feedback(payload: dict, context=Depends(require_org), db: Session = Depends(get_db)):
    """Capture tenant-scoped pilot feedback and operational issues."""
    category = payload.get("category", "feedback")
    severity = payload.get("severity", "normal")
    message = payload.get("message")
    if category not in {"feedback", "bug", "support", "idea"}:
        raise HTTPException(400, "Invalid feedback category")
    if severity not in {"low", "normal", "high", "critical"}:
        raise HTTPException(400, "Invalid severity")
    if not isinstance(message, str) or not message.strip() or len(message.strip()) > 4000:
        raise HTTPException(400, "message is required and must be at most 4000 characters")
    item = PilotFeedback(organization_id=context["organization_id"], submitted_by_user_id=context["user"].id,
                         category=category, severity=severity, message=message.strip())
    db.add(item)
    audit(db, context["organization_id"], context["user"].id, "pilot.feedback_submitted", "pilot_feedback", item.id,
          {"category": category, "severity": severity})
    db.commit()
    return {"id": item.id, "category": item.category, "severity": item.severity, "status": item.status,
            "created_at": item.created_at.isoformat()}


@app.get("/v1/pilot/feedback")
def list_pilot_feedback(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    rows = db.scalars(select(PilotFeedback).where(PilotFeedback.organization_id == context["organization_id"])
                      .order_by(PilotFeedback.created_at.desc()).limit(100)).all()
    return [{"id": row.id, "category": row.category, "severity": row.severity, "message": row.message,
             "status": row.status, "created_at": row.created_at.isoformat()} for row in rows]


@app.get("/v1/pilot/readiness")
def pilot_readiness(context=Depends(require_org), db: Session = Depends(get_db)):
    """Tenant-scoped, industry-neutral checklist for starting a controlled business pilot."""
    org_id = context["organization_id"]
    org = db.get(Organization, org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    member_count = db.scalar(select(func.count(Membership.id)).where(Membership.organization_id == org_id)) or 0
    inquiry_count = db.scalar(select(func.count(Inquiry.id)).where(Inquiry.organization_id == org_id)) or 0
    workflow_count = db.scalar(select(func.count(Workflow.id)).where(Workflow.organization_id == org_id)) or 0
    pending_reviews = db.scalar(select(func.count(WorkflowRun.id)).where(
        WorkflowRun.organization_id == org_id, WorkflowRun.status == "pending_approval"
    )) or 0
    profile_complete = bool(org.name and org.name.strip() and org.industry and org.industry.strip() and org.country_code and org.country_code.strip())
    steps = [
        {"key": "business_profile", "title": "Complete business profile", "complete": profile_complete,
         "detail": "Business name, industry and country are recorded." if profile_complete else "Add an industry and two-letter country code to the business profile."},
        {"key": "team_access", "title": "Set up team access", "complete": member_count >= 2,
         "detail": f"{member_count} active organization member(s). Invite a teammate to enable shared operations." if member_count < 2 else f"{member_count} organization members can collaborate."},
        {"key": "first_inquiry", "title": "Capture the first customer inquiry", "complete": inquiry_count >= 1,
         "detail": f"{inquiry_count} inquiry record(s) captured."},
        {"key": "workflow", "title": "Create a response workflow", "complete": workflow_count >= 1,
         "detail": f"{workflow_count} workflow(s) configured."},
    ]
    completed = sum(1 for step in steps if step["complete"])
    return {
        "organization_id": org_id,
        "pilot_status": "ready_for_controlled_pilot" if completed == len(steps) else "setup_in_progress",
        "completion_percent": round(completed / len(steps) * 100),
        "completed_steps": completed,
        "total_steps": len(steps),
        "steps": steps,
        "pending_human_reviews": pending_reviews,
        "external_actions_enabled": False,
        "note": "Readiness is a setup checklist, not a security certification or production approval. External customer actions remain disabled until separately configured and approved."
    }


@app.post("/v1/pilot/activate")
def activate_pilot(context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    """Activate a controlled pilot only after the tenant readiness checklist is complete."""
    readiness = pilot_readiness(context, db)
    if readiness["pilot_status"] != "ready_for_controlled_pilot":
        incomplete = [step["key"] for step in readiness["steps"] if not step["complete"]]
        raise HTTPException(409, {"message": "Pilot prerequisites are incomplete", "incomplete_steps": incomplete})
    org_id = context["organization_id"]
    record = db.get(PilotEnrollment, org_id)
    if not record:
        record = PilotEnrollment(organization_id=org_id)
        db.add(record)
    if record.status == "completed":
        raise HTTPException(409, "A completed pilot cannot be reactivated; create a new cohort enrollment")
    record.status = "active"
    if record.activated_at is None:
        record.activated_at = datetime.now(timezone.utc)
    audit(db, org_id, context["user"].id, "pilot.activated", "pilot_enrollment", org_id,
          {"readiness_percent": readiness["completion_percent"], "completed_steps": readiness["completed_steps"]})
    db.commit()
    return {"organization_id": org_id, "cohort": record.cohort, "status": record.status,
            "activated_at": record.activated_at.isoformat(), "readiness": readiness}


@app.get("/v1/pilot/metrics")
def pilot_metrics(days: int = 30, context=Depends(require_org), db: Session = Depends(get_db)):
    """Privacy-conscious, tenant-scoped pilot outcome metrics; never returns customer identifiers."""
    if days < 7 or days > 90:
        raise HTTPException(400, "days must be between 7 and 90")
    org_id = context["organization_id"]
    since = datetime.now(timezone.utc) - timedelta(days=days)
    inquiry_rows = db.execute(
        select(Inquiry.status, func.count(Inquiry.id))
        .where(Inquiry.organization_id == org_id, Inquiry.created_at >= since)
        .group_by(Inquiry.status).order_by(Inquiry.status)
    ).all()
    status_counts = {status: int(count) for status, count in inquiry_rows}
    inquiries_created = sum(status_counts.values())
    open_statuses = {"new", "needs_review", "in_progress", "waiting_customer"}
    inquiries_open = sum(count for status, count in status_counts.items() if status in open_statuses)
    sales_rows = db.execute(
        select(SaleRecord.currency, func.count(SaleRecord.id), func.sum(SaleRecord.amount_minor))
        .where(SaleRecord.organization_id == org_id, SaleRecord.created_at >= since)
        .group_by(SaleRecord.currency).order_by(SaleRecord.currency)
    ).all()
    sales_by_currency = [{"currency": currency, "sales_count": int(count),
                          "revenue_minor": int(total or 0)} for currency, count, total in sales_rows]
    review_rows = db.execute(
        select(WorkflowRun.status, func.count(WorkflowRun.id))
        .where(WorkflowRun.organization_id == org_id, WorkflowRun.created_at >= since)
        .group_by(WorkflowRun.status).order_by(WorkflowRun.status)
    ).all()
    review_counts = {status: int(count) for status, count in review_rows}
    active_team_members = db.scalar(
        select(func.count(func.distinct(AuditEvent.actor_user_id))).where(
            AuditEvent.organization_id == org_id, AuditEvent.actor_user_id.is_not(None), AuditEvent.created_at >= since
        )
    ) or 0
    total_sales = sum(row["sales_count"] for row in sales_by_currency)
    return {
        "period_days": days,
        "inquiries_created": inquiries_created,
        "inquiries_open": inquiries_open,
        "inquiry_status_counts": status_counts,
        "sales_count": total_sales,
        "sales_by_currency": sales_by_currency,
        "workflow_run_counts": review_counts,
        "active_team_members": int(active_team_members),
        "pending_human_reviews": review_counts.get("pending_approval", 0),
        "external_actions_executed": False,
        "privacy_note": "Aggregated organization metrics only. Customer names, contact details and message contents are not returned.",
    }


@app.get("/v1/operations/summary")
def operations_summary(context=Depends(require_org), db: Session = Depends(get_db)):
    """Tenant-scoped operational counts and current team workload."""
    org_id = context["organization_id"]
    rows = db.execute(
        select(Inquiry.status, func.count(Inquiry.id))
        .where(Inquiry.organization_id == org_id)
        .group_by(Inquiry.status)
    ).all()
    status_counts = {status: count for status, count in rows}
    total = sum(status_counts.values())
    open_statuses = {"new", "needs_review", "in_progress", "waiting_customer", "failed"}
    open_total = sum(status_counts.get(status, 0) for status in open_statuses)
    unassigned = db.scalar(select(func.count(Inquiry.id)).where(
        Inquiry.organization_id == org_id,
        Inquiry.assigned_to_user_id.is_(None),
        Inquiry.status.in_(open_statuses),
    )) or 0
    workload_rows = db.execute(
        select(User.id, User.full_name, Membership.role, func.count(Inquiry.id))
        .join(Membership, Membership.user_id == User.id)
        .outerjoin(Inquiry, (Inquiry.assigned_to_user_id == User.id) &
                   (Inquiry.organization_id == org_id) & Inquiry.status.in_(open_statuses))
        .where(Membership.organization_id == org_id)
        .group_by(User.id, User.full_name, Membership.role)
        .order_by(User.full_name.asc())
    ).all()
    return {
        "total_inquiries": total,
        "open_inquiries": open_total,
        "unassigned_open": unassigned,
        "status_counts": status_counts,
        "team_workload": [
            {"user_id": user_id, "full_name": full_name, "role": role, "open_assigned": count}
            for user_id, full_name, role, count in workload_rows
        ],
    }

@app.get("/v1/operations/activity", response_model=list[AuditOut])
def operations_activity(limit: int = 20, context=Depends(require_org), db: Session = Depends(get_db)):
    """Recent organisation activity; bounded and isolated by tenant."""
    if limit < 1 or limit > 50:
        raise HTTPException(400, "limit must be between 1 and 50")
    return db.scalars(
        select(AuditEvent)
        .where(AuditEvent.organization_id == context["organization_id"])
        .order_by(AuditEvent.created_at.desc())
        .limit(limit)
    ).all()


@app.post("/v1/sales", response_model=SaleOut, status_code=201)
def record_sale(payload: SaleCreate, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    """Record a completed sale using integer minor currency units (e.g. cents)."""
    org_id, actor = context["organization_id"], context["user"]
    if payload.inquiry_id:
        inquiry = db.scalar(select(Inquiry).where(Inquiry.id == payload.inquiry_id, Inquiry.organization_id == org_id))
        if not inquiry:
            raise HTTPException(404, "Inquiry not found")
        existing = db.scalar(select(SaleRecord).where(SaleRecord.organization_id == org_id, SaleRecord.inquiry_id == payload.inquiry_id))
        if existing:
            raise HTTPException(409, "A sale is already recorded for this inquiry")
    sale = SaleRecord(organization_id=org_id, inquiry_id=payload.inquiry_id, description=payload.description.strip(), product_or_service=(payload.product_or_service.strip() if payload.product_or_service else None), amount_minor=payload.amount_minor, currency=payload.currency, recorded_by_user_id=actor.id)
    db.add(sale)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "A sale is already recorded for this inquiry")
    audit(db, org_id, actor.id, "sale.recorded", "sale", sale.id, {"amount_minor": payload.amount_minor, "currency": payload.currency, "inquiry_id": payload.inquiry_id})
    db.commit(); db.refresh(sale)
    return sale

@app.get("/v1/sales", response_model=list[SaleOut])
def list_sales(limit: int = 50, context=Depends(require_org), db: Session = Depends(get_db)):
    if limit < 1 or limit > 100:
        raise HTTPException(400, "limit must be between 1 and 100")
    return db.scalars(select(SaleRecord).where(SaleRecord.organization_id == context["organization_id"]).order_by(SaleRecord.created_at.desc()).limit(limit)).all()

@app.get("/v1/performance/summary")
def performance_summary(days: int = 30, context=Depends(require_org), db: Session = Depends(get_db)):
    """Tenant-scoped sales and inquiry funnel metrics for a bounded period."""
    if days < 1 or days > 365:
        raise HTTPException(400, "days must be between 1 and 365")
    org_id = context["organization_id"]
    since = datetime.now(timezone.utc) - timedelta(days=days)
    inquiry_count = db.scalar(select(func.count(Inquiry.id)).where(Inquiry.organization_id == org_id, Inquiry.created_at >= since)) or 0
    converted = db.scalar(select(func.count(func.distinct(SaleRecord.inquiry_id))).join(Inquiry, Inquiry.id == SaleRecord.inquiry_id).where(SaleRecord.organization_id == org_id, Inquiry.organization_id == org_id, Inquiry.created_at >= since, SaleRecord.created_at >= since)) or 0
    sales = db.execute(select(SaleRecord.currency, func.count(SaleRecord.id), func.sum(SaleRecord.amount_minor)).where(SaleRecord.organization_id == org_id, SaleRecord.created_at >= since).group_by(SaleRecord.currency).order_by(SaleRecord.currency)).all()
    revenue_by_currency = [{"currency": currency, "sales_count": count, "revenue_minor": int(total or 0), "average_sale_minor": int((total or 0) / count) if count else 0} for currency, count, total in sales]
    rate = round((converted / inquiry_count) * 100, 2) if inquiry_count else 0.0
    return {"period_days": days, "inquiries_created": inquiry_count, "converted_inquiries": converted, "conversion_rate_percent": rate, "revenue_by_currency": revenue_by_currency, "sales_count": sum(row["sales_count"] for row in revenue_by_currency)}

@app.get("/v1/performance/insights")
def performance_insights(days: int = 30, context=Depends(require_org), db: Session = Depends(get_db)):
    """Explainable rules-based operational insights; no customer message data is sent to an LLM."""
    metrics = performance_summary(days=days, context=context, db=db)
    insights = []
    if metrics["inquiries_created"] == 0:
        insights.append({"type": "activity", "priority": "normal", "title": "No new inquiries in this period", "recommendation": "Check that your inquiry channels are connected and invite recent customers to contact the business."})
    elif metrics["converted_inquiries"] == 0:
        insights.append({"type": "conversion", "priority": "high", "title": "No recorded inquiry conversions yet", "recommendation": "Review open inquiries, follow up with customers, and record completed sales against their inquiry."})
    elif metrics["conversion_rate_percent"] < 10:
        insights.append({"type": "conversion", "priority": "high", "title": "Conversion rate is below 10%", "recommendation": "Review response speed, quote clarity and follow-up consistency for recent inquiries."})
    else:
        insights.append({"type": "conversion", "priority": "normal", "title": "Inquiry conversion is being recorded", "recommendation": "Compare conversion performance by channel and keep recording every completed sale."})
    if metrics["sales_count"] == 0:
        insights.append({"type": "revenue", "priority": "normal", "title": "Sales data is not yet available", "recommendation": "Record completed sales to establish a reliable revenue baseline. Amounts are stored in minor currency units."})
    return {"method": "transparent_rules_v1", "period_days": days, "insights": insights, "metrics": metrics}

@app.get("/v1/intelligence/customers")
def customer_intelligence(context=Depends(require_org), db: Session = Depends(get_db)):
    """Return privacy-preserving, organisation-scoped customer lifecycle aggregates."""
    org_id = context["organization_id"]
    inquiry_rows = db.execute(
        select(Inquiry.customer_contact, func.count(Inquiry.id))
        .where(Inquiry.organization_id == org_id, Inquiry.customer_contact.is_not(None), Inquiry.customer_contact != "")
        .group_by(Inquiry.customer_contact)
    ).all()
    # Normalize only in memory; raw customer identifiers are never returned or persisted by this endpoint.
    inquiry_counts = {}
    for contact, count in inquiry_rows:
        key = contact.strip().casefold()
        if key:
            inquiry_counts[key] = inquiry_counts.get(key, 0) + int(count)
    sale_rows = db.execute(
        select(Inquiry.customer_contact, func.count(SaleRecord.id))
        .join(SaleRecord, SaleRecord.inquiry_id == Inquiry.id)
        .where(Inquiry.organization_id == org_id, SaleRecord.organization_id == org_id,
               Inquiry.customer_contact.is_not(None), Inquiry.customer_contact != "")
        .group_by(Inquiry.customer_contact)
    ).all()
    sale_counts = {}
    for contact, count in sale_rows:
        key = contact.strip().casefold()
        if key:
            sale_counts[key] = sale_counts.get(key, 0) + int(count)
    identified = len(inquiry_counts)
    repeat_customers = sum(1 for count in inquiry_counts.values() if count > 1)
    repeat_buyers = sum(1 for count in sale_counts.values() if count > 1)
    buyers = len(sale_counts)
    return {
        "identified_customers": identified,
        "repeat_customers": repeat_customers,
        "repeat_customer_rate_percent": round(repeat_customers / identified * 100, 2) if identified else 0.0,
        "customers_with_recorded_sales": buyers,
        "repeat_buyers": repeat_buyers,
        "repeat_buyer_rate_percent": round(repeat_buyers / buyers * 100, 2) if buyers else 0.0,
        "measurement_note": "Customer matching uses normalized contact details in memory. Customers without contact details are excluded from repeat-customer metrics."
    }

@app.get("/v1/intelligence/products")
def product_intelligence(days: int = 90, context=Depends(require_org), db: Session = Depends(get_db)):
    """Aggregate product/service sales using the explicit label or sale description fallback."""
    if days < 1 or days > 365:
        raise HTTPException(400, "days must be between 1 and 365")
    since = datetime.now(timezone.utc) - timedelta(days=days)
    org_id = context["organization_id"]
    label_expr = func.coalesce(SaleRecord.product_or_service, SaleRecord.description)
    rows = db.execute(
        select(label_expr, SaleRecord.currency, func.count(SaleRecord.id), func.sum(SaleRecord.amount_minor))
        .where(SaleRecord.organization_id == org_id, SaleRecord.created_at >= since)
        .group_by(label_expr, SaleRecord.currency)
        .order_by(func.sum(SaleRecord.amount_minor).desc())
    ).all()
    return {"period_days": days, "basis": "recorded_sale_label", "items": [
        {"product_or_service": name, "currency": currency, "sales_count": int(count),
         "revenue_minor": int(total or 0), "average_sale_minor": int((total or 0) / count) if count else 0}
        for name, currency, count, total in rows
    ]}

@app.get("/v1/intelligence/trends")
def sales_trends(days: int = 30, context=Depends(require_org), db: Session = Depends(get_db)):
    """Daily sales trend grouped by currency; currencies are never combined."""
    if days < 1 or days > 365:
        raise HTTPException(400, "days must be between 1 and 365")
    since = datetime.now(timezone.utc) - timedelta(days=days)
    rows = db.execute(
        select(func.date(SaleRecord.created_at), SaleRecord.currency,
               func.count(SaleRecord.id), func.sum(SaleRecord.amount_minor))
        .where(SaleRecord.organization_id == context["organization_id"], SaleRecord.created_at >= since)
        .group_by(func.date(SaleRecord.created_at), SaleRecord.currency)
        .order_by(func.date(SaleRecord.created_at), SaleRecord.currency)
    ).all()
    return {"period_days": days, "series": [
        {"date": str(day), "currency": currency, "sales_count": int(count), "revenue_minor": int(total or 0)}
        for day, currency, count, total in rows
    ]}

@app.get("/v1/intelligence/forecast")
def revenue_run_rate(days: int = 30, horizon_days: int = 30, context=Depends(require_org), db: Session = Depends(get_db)):
    """Simple run-rate projection, deliberately not presented as a predictive forecast."""
    if days < 1 or days > 365 or horizon_days < 1 or horizon_days > 90:
        raise HTTPException(400, "days must be 1..365 and horizon_days must be 1..90")
    since = datetime.now(timezone.utc) - timedelta(days=days)
    rows = db.execute(
        select(SaleRecord.currency, func.count(SaleRecord.id), func.sum(SaleRecord.amount_minor))
        .where(SaleRecord.organization_id == context["organization_id"], SaleRecord.created_at >= since)
        .group_by(SaleRecord.currency).order_by(SaleRecord.currency)
    ).all()
    return {"basis": "historical_average_daily_run_rate", "lookback_days": days,
            "horizon_days": horizon_days, "is_prediction": False,
            "projections": [
                {"currency": currency, "observed_sales": int(count),
                 "observed_revenue_minor": int(total or 0),
                 "average_daily_revenue_minor": round((int(total or 0)) / days),
                 "run_rate_projection_minor": round((int(total or 0)) / days * horizon_days)}
                for currency, count, total in rows
            ],
            "caveat": "This is a straight-line historical run-rate illustration, not a forecast. It assumes the observed daily average continues and does not account for seasonality, pipeline, refunds, costs or currency conversion."}

@app.get("/v1/growth/action-queue")
def growth_action_queue(context=Depends(require_org), db: Session = Depends(get_db)):
    """Explainable follow-up priorities; suggestions only, with no outbound actions."""
    org_id = context["organization_id"]
    now = datetime.now(timezone.utc)
    open_statuses = ("new", "needs_review", "in_progress", "waiting_customer")
    inquiries = db.scalars(select(Inquiry).where(
        Inquiry.organization_id == org_id,
        Inquiry.status.in_(open_statuses),
    ).order_by(Inquiry.updated_at.asc()).limit(500)).all()
    items = []
    for inquiry in inquiries:
        updated = inquiry.updated_at
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        age_hours = max(0, int((now - updated).total_seconds() // 3600))
        reasons = []
        if inquiry.status == "needs_review":
            reasons.append(("high", "A response draft is waiting for human review", "Review the proposed response and approve or revise it"))
        if inquiry.assigned_to_user_id is None:
            reasons.append(("normal", "No team member is assigned", "Assign an owner so the inquiry has a clear next step"))
        if age_hours >= 72:
            reasons.append(("high", f"No update for {age_hours} hours", "Review the conversation and decide whether a follow-up is appropriate"))
        elif age_hours >= 24:
            reasons.append(("normal", f"No update for {age_hours} hours", "Check whether the customer needs a response"))
        if not reasons:
            continue
        priority_order = {"high": 0, "normal": 1}
        priority, reason, action = sorted(reasons, key=lambda item: priority_order[item[0]])[0]
        items.append({
            "inquiry_id": inquiry.id,
            "subject": inquiry.subject or "Customer inquiry",
            "status": inquiry.status,
            "priority": priority,
            "reason": reason,
            "recommended_action": action,
            "age_hours": age_hours,
            "updated_at": updated.isoformat(),
        })
    items.sort(key=lambda item: (0 if item["priority"] == "high" else 1, -item["age_hours"]))
    return {"method": "transparent_rules_v1", "items": items[:100],
            "total_actions": len(items), "external_actions_executed": False,
            "note": "Recommendations only. No customer messages are sent and no inquiry records are changed."}

@app.get("/v1/intelligence/commerce-decisions")
def commerce_decision_intelligence(context=Depends(require_org), db: Session=Depends(get_db)):
    """Tenant-scoped, explainable commercial action queue based on recorded network activity."""
    org_id = context["organization_id"]
    now = datetime.now(timezone.utc)
    attention = []
    requests = db.scalars(select(BusinessPurchaseRequest).where(
        (BusinessPurchaseRequest.buyer_organization_id == org_id) |
        (BusinessPurchaseRequest.supplier_organization_id == org_id)
    ).order_by(BusinessPurchaseRequest.created_at.desc()).limit(500)).all()
    request_ids = [row.id for row in requests]
    quotes = db.scalars(select(BusinessQuote).where(
        BusinessQuote.purchase_request_id.in_(request_ids)
    ).order_by(BusinessQuote.created_at.desc())).all() if request_ids else []
    quotes_by_request = {}
    for quote in quotes:
        quotes_by_request.setdefault(quote.purchase_request_id, []).append(quote)

    def hours_since(value):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return max(0, int((now - value).total_seconds() // 3600))

    for request_row in requests:
        age = hours_since(request_row.created_at)
        related = quotes_by_request.get(request_row.id, [])
        if request_row.status == "open" and age >= 72:
            if request_row.buyer_organization_id == org_id and not any(q.status in ("submitted", "accepted") for q in related):
                attention.append({"kind":"opportunity","reference_id":request_row.id,"title":request_row.title,
                    "priority":"high" if age >= 168 else "normal","age_hours":age,
                    "evidence":f"Open purchase request has received no submitted quotation after {age} hours.",
                    "recommended_action":"Check supplier availability and clarify any missing requirements."})
            elif request_row.supplier_organization_id == org_id and not any(q.supplier_organization_id == org_id for q in related):
                attention.append({"kind":"supplier_response","reference_id":request_row.id,"title":request_row.title,
                    "priority":"high" if age >= 168 else "normal","age_hours":age,
                    "evidence":f"A connected buyer request has remained open for {age} hours without your quotation.",
                    "recommended_action":"Review the requirements and submit a quote or decline the opportunity."})
        if request_row.buyer_organization_id == org_id and request_row.status == "open":
            for quote in related:
                if quote.status == "submitted":
                    quote_age = hours_since(quote.created_at)
                    if quote_age >= 48:
                        attention.append({"kind":"quote_decision","reference_id":quote.id,"title":request_row.title,
                            "priority":"high" if quote_age >= 120 else "normal","age_hours":quote_age,
                            "evidence":f"A submitted quotation has awaited your decision for {quote_age} hours.",
                            "recommended_action":"Compare the submitted terms and accept or reject the quotation."})

    transactions = db.scalars(select(BusinessTransaction).where(
        (BusinessTransaction.buyer_organization_id == org_id) |
        (BusinessTransaction.supplier_organization_id == org_id)
    ).order_by(BusinessTransaction.updated_at.asc()).limit(500)).all()
    active_count = 0
    delayed_count = 0
    for transaction in transactions:
        if transaction.status in ("accepted", "in_progress"):
            active_count += 1
            age = hours_since(transaction.updated_at or transaction.created_at)
            if age >= 72:
                delayed_count += 1
                attention.append({"kind":"deal_delay","reference_id":transaction.id,"title":"Active business transaction",
                    "priority":"high" if age >= 168 else "normal","age_hours":age,
                    "evidence":f"No transaction status update has been recorded for {age} hours.",
                    "recommended_action":"Contact the counterparty through your agreed channel and record the next fulfilment milestone."})

    response_hours = []
    for quote in quotes:
        request_row = next((r for r in requests if r.id == quote.purchase_request_id), None)
        if request_row and quote.supplier_organization_id == org_id:
            created = quote.created_at
            requested = request_row.created_at
            if created.tzinfo is None: created = created.replace(tzinfo=timezone.utc)
            if requested.tzinfo is None: requested = requested.replace(tzinfo=timezone.utc)
            response_hours.append(max(0, round((created-requested).total_seconds()/3600, 1)))
    attention.sort(key=lambda row: (0 if row["priority"] == "high" else 1, -row["age_hours"]))
    return {"method":"transparent_commerce_rules_v1","organization_id":org_id,
        "summary":{"attention_items":len(attention),"active_deals":active_count,"stale_active_deals":delayed_count,
            "quotes_recorded":len(quotes),"supplier_quote_response_samples":len(response_hours),
            "average_supplier_quote_response_hours":round(sum(response_hours)/len(response_hours),1) if response_hours else None},
        "items":attention[:100],"external_actions_executed":False,
        "note":"Recommendations are derived from recorded request, quote and transaction timestamps. No messages are sent and no records are changed."}

@app.post("/v1/inquiries", response_model=InquiryOut, status_code=201)
def create_inquiry(payload: InquiryCreate, idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"), context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    if not db.get(Organization, org_id):
        raise HTTPException(404, "Organization not found")
    if idempotency_key:
        if len(idempotency_key) > 128:
            raise HTTPException(400, "Idempotency-Key must be 128 characters or fewer")
        existing = db.scalar(select(Inquiry).where(Inquiry.organization_id == org_id, Inquiry.idempotency_key == idempotency_key))
        if existing:
            return existing
    inquiry = Inquiry(organization_id=org_id, idempotency_key=idempotency_key, **payload.model_dump())
    db.add(inquiry)
    db.flush()
    audit(db, org_id, actor.id, "inquiry.created", "inquiry", inquiry.id)
    db.commit()
    db.refresh(inquiry)
    return inquiry

@app.get("/v1/inquiries", response_model=list[InquiryOut])
def list_inquiries(status: str | None = None, assigned_to_me: bool = False, context=Depends(require_org), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    query = select(Inquiry).where(Inquiry.organization_id == org_id)
    if status:
        if status not in {"new", "needs_review", "in_progress", "waiting_customer", "approved", "rejected", "failed", "resolved", "closed"}:
            raise HTTPException(400, "Unsupported inquiry status")
        query = query.where(Inquiry.status == status)
    if assigned_to_me:
        query = query.where(Inquiry.assigned_to_user_id == actor.id)
    return db.scalars(query.order_by(Inquiry.created_at.desc()).limit(200)).all()

@app.patch("/v1/inquiries/{inquiry_id}/assignment", response_model=InquiryOut)
def assign_inquiry(inquiry_id: str, payload: InquiryAssignment, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    inquiry = db.scalar(select(Inquiry).where(Inquiry.id == inquiry_id, Inquiry.organization_id == org_id))
    if not inquiry:
        raise HTTPException(404, "Inquiry not found")
    if payload.user_id is not None:
        membership = db.scalar(select(Membership).where(Membership.organization_id == org_id, Membership.user_id == payload.user_id))
        if not membership:
            raise HTTPException(400, "Assignee must be an active member of this organization")
    inquiry.assigned_to_user_id = payload.user_id
    audit(db, org_id, actor.id, "inquiry.assigned" if payload.user_id else "inquiry.unassigned", "inquiry", inquiry.id, {"assigned_to_user_id": payload.user_id})
    db.commit()
    db.refresh(inquiry)
    return inquiry

@app.patch("/v1/inquiries/{inquiry_id}/status", response_model=InquiryOut)
def update_inquiry_status(inquiry_id: str, payload: InquiryStatusUpdate, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    inquiry = db.scalar(select(Inquiry).where(Inquiry.id == inquiry_id, Inquiry.organization_id == org_id))
    if not inquiry:
        raise HTTPException(404, "Inquiry not found")
    previous = inquiry.status
    inquiry.status = payload.status
    audit(db, org_id, actor.id, "inquiry.status_changed", "inquiry", inquiry.id, {"from": previous, "to": payload.status})
    db.commit()
    db.refresh(inquiry)
    return inquiry

@app.post("/v1/inquiries/{inquiry_id}/draft", response_model=RunOut, status_code=201)
def draft_inquiry_response(inquiry_id: str, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    inquiry = db.scalar(select(Inquiry).where(Inquiry.id == inquiry_id, Inquiry.organization_id == org_id))
    if not inquiry:
        raise HTTPException(404, "Inquiry not found")
    workflow = db.scalar(select(Workflow).where(Workflow.organization_id == org_id, Workflow.action_type == "draft_response"))
    if not workflow:
        workflow = Workflow(organization_id=org_id, name="Customer inquiry response", description="Prepare a customer response for human review.", action_type="draft_response", trigger_type="manual")
        db.add(workflow)
        db.flush()
    try:
        organization = db.get(Organization, org_id)
        proposal = ai_adapter.propose_inquiry_response(inquiry.message, {"business_name": organization.name if organization else None})
    except Exception:
        inquiry.status = "failed"
        db.commit()
        raise HTTPException(503, "Proposal generation failed safely; no external action was performed.")
    run = WorkflowRun(organization_id=org_id, workflow_id=workflow.id, inquiry_id=inquiry.id, status="pending_approval", input_data={"message": inquiry.message, "source": inquiry.source}, proposed_action=proposal)
    inquiry.status = "needs_review"
    db.add(run)
    db.flush()
    audit(db, org_id, actor.id, "workflow_run.proposed", "workflow_run", run.id)
    db.commit()
    db.refresh(run)
    return run

@app.post("/v1/workflows", response_model=WorkflowOut, status_code=201)
def create_workflow(payload: WorkflowCreate, context=Depends(require_role("owner", "admin")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    if not db.get(Organization, org_id):
        raise HTTPException(404, "Organization not found")
    workflow = Workflow(organization_id=org_id, **payload.model_dump())
    db.add(workflow)
    db.flush()
    audit(db, org_id, actor.id, "workflow.created", "workflow", workflow.id)
    db.commit()
    db.refresh(workflow)
    return workflow

@app.get("/v1/workflows", response_model=list[WorkflowOut])
def list_workflows(context=Depends(require_org), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    return db.scalars(select(Workflow).where(Workflow.organization_id == org_id)).all()

@app.post("/v1/workflows/{workflow_id}/runs", response_model=RunOut, status_code=201)
def run_workflow(workflow_id: str, payload: RunCreate, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    workflow = db.scalar(select(Workflow).where(
        Workflow.id == workflow_id, Workflow.organization_id == org_id
    ))
    if not workflow:
        raise HTTPException(404, "Workflow not found")
    proposal = ai_adapter.propose(workflow.action_type, payload.input_data, workflow.config or {})
    run = WorkflowRun(
        organization_id=org_id,
        workflow_id=workflow.id,
        status="pending_approval",
        input_data=payload.input_data,
        proposed_action=proposal,
    )
    db.add(run)
    db.flush()
    audit(db, org_id, actor.id, "workflow_run.proposed", "workflow_run", run.id)
    db.commit()
    db.refresh(run)
    return run

@app.get("/v1/runs", response_model=list[RunOut])
def list_runs(context=Depends(require_org), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    return db.scalars(select(WorkflowRun).where(
        WorkflowRun.organization_id == org_id
    ).order_by(WorkflowRun.created_at.desc())).all()

@app.post("/v1/runs/{run_id}/approve", response_model=RunOut)
def approve_run(run_id: str, payload: DecisionInput, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    run = db.scalar(select(WorkflowRun).where(
        WorkflowRun.id == run_id, WorkflowRun.organization_id == org_id
    ))
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status != "pending_approval":
        raise HTTPException(409, "Run is not awaiting approval")
    # Approval records intent only. No external connector is executed in this starter.
    run.status = "approved"
    if run.inquiry_id:
        inquiry = db.get(Inquiry, run.inquiry_id)
        if inquiry and inquiry.organization_id == org_id:
            inquiry.status = "approved"
    run.decision_note = payload.note
    audit(db, org_id, actor.id, "workflow_run.approved", "workflow_run", run.id)
    db.commit()
    db.refresh(run)
    return run

@app.post("/v1/runs/{run_id}/reject", response_model=RunOut)
def reject_run(run_id: str, payload: DecisionInput, context=Depends(require_role("owner", "admin", "manager")), db: Session = Depends(get_db)):
    org_id, actor = context["organization_id"], context["user"]
    run = db.scalar(select(WorkflowRun).where(
        WorkflowRun.id == run_id, WorkflowRun.organization_id == org_id
    ))
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status != "pending_approval":
        raise HTTPException(409, "Run is not awaiting approval")
    run.status = "rejected"
    if run.inquiry_id:
        inquiry = db.get(Inquiry, run.inquiry_id)
        if inquiry and inquiry.organization_id == org_id:
            inquiry.status = "rejected"
    run.decision_note = payload.note
    audit(db, org_id, actor.id, "workflow_run.rejected", "workflow_run", run.id)
    db.commit()
    db.refresh(run)
    return run
