from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from cryptography.fernet import Fernet

class Settings(BaseSettings):
    app_name: str = "IMPERIONX OS"
    app_env: str = "development"
    database_url: str = "sqlite:///./imperionx_dev.db"
    public_base_url: str = "http://localhost:3000"
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from_email: str = "no-reply@imperionx.local"
    smtp_use_tls: bool = True
    mfa_encryption_key: str | None = None
    public_rate_limit_hmac_key: str | None = None
    ai_provider: str = "safe-demo"
    ai_base_url: str | None = None
    ai_api_key: str | None = None
    ai_model: str | None = None
    webhook_delivery_enabled: bool = False
    db_pool_size: int = Field(default=5, ge=1, le=50)
    db_max_overflow: int = Field(default=5, ge=0, le=100)
    db_pool_timeout_seconds: int = Field(default=30, ge=1, le=120)
    db_pool_recycle_seconds: int = Field(default=1800, ge=60, le=86400)
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()


def validate_production_settings() -> None:
    """Fail closed on unsafe production configuration."""
    if settings.app_env.lower() not in ("production", "staging"):
        return
    problems = []
    if not settings.database_url.startswith(("postgresql://", "postgresql+")):
        problems.append("DATABASE_URL must use PostgreSQL in production")
    if not settings.public_base_url.startswith("https://"):
        problems.append("PUBLIC_BASE_URL must use HTTPS in production")
    if not settings.smtp_host:
        problems.append("SMTP_HOST must be configured in production")
    if not settings.mfa_encryption_key:
        problems.append("MFA_ENCRYPTION_KEY must be configured in production")
    if not settings.public_rate_limit_hmac_key or len(settings.public_rate_limit_hmac_key) < 32:
        problems.append("PUBLIC_RATE_LIMIT_HMAC_KEY must be configured with at least 32 characters in production")
    else:
        try:
            Fernet(settings.mfa_encryption_key.encode())
        except (ValueError, TypeError):
            problems.append("MFA_ENCRYPTION_KEY must be a valid Fernet key")
    if settings.smtp_username and not settings.smtp_password:
        problems.append("SMTP_PASSWORD is required when SMTP_USERNAME is configured")
    if settings.smtp_password and not settings.smtp_username:
        problems.append("SMTP_USERNAME is required when SMTP_PASSWORD is configured")
    if settings.smtp_from_email.endswith(".local") or "@" not in settings.smtp_from_email:
        problems.append("SMTP_FROM_EMAIL must be a deliverable email address in production")
    if problems:
        raise RuntimeError("Unsafe production configuration: " + "; ".join(problems))
