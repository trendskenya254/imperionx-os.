from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_backend_container_runs_as_non_root_user():
    dockerfile = (ROOT / "backend" / "Dockerfile").read_text()
    assert "USER 10001:10001" in dockerfile
    assert "COPY --chown=imperionx:imperionx" in dockerfile


def test_frontend_container_runs_as_non_root_user():
    dockerfile = (ROOT / "frontend" / "Dockerfile").read_text()
    assert "USER 1001:1001" in dockerfile
    assert "--chown=nextjs:nextjs" in dockerfile


def test_application_compose_services_drop_linux_capabilities():
    compose = (ROOT / "docker-compose.yml").read_text()
    for service in ("api:", "webhook-worker:", "frontend:"):
        section = compose.split(service, 1)[1]
        assert "no-new-privileges:true" in section.split("\n  ", 1)[0] or "no-new-privileges:true" in section
        assert "cap_drop:" in section
        assert "- ALL" in section


def test_secrets_and_runtime_artifacts_are_excluded_from_git_and_images():
    gitignore = (ROOT / ".gitignore").read_text()
    backend_ignore = (ROOT / "backend" / ".dockerignore").read_text()
    frontend_ignore = (ROOT / "frontend" / ".dockerignore").read_text()
    assert ".env" in gitignore
    assert "backups/" in gitignore
    assert ".env" in backend_ignore
    assert ".env" in frontend_ignore
