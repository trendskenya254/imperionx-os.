from sqlalchemy import create_engine
import app.main as main_module

def test_health_reports_current_version(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["version"] == "5.0.0"

def test_readiness_checks_database(client, monkeypatch):
    test_engine = create_engine("sqlite://")
    monkeypatch.setattr(main_module, "engine", test_engine)
    response = client.get("/ready")
    assert response.status_code == 200
    assert response.json()["status"] == "ready"
    assert response.json()["version"] == "5.0.0"
    test_engine.dispose()

def test_request_id_is_returned(client):
    response = client.get("/health", headers={"X-Request-ID": "trace-test-001"})
    assert response.headers["X-Request-ID"] == "trace-test-001"

def test_api_sets_baseline_security_headers(client):
    response = client.get("/health")
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Referrer-Policy"] == "strict-origin-when-cross-origin"
    assert response.headers["Cache-Control"] == "no-store"

def test_production_responses_include_hsts(client, monkeypatch):
    from app.config import settings
    monkeypatch.setattr(settings, "app_env", "production")
    response = client.get("/health")
    assert response.headers["Strict-Transport-Security"] == "max-age=63072000; includeSubDomains; preload"
