from test_inquiries import register


def test_public_profile_is_opt_in_and_searchable(client):
    org_id, headers = register(client, "discover-a@example.com", "Acme Solar")
    hidden = client.get("/v1/discovery/businesses")
    assert hidden.status_code == 200 and hidden.json()["items"] == []
    saved = client.put("/v1/business/profile", headers=headers, json={
        "slug": "acme-solar", "tagline": "Solar solutions for growing businesses",
        "description": "Design and installation of commercial solar systems.",
        "city": "Mombasa", "public_email": "hello@acmesolar.example", "is_published": True
    })
    assert saved.status_code == 200, saved.text
    result = client.get("/v1/discovery/businesses?q=solar")
    assert result.status_code == 200
    assert result.json()["items"][0]["name"] == "Acme Solar"
    assert "email" not in result.json()["items"][0]
    assert client.get("/v1/discovery/businesses/acme-solar").status_code == 200


def test_public_lead_requires_consent_and_is_private_to_target_org(client):
    org_id, owner = register(client, "lead-owner@example.com", "Lead Target")
    client.put("/v1/business/profile", headers=owner, json={"slug": "lead-target", "is_published": True})
    denied = client.post("/v1/discovery/businesses/lead-target/leads", json={
        "contact_name": "Prospect", "contact_email": "prospect@example.com", "message": "Please contact me", "consent_to_contact": False
    })
    assert denied.status_code == 400
    accepted = client.post("/v1/discovery/businesses/lead-target/leads", json={
        "contact_name": "Prospect", "contact_email": "prospect@example.com", "message": "Please contact me", "consent_to_contact": True
    })
    assert accepted.status_code == 201
    assert len(client.get("/v1/business/leads", headers=owner).json()) == 1
    other_org, other = register(client, "lead-other@example.com", "Other Business")
    assert client.get("/v1/business/leads", headers=other).json() == []


def test_business_connection_requests_require_published_target(client):
    source_id, source = register(client, "connection-source@example.com", "Source Co")
    target_id, target = register(client, "connection-target@example.com", "Target Co")
    client.put("/v1/business/profile", headers=target, json={"slug": "target-co", "is_published": True})
    created = client.post("/v1/business/connections", headers=source, json={"target_slug": "target-co", "message": "Explore supplier partnership"})
    assert created.status_code == 201, created.text
    assert created.json()["status"] == "pending"
    assert len(client.get("/v1/business/connections", headers=source).json()) == 1
    assert len(client.get("/v1/business/connections", headers=target).json()) == 1
    duplicate = client.post("/v1/business/connections", headers=source, json={"target_slug": "target-co"})
    assert duplicate.status_code == 409
    self_request = client.post("/v1/business/connections", headers=target, json={"target_slug": "target-co"})
    assert self_request.status_code == 400


def test_public_lead_submission_is_rate_limited(client):
    from test_inquiries import register as register_business
    org_id, owner = register_business(client, "rate-target@example.com", "Rate Target")
    saved = client.put("/v1/business/profile", headers=owner, json={"slug": "rate-target", "is_published": True})
    assert saved.status_code == 200
    payload = {"contact_name": "Prospect", "contact_email": "p@example.com", "message": "Please contact our company", "consent_to_contact": True}
    responses = [client.post("/v1/discovery/businesses/rate-target/leads", json=payload) for _ in range(6)]
    assert [r.status_code for r in responses[:5]] == [201] * 5
    assert responses[5].status_code == 429
