import pytest
from app.config import settings, validate_production_settings

def test_production_configuration_fails_closed_when_incomplete(monkeypatch):
    monkeypatch.setattr(settings, "app_env", "production")
    monkeypatch.setattr(settings, "database_url", "sqlite:///unsafe.db")
    monkeypatch.setattr(settings, "public_base_url", "http://example.test")
    monkeypatch.setattr(settings, "smtp_host", None)
    monkeypatch.setattr(settings, "mfa_encryption_key", None)
    with pytest.raises(RuntimeError, match="Unsafe production configuration"):
        validate_production_settings()

def test_nonproduction_configuration_keeps_local_sqlite_supported(monkeypatch):
    monkeypatch.setattr(settings, "app_env", "test")
    monkeypatch.setattr(settings, "database_url", "sqlite://")
    monkeypatch.setattr(settings, "public_base_url", "http://localhost:3000")
    monkeypatch.setattr(settings, "smtp_host", None)
    monkeypatch.setattr(settings, "mfa_encryption_key", None)
    validate_production_settings()

def test_production_configuration_rejects_invalid_mfa_key(monkeypatch):
    from cryptography.fernet import Fernet
    monkeypatch.setattr(settings, "app_env", "production")
    monkeypatch.setattr(settings, "database_url", "postgresql+psycopg://user:pass@db/app")
    monkeypatch.setattr(settings, "public_base_url", "https://app.example.com")
    monkeypatch.setattr(settings, "smtp_host", "smtp.example.com")
    monkeypatch.setattr(settings, "smtp_from_email", "no-reply@example.com")
    monkeypatch.setattr(settings, "smtp_username", None)
    monkeypatch.setattr(settings, "smtp_password", None)
    monkeypatch.setattr(settings, "mfa_encryption_key", "not-a-fernet-key")
    monkeypatch.setattr(settings, "public_rate_limit_hmac_key", "test-public-rate-limit-secret-32-bytes")
    with pytest.raises(RuntimeError, match="valid Fernet key"):
        validate_production_settings()


def test_production_configuration_rejects_unpaired_smtp_credentials(monkeypatch):
    from cryptography.fernet import Fernet
    monkeypatch.setattr(settings, "app_env", "production")
    monkeypatch.setattr(settings, "database_url", "postgresql+psycopg://user:pass@db/app")
    monkeypatch.setattr(settings, "public_base_url", "https://app.example.com")
    monkeypatch.setattr(settings, "smtp_host", "smtp.example.com")
    monkeypatch.setattr(settings, "smtp_from_email", "no-reply@example.com")
    monkeypatch.setattr(settings, "smtp_username", "mailer")
    monkeypatch.setattr(settings, "smtp_password", None)
    monkeypatch.setattr(settings, "mfa_encryption_key", Fernet.generate_key().decode())
    monkeypatch.setattr(settings, "public_rate_limit_hmac_key", "test-public-rate-limit-secret-32-bytes")
    with pytest.raises(RuntimeError, match="SMTP_PASSWORD is required"):
        validate_production_settings()

def test_production_configuration_accepts_valid_security_settings(monkeypatch):
    from cryptography.fernet import Fernet
    monkeypatch.setattr(settings, "app_env", "production")
    monkeypatch.setattr(settings, "database_url", "postgresql+psycopg://user:pass@db/app")
    monkeypatch.setattr(settings, "public_base_url", "https://app.example.com")
    monkeypatch.setattr(settings, "smtp_host", "smtp.example.com")
    monkeypatch.setattr(settings, "smtp_from_email", "no-reply@example.com")
    monkeypatch.setattr(settings, "smtp_username", "mailer")
    monkeypatch.setattr(settings, "smtp_password", "smtp-secret")
    monkeypatch.setattr(settings, "mfa_encryption_key", Fernet.generate_key().decode())
    monkeypatch.setattr(settings, "public_rate_limit_hmac_key", "test-public-rate-limit-secret-32-bytes")
    validate_production_settings()
