from test_inquiries import register
from test_trust_commerce import _make_transaction


def test_feedback_challenge_hides_rating_pending_review_and_blocks_duplicate(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    assert client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"}).status_code == 200
    payload = {"communication_rating": 5, "quality_rating": 5, "timeliness_rating": 4, "comment": "Private context"}
    feedback = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json=payload)
    assert feedback.status_code == 201, feedback.text
    challenge = client.post(f"/v1/business/feedback/{feedback.json()['id']}/challenge", headers=supplier, json={
        "reason": "factual_inaccuracy", "explanation": "The rating conflicts with the signed delivery record.",
        "evidence_reference": "case-file-2026-001", "evidence_sha256": "a" * 64
    })
    assert challenge.status_code == 201, challenge.text
    assert challenge.json()["status"] == "pending"
    reputation = client.get(f"/v1/business/organizations/{supplier_id}/reputation", headers=buyer)
    assert reputation.status_code == 200
    assert reputation.json()["verified_transaction_feedback_count"] == 0
    assert reputation.json()["ratings"]["quality_rating"]["average"] is None
    repeated = client.post(f"/v1/business/feedback/{feedback.json()['id']}/challenge", headers=supplier, json={
        "reason": "other", "explanation": "A second attempt to challenge this same feedback."
    })
    assert repeated.status_code == 409
    assert client.get("/v1/platform/feedback-challenges", headers=buyer).status_code == 403


def test_feedback_challenge_requires_participant_and_valid_evidence_digest(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    assert client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"}).status_code == 200
    feedback = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json={
        "communication_rating": 5, "quality_rating": 4, "timeliness_rating": 5
    })
    outsider_id, outsider = register(client, "challenge-outsider@example.com", "Challenge Outsider")
    assert client.post(f"/v1/business/feedback/{feedback.json()['id']}/challenge", headers=outsider, json={
        "reason": "other", "explanation": "This organization is not a transaction participant."
    }).status_code == 404
    invalid = client.post(f"/v1/business/feedback/{feedback.json()['id']}/challenge", headers=supplier, json={
        "reason": "other", "explanation": "The evidence digest is malformed and should be rejected.", "evidence_sha256": "not-a-digest"
    })
    assert invalid.status_code == 400


def test_moderation_and_appeal_require_independent_platform_reviewers(client, monkeypatch):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    assert client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"}).status_code == 200
    feedback = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json={
        "communication_rating": 2, "quality_rating": 2, "timeliness_rating": 2
    }).json()
    challenge = client.post(f"/v1/business/feedback/{feedback['id']}/challenge", headers=supplier, json={
        "reason": "factual_inaccuracy", "explanation": "The feedback does not match the signed acceptance record."
    }).json()
    reviewer_id, reviewer = register(client, "neutral-reviewer@example.com", "Neutral Review Office")
    reviewer_user_id = client.get("/v1/auth/me", headers=reviewer).json()["id"]
    monkeypatch.setenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", reviewer_user_id)
    decision = client.post(f"/v1/platform/feedback-challenges/{challenge['id']}/decision", headers=reviewer,
                           json={"decision": "upheld", "note": "Evidence supports the challenge."})
    assert decision.status_code == 200, decision.text
    assert decision.json()["feedback_moderation_status"] == "hidden"
    assert client.get(f"/v1/business/organizations/{supplier_id}/reputation", headers=buyer).json()["verified_transaction_feedback_count"] == 0
    appeal = client.post(f"/v1/business/feedback-challenges/{challenge['id']}/appeal", headers=buyer,
                         json={"note": "The evidence was incomplete and the feedback should remain visible."})
    assert appeal.status_code == 201, appeal.text
    same_reviewer = client.post(f"/v1/platform/feedback-appeals/{challenge['id']}/decision", headers=reviewer,
                                json={"decision": "overturn", "note": "Reconsidered."})
    assert same_reviewer.status_code == 403
    second_reviewer_id, second_reviewer = register(client, "appeal-reviewer@example.com", "Appeal Review Office")
    second_user_id = client.get("/v1/auth/me", headers=second_reviewer).json()["id"]
    monkeypatch.setenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", f"{reviewer_user_id},{second_user_id}")
    overturned = client.post(f"/v1/platform/feedback-appeals/{challenge['id']}/decision", headers=second_reviewer,
                             json={"decision": "overturn", "note": "Appeal evidence warrants restoring publication."})
    assert overturned.status_code == 200, overturned.text
    assert overturned.json()["feedback_moderation_status"] == "published"
    assert client.get(f"/v1/business/organizations/{supplier_id}/reputation", headers=buyer).json()["verified_transaction_feedback_count"] == 1
