from test_inquiries import register
from test_business_network import _setup_pair


def test_evidence_is_tenant_scoped_and_never_exposes_document_bytes(client, monkeypatch):
    org_id, owner = register(client, "identity-owner@example.com", "Identity Owner Co")
    added = client.post("/v1/business/verification/evidence", headers=owner, json={
        "evidence_type": "Business registry extract",
        "evidence_reference": "vault://private/evidence/registry-123",
        "issuer_name": "National Business Registry",
        "access_scope": "review_only",
    })
    assert added.status_code == 201, added.text
    assert added.json()["access_scope"] == "review_only"
    rows = client.get("/v1/business/verification/evidence", headers=owner)
    assert rows.status_code == 200 and rows.json()[0]["id"] == added.json()["id"]
    assert "evidence_reference" not in rows.text
    reviewer_id, reviewer = register(client, "identity-evidence-reviewer@example.com", "Evidence Review Unit")
    reviewer_user_id = client.get("/v1/auth/me", headers=reviewer).json()["id"]
    monkeypatch.setenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", reviewer_user_id)
    reviewed_evidence = client.get(f"/v1/platform/verifications/{org_id}/evidence", headers=reviewer)
    assert reviewed_evidence.status_code == 200
    assert reviewed_evidence.json()[0]["evidence_reference"] == "vault://private/evidence/registry-123"
    outsider_id, outsider = register(client, "identity-outsider@example.com", "Identity Outsider Co")
    assert client.get("/v1/business/verification/evidence", headers=outsider).json() == []
    assert "evidence_reference" not in client.get(f"/v1/network/organizations/{org_id}/trust", headers=outsider).text


def test_trust_credential_issue_signature_revocation_and_connection_scope(client, monkeypatch):
    source_id, source, target_id, target, connection_id = _setup_pair(client)
    assert client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                       json={"decision": "accepted", "shared_fields": []}).status_code == 200
    submitted = client.post("/v1/business/verification", headers=target, json={"evidence_type": "Registry certificate"})
    assert submitted.status_code == 201
    reviewer_id, reviewer = register(client, "identity-reviewer@example.com", "Platform Review Unit")
    reviewer_user_id = client.get("/v1/auth/me", headers=reviewer).json()["id"]
    monkeypatch.setenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", reviewer_user_id)
    decision = client.post(f"/v1/platform/verifications/{target_id}/decision", headers=reviewer,
                           json={"decision": "verified", "note": "Registry evidence reviewed"})
    assert decision.status_code == 200
    monkeypatch.setattr("app.main.settings.public_rate_limit_hmac_key", "k" * 48)
    issued = client.post(f"/v1/platform/verifications/{target_id}/credentials", headers=reviewer,
                         json={"credential_type": "business_verification"})
    assert issued.status_code == 201, issued.text
    credential = issued.json()
    assert len(credential["signature"]) == 64 and len(credential["payload_digest"]) == 64
    trust = client.get(f"/v1/network/organizations/{target_id}/trust", headers=source)
    assert trust.status_code == 200 and trust.json()["verification_status"] == "verified"
    assert trust.json()["active_credentials"][0]["id"] == credential["id"]
    assert trust.json()["active_credentials"][0]["signature"] == credential["signature"]
    revoked = client.post(f"/v1/platform/trust-credentials/{credential['id']}/revoke", headers=reviewer,
                          json={"reason": "Credential superseded after review"})
    assert revoked.status_code == 200 and revoked.json()["status"] == "revoked"
    assert client.get(f"/v1/network/organizations/{target_id}/trust", headers=source).json()["active_credentials"] == []
    outsider_id, outsider = register(client, "identity-no-connection@example.com", "No Connection Co")
    assert client.get(f"/v1/network/organizations/{target_id}/trust", headers=outsider).status_code == 404


def test_credential_issuance_fails_closed_without_signing_key(client, monkeypatch):
    org_id, owner = register(client, "identity-keyless@example.com", "Keyless Co")
    client.post("/v1/business/verification", headers=owner, json={"evidence_type": "Registry certificate"})
    reviewer_id, reviewer = register(client, "identity-keyless-reviewer@example.com", "Review Unit")
    reviewer_user_id = client.get("/v1/auth/me", headers=reviewer).json()["id"]
    monkeypatch.setenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", reviewer_user_id)
    client.post(f"/v1/platform/verifications/{org_id}/decision", headers=reviewer,
                json={"decision": "verified", "note": "Reviewed"})
    monkeypatch.setattr("app.main.settings.public_rate_limit_hmac_key", None)
    response = client.post(f"/v1/platform/verifications/{org_id}/credentials", headers=reviewer, json={})
    assert response.status_code == 503
