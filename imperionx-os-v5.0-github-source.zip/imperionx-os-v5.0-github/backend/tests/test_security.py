from app.security import totp_code
import time

def register(client, email, org):
    r = client.post("/v1/auth/register", json={"email": email, "password": "correct-horse-battery-staple", "full_name": email.split('@')[0], "organization_name": org})
    assert r.status_code == 202, r.text
    message = client.app.state.test_mailbox[-1]["body"]
    raw_token = message.split("token=", 1)[1].split("\n", 1)[0]
    verified = client.post("/v1/auth/verify-email", json={"token": raw_token})
    assert verified.status_code == 200, verified.text
    login = client.post("/v1/auth/login", json={"email": email, "password": "correct-horse-battery-staple"})
    assert login.status_code == 200, login.text
    d = login.json()
    headers = {"Authorization": f"Bearer {d['access_token']}", "X-Organization-ID": d["organization_id"]}
    enrolled = client.post("/v1/auth/mfa/enroll", headers=headers)
    assert enrolled.status_code == 200, enrolled.text
    secret = enrolled.json()["secret"]
    enabled = client.post("/v1/auth/mfa/enable", headers=headers, json={"code": totp_code(secret)})
    assert enabled.status_code == 200, enabled.text
    return d, headers

def test_authentication_required_and_bad_login(client):
    assert client.get("/v1/inquiries", headers={"X-Organization-ID": "anything"}).status_code == 401
    client.post("/v1/auth/register", json={"email":"first@example.com", "password":"correct-horse-battery-staple", "full_name":"First User", "organization_name":"First Org"})
    bad = client.post("/v1/auth/login", json={"email":"first@example.com", "password":"wrong"})
    assert bad.status_code == 401

def test_role_permissions_and_membership(client):
    owner, owner_headers = register(client, "owner@example.com", "Owner Org")
    staff, staff_headers = register(client, "staff@example.com", "Staff Org")
    invited = client.post("/v1/organizations/members", headers=owner_headers, json={"email":"staff@example.com", "role":"member"})
    assert invited.status_code == 201
    viewer_headers = {"Authorization": staff_headers["Authorization"], "X-Organization-ID": owner["organization_id"]}
    assert client.get("/v1/inquiries", headers=viewer_headers).status_code == 200
    denied = client.post("/v1/inquiries", headers=viewer_headers, json={"message":"This should be denied for viewer role"})
    assert denied.status_code == 403
    assert client.post("/v1/organizations/members", headers=viewer_headers, json={"email":"owner@example.com", "role":"manager"}).status_code == 403

def test_logout_revokes_session(client):
    data, headers = register(client, "logout@example.com", "Logout Org")
    assert client.get("/v1/auth/me", headers=headers).status_code == 200
    assert client.post("/v1/auth/logout", headers=headers).status_code == 204
    assert client.get("/v1/auth/me", headers=headers).status_code == 401

def test_duplicate_registration_rejected(client):
    register(client, "duplicate@example.com", "Org One")
    again = client.post("/v1/auth/register", json={"email":"duplicate@example.com", "password":"correct-horse-battery-staple", "full_name":"Second User", "organization_name":"Org Two"})
    assert again.status_code == 409


def test_admin_cannot_grant_admin_or_owner(client):
    owner, owner_headers = register(client, "primary-owner@example.com", "Primary Org")
    admin_user, admin_personal_headers = register(client, "new-admin@example.com", "Other Org")
    # Owner promotes the second account to admin in this organization.
    promoted = client.post("/v1/organizations/members", headers=owner_headers, json={"email":"new-admin@example.com", "role":"admin"})
    assert promoted.status_code == 201
    admin_headers = {"Authorization": admin_personal_headers["Authorization"], "X-Organization-ID": owner["organization_id"]}
    outsider, _ = register(client, "third-user@example.com", "Third Org")
    assert client.post("/v1/organizations/members", headers=admin_headers, json={"email":"third-user@example.com", "role":"admin"}).status_code == 403
    assert client.post("/v1/organizations/members", headers=admin_headers, json={"email":"third-user@example.com", "role":"owner"}).status_code == 403


def test_authenticated_tenant_isolation(client):
    first, first_headers = register(client, "tenant-a@example.com", "Tenant A")
    second, second_headers = register(client, "tenant-b@example.com", "Tenant B")
    created = client.post("/v1/inquiries", headers=first_headers, json={"message":"Tenant A confidential inquiry"})
    assert created.status_code == 201
    # A user with no membership in tenant A cannot select it by changing the header.
    forged = {"Authorization": second_headers["Authorization"], "X-Organization-ID": first["organization_id"]}
    assert client.get("/v1/inquiries", headers=forged).status_code == 403
    assert client.get("/v1/inquiries", headers=second_headers).json() == []


def test_refresh_rotates_tokens_and_old_access_is_revoked(client):
    data, headers = register(client, "rotate@example.com", "Rotate Org")
    old_access = headers["Authorization"]
    refreshed = client.post("/v1/auth/refresh", json={"refresh_token": data["refresh_token"]})
    assert refreshed.status_code == 200, refreshed.text
    new_data = refreshed.json()
    assert new_data["access_token"] != data["access_token"]
    assert new_data["refresh_token"] != data["refresh_token"]
    assert client.get("/v1/auth/me", headers={"Authorization": old_access}).status_code == 401
    assert client.get("/v1/auth/me", headers={"Authorization": f"Bearer {new_data['access_token']}"}).status_code == 200

def test_refresh_token_reuse_revokes_session_family(client):
    data, headers = register(client, "reuse@example.com", "Reuse Org")
    first = client.post("/v1/auth/refresh", json={"refresh_token": data["refresh_token"]})
    assert first.status_code == 200
    second = client.post("/v1/auth/refresh", json={"refresh_token": data["refresh_token"]})
    assert second.status_code == 401
    rotated = first.json()
    assert client.get("/v1/auth/me", headers={"Authorization": f"Bearer {rotated['access_token']}"}).status_code == 401

def test_logout_revokes_refresh_family(client):
    data, headers = register(client, "logout-family@example.com", "Logout Family")
    rotated = client.post("/v1/auth/refresh", json={"refresh_token": data["refresh_token"]}).json()
    rotated_headers = {"Authorization": f"Bearer {rotated['access_token']}"}
    assert client.post("/v1/auth/logout", headers=rotated_headers).status_code == 204
    assert client.post("/v1/auth/refresh", json={"refresh_token": rotated["refresh_token"]}).status_code == 401

def test_login_rate_limit_after_ten_failed_attempts(client):
    register(client, "throttle@example.com", "Throttle Org")
    for _ in range(10):
        response = client.post("/v1/auth/login", json={"email": "throttle@example.com", "password": "incorrect"})
        assert response.status_code == 401
    blocked = client.post("/v1/auth/login", json={"email": "throttle@example.com", "password": "correct-horse-battery-staple"})
    assert blocked.status_code == 429
    assert blocked.headers.get("retry-after") == "900"


def test_registration_requires_email_verification_and_token_is_one_time(client):
    response = client.post("/v1/auth/register", json={
        "email": "verify@example.com", "password": "correct-horse-battery-staple",
        "full_name": "Verify User", "organization_name": "Verify Org"
    })
    assert response.status_code == 202
    assert "access_token" not in response.json()
    blocked = client.post("/v1/auth/login", json={"email": "verify@example.com", "password": "correct-horse-battery-staple"})
    assert blocked.status_code == 403
    body = client.app.state.test_mailbox[-1]["body"]
    token = body.split("token=", 1)[1].split("\n", 1)[0]
    assert client.post("/v1/auth/verify-email", json={"token": token}).status_code == 200
    assert client.post("/v1/auth/verify-email", json={"token": token}).status_code == 400
    assert client.post("/v1/auth/login", json={"email": "verify@example.com", "password": "correct-horse-battery-staple"}).status_code == 200


def test_password_reset_is_one_time_and_revokes_existing_sessions(client):
    _, headers = register(client, "reset@example.com", "Reset Org")
    request = client.post("/v1/auth/password-reset/request", json={"email": "reset@example.com"})
    assert request.status_code == 202
    body = client.app.state.test_mailbox[-1]["body"]
    token = body.split("token=", 1)[1].split("\n", 1)[0]
    reset = client.post("/v1/auth/password-reset/confirm", json={"token": token, "new_password": "a-new-very-strong-password"})
    assert reset.status_code == 200
    assert client.post("/v1/auth/password-reset/confirm", json={"token": token, "new_password": "another-very-strong-password"}).status_code == 400
    assert client.get("/v1/auth/me", headers=headers).status_code == 401
    old_login = client.post("/v1/auth/login", json={"email": "reset@example.com", "password": "correct-horse-battery-staple"})
    new_login = client.post("/v1/auth/login", json={"email": "reset@example.com", "password": "a-new-very-strong-password"})
    assert old_login.status_code == 401
    assert new_login.status_code == 200
    assert new_login.json().get("mfa_required") is True


def test_password_reset_request_does_not_disclose_unknown_email(client):
    known = client.post("/v1/auth/password-reset/request", json={"email": "nobody@example.com"})
    assert known.status_code == 202
    assert "If a verified account exists" in known.json()["message"]


def test_resending_verification_invalidates_previous_token(client):
    response = client.post("/v1/auth/register", json={
        "email": "resend@example.com", "password": "correct-horse-battery-staple",
        "full_name": "Resend User", "organization_name": "Resend Org"
    })
    assert response.status_code == 202
    first_body = client.app.state.test_mailbox[-1]["body"]
    first_token = first_body.split("token=", 1)[1].split("\n", 1)[0]
    assert client.post("/v1/auth/resend-verification", json={"email": "resend@example.com"}).status_code == 202
    second_body = client.app.state.test_mailbox[-1]["body"]
    second_token = second_body.split("token=", 1)[1].split("\n", 1)[0]
    assert first_token != second_token
    assert client.post("/v1/auth/verify-email", json={"token": first_token}).status_code == 400
    assert client.post("/v1/auth/verify-email", json={"token": second_token}).status_code == 200


def test_mfa_challenge_and_one_time_recovery_code(client):
    response = client.post("/v1/auth/register", json={"email": "mfa-flow@example.com", "password": "correct-horse-battery-staple", "full_name": "MFA Flow", "organization_name": "MFA Flow Org"})
    token = client.app.state.test_mailbox[-1]["body"].split("token=", 1)[1].split("\n", 1)[0]
    assert client.post("/v1/auth/verify-email", json={"token": token}).status_code == 200
    initial = client.post("/v1/auth/login", json={"email": "mfa-flow@example.com", "password": "correct-horse-battery-staple"}).json()
    headers = {"Authorization": f"Bearer {initial['access_token']}"}
    secret = client.post("/v1/auth/mfa/enroll", headers=headers).json()["secret"]
    enabled = client.post("/v1/auth/mfa/enable", headers=headers, json={"code": totp_code(secret)})
    assert enabled.status_code == 200
    recovery_code = enabled.json()["recovery_codes"][0]
    challenge = client.post("/v1/auth/login", json={"email": "mfa-flow@example.com", "password": "correct-horse-battery-staple"}).json()
    assert challenge["mfa_required"] is True and "access_token" not in challenge
    next_code = totp_code(secret, int(time.time()) + 30)
    completed = client.post("/v1/auth/mfa/verify-login", json={"challenge_token": challenge["challenge_token"], "code": next_code})
    assert completed.status_code == 200 and "access_token" in completed.json()
    replay = client.post("/v1/auth/mfa/verify-login", json={"challenge_token": challenge["challenge_token"], "code": next_code})
    assert replay.status_code == 401
    # A TOTP step cannot be replayed across distinct login challenges.
    replay_challenge = client.post("/v1/auth/login", json={"email": "mfa-flow@example.com", "password": "correct-horse-battery-staple"}).json()
    replay_step = client.post("/v1/auth/mfa/verify-login", json={"challenge_token": replay_challenge["challenge_token"], "code": next_code})
    assert replay_step.status_code == 401
    # A recovery code is also one-time and may be used instead of an authenticator code.
    second = client.post("/v1/auth/login", json={"email": "mfa-flow@example.com", "password": "correct-horse-battery-staple"}).json()
    recovered = client.post("/v1/auth/mfa/verify-login", json={"challenge_token": second["challenge_token"], "code": recovery_code})
    assert recovered.status_code == 200
    third = client.post("/v1/auth/login", json={"email": "mfa-flow@example.com", "password": "correct-horse-battery-staple"}).json()
    reused = client.post("/v1/auth/mfa/verify-login", json={"challenge_token": third["challenge_token"], "code": recovery_code})
    assert reused.status_code == 401


def test_owner_admin_privileges_require_mfa(client):
    response = client.post("/v1/auth/register", json={"email": "mfa-required@example.com", "password": "correct-horse-battery-staple", "full_name": "MFA Required", "organization_name": "MFA Required Org"})
    assert response.status_code == 202
    token = client.app.state.test_mailbox[-1]["body"].split("token=", 1)[1].split("\n", 1)[0]
    assert client.post("/v1/auth/verify-email", json={"token": token}).status_code == 200
    login = client.post("/v1/auth/login", json={"email": "mfa-required@example.com", "password": "correct-horse-battery-staple"}).json()
    headers = {"Authorization": f"Bearer {login['access_token']}", "X-Organization-ID": login["organization_id"]}
    blocked = client.get("/v1/audit", headers=headers)
    assert blocked.status_code == 403 and "MFA enrollment" in blocked.text


def test_org_invitation_acceptance_and_tenant_membership(client):
    owner, owner_headers = register(client, "invite-owner@example.com", "Invitation Org")
    invitee, invitee_headers = register(client, "invitee@example.com", "Invitee Home")
    created = client.post("/v1/organizations/invitations", headers=owner_headers, json={"email": "invitee@example.com", "role": "manager"})
    assert created.status_code == 202, created.text
    assert created.json()["email"] == "invitee@example.com"
    body = client.app.state.test_mailbox[-1]["body"]
    token = body.split("token=", 1)[1].split("\n", 1)[0]
    accepted = client.post("/v1/organizations/invitations/accept", headers=invitee_headers, json={"token": token})
    assert accepted.status_code == 200, accepted.text
    assert accepted.json()["organization_id"] == owner["organization_id"]
    assert accepted.json()["role"] == "manager"
    joined_headers = {"Authorization": invitee_headers["Authorization"], "X-Organization-ID": owner["organization_id"]}
    assert client.get("/v1/inquiries", headers=joined_headers).status_code == 200
    assert client.post("/v1/organizations/invitations/accept", headers=invitee_headers, json={"token": token}).status_code == 400

def test_invitation_is_bound_to_invited_email_and_replacement_invalidates_old(client):
    owner, owner_headers = register(client, "invite-owner2@example.com", "Invitation Org 2")
    invited, invited_headers = register(client, "intended@example.com", "Intended Home")
    other, other_headers = register(client, "other@example.com", "Other Home")
    first = client.post("/v1/organizations/invitations", headers=owner_headers, json={"email": "intended@example.com", "role": "member"})
    first_token = client.app.state.test_mailbox[-1]["body"].split("token=", 1)[1].split("\n", 1)[0]
    second = client.post("/v1/organizations/invitations", headers=owner_headers, json={"email": "intended@example.com", "role": "manager"})
    second_token = client.app.state.test_mailbox[-1]["body"].split("token=", 1)[1].split("\n", 1)[0]
    assert first.status_code == second.status_code == 202
    assert client.post("/v1/organizations/invitations/accept", headers=other_headers, json={"token": second_token}).status_code == 403
    assert client.post("/v1/organizations/invitations/accept", headers=invited_headers, json={"token": first_token}).status_code == 400
    assert client.post("/v1/organizations/invitations/accept", headers=invited_headers, json={"token": second_token}).status_code == 200

def test_admin_cannot_invite_another_admin(client):
    owner, owner_headers = register(client, "invite-owner3@example.com", "Invitation Org 3")
    admin_user, admin_headers_home = register(client, "invite-admin@example.com", "Admin Home")
    promoted = client.post("/v1/organizations/members", headers=owner_headers, json={"email": "invite-admin@example.com", "role": "admin"})
    assert promoted.status_code == 201
    admin_headers = {"Authorization": admin_headers_home["Authorization"], "X-Organization-ID": owner["organization_id"]}
    assert client.post("/v1/organizations/invitations", headers=admin_headers, json={"email": "new-admin@example.com", "role": "admin"}).status_code == 403
