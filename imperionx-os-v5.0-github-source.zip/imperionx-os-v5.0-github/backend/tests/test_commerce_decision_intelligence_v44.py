from test_inquiries import register
from test_business_network import _setup_pair


def _create_quoted_request(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    accepted = client.post(f"/v1/business/connections/{connection_id}/decision", headers=supplier,
                           json={"decision": "accepted", "shared_fields": []})
    assert accepted.status_code == 200
    request = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Commercial generator supply",
        "description": "Supply and deliver a commercial backup generator", "quantity": "2 units"})
    assert request.status_code == 201
    quote = client.post(f"/v1/business/purchase-requests/{request.json()['id']}/quotes", headers=supplier,
                        json={"amount_minor": 42500000, "currency": "KES", "validity_days": 14})
    assert quote.status_code == 201
    return buyer_id, buyer, supplier_id, supplier, request.json(), quote.json()


def test_commerce_decisions_are_tenant_scoped_and_explainable(client):
    buyer_id, buyer, supplier_id, supplier, request, quote = _create_quoted_request(client)
    buyer_result = client.get("/v1/intelligence/commerce-decisions", headers=buyer)
    supplier_result = client.get("/v1/intelligence/commerce-decisions", headers=supplier)
    assert buyer_result.status_code == 200
    assert supplier_result.status_code == 200
    assert buyer_result.json()["method"] == "transparent_commerce_rules_v1"
    assert buyer_result.json()["summary"]["attention_items"] == 0  # fresh quote is not overdue
    assert supplier_result.json()["summary"]["supplier_quote_response_samples"] == 1
    assert supplier_result.json()["summary"]["average_supplier_quote_response_hours"] is not None
    assert buyer_result.json()["external_actions_executed"] is False
    outsider_id, outsider = register(client, "commerce-intel-outsider@example.com", "Unrelated Company")
    outsider_result = client.get("/v1/intelligence/commerce-decisions", headers=outsider)
    assert outsider_result.status_code == 200
    assert outsider_result.json()["summary"]["quotes_recorded"] == 0
    assert outsider_result.json()["items"] == []


def test_commerce_decision_endpoint_requires_authentication(client):
    assert client.get("/v1/intelligence/commerce-decisions").status_code == 401


def test_commerce_decisions_flag_aged_quotes_and_stale_deals(client):
    from datetime import datetime, timedelta, timezone
    import app.main as main_module
    from app.models import BusinessTransaction

    buyer_id, buyer, supplier_id, supplier, request, quote = _create_quoted_request(client)
    accepted = client.post(f"/v1/business/quotes/{quote['id']}/accept", headers=buyer)
    assert accepted.status_code == 201

    db_generator = main_module.app.dependency_overrides[main_module.get_db]()
    db = next(db_generator)
    transaction_row = db.get(BusinessTransaction, accepted.json()["id"])
    transaction_row.updated_at = datetime.now(timezone.utc) - timedelta(hours=80)
    db.commit()
    try:
        next(db_generator)
    except StopIteration:
        pass

    result = client.get("/v1/intelligence/commerce-decisions", headers=buyer)
    assert result.status_code == 200
    assert result.json()["summary"]["stale_active_deals"] == 1
    assert any(item["kind"] == "deal_delay" for item in result.json()["items"])
