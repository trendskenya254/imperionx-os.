from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_render_blueprint_has_private_database_and_predeploy_migrations():
    source = (ROOT / "render.yaml").read_text()
    assert "name: imperionx-api" in source
    assert "name: imperionx-frontend" in source
    assert "name: imperionx-db" in source
    assert "preDeployCommand: alembic upgrade head" in source
    assert "healthCheckPath: /ready" in source
    assert "ipAllowList: []" in source
    assert "autoDeployTrigger: checksPass" in source


def test_webhook_delivery_is_disabled_in_initial_blueprint():
    source = (ROOT / "render.yaml").read_text()
    assert 'key: WEBHOOK_DELIVERY_ENABLED\n        value: "false"' in source
    assert "imperionx-webhook-worker" not in source


def test_release_versions_are_aligned():
    main = (ROOT / "backend/app/main.py").read_text()
    package = (ROOT / "frontend/package.json").read_text()
    smoke = (ROOT / "scripts/staging_smoke.py").read_text()
    assert 'version="5.0.0"' in main
    assert '"version": "5.0.0"' in package
    assert 'EXPECTED_VERSION = "5.0.0"' in smoke


def test_worker_waits_for_current_migration_head():
    worker_wait = (ROOT / "backend/scripts/wait_for_schema.py").read_text()
    assert "ScriptDirectory.from_config" in worker_wait
    assert 'SELECT version_num FROM alembic_version' in worker_wait
    assert "current == expected" in worker_wait


def test_frontend_normalizes_private_service_hostport_to_http_url():
    for relative in ("frontend/app/api/[...path]/route.ts", "frontend/app/api/session/route.ts"):
        source = (ROOT / relative).read_text()
        assert "API_HOST.includes('://')" in source
        assert "`http://${API_HOST}`" in source
