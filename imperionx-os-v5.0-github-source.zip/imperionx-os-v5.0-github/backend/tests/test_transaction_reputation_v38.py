from test_inquiries import register
from test_trust_commerce import _make_transaction


def test_transaction_feedback_requires_completed_transaction_and_is_one_per_side(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    payload = {"communication_rating": 5, "quality_rating": 4, "timeliness_rating": 5, "comment": "Delivered as agreed"}
    early = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json=payload)
    assert early.status_code == 409
    assert client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"}).status_code == 200
    created = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json=payload)
    assert created.status_code == 201, created.text
    duplicate = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json=payload)
    assert duplicate.status_code == 409
    invalid = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=supplier, json={**payload, "quality_rating": 6})
    assert invalid.status_code == 400
    accepted = client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=supplier, json=payload)
    assert accepted.status_code == 201


def test_reputation_is_connection_gated_and_hides_comments_and_reviewer_identity(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    assert client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"}).status_code == 200
    payload = {"communication_rating": 5, "quality_rating": 4, "timeliness_rating": 5, "comment": "Private feedback text"}
    assert client.post(f"/v1/business/transactions/{tx_id}/feedback", headers=buyer, json=payload).status_code == 201
    view = client.get(f"/v1/business/organizations/{supplier_id}/reputation", headers=buyer)
    assert view.status_code == 200
    assert view.json()["completed_transactions"] == 1
    assert view.json()["verified_transaction_feedback_count"] == 1
    assert view.json()["ratings"]["quality_rating"]["average"] == 4.0
    assert "Private feedback text" not in view.text and buyer_id not in view.text
    outsider_id, outsider = register(client, "reputation-outsider@example.com", "Reputation Outsider")
    assert client.get(f"/v1/business/organizations/{supplier_id}/reputation", headers=outsider).status_code == 404

