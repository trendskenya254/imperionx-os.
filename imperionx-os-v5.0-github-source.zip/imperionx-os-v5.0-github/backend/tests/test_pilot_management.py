from test_inquiries import register


def test_pilot_enrollment_lifecycle_and_goal_validation(client):
    org_id, headers = register(client, "enroll@example.com", "Enrollment Co")
    initial = client.get("/v1/pilot/enrollment", headers=headers)
    assert initial.status_code == 200
    assert initial.json()["status"] == "interested"
    updated = client.put("/v1/pilot/enrollment", headers=headers, json={
        "status": "active", "primary_goal": "Reduce time spent responding to customer inquiries",
        "baseline_minutes_per_day": 90, "target_minutes_saved_per_day": 30
    })
    assert updated.status_code == 200, updated.text
    assert updated.json()["status"] == "active"
    assert updated.json()["activated_at"]
    assert client.put("/v1/pilot/enrollment", headers=headers, json={"status": "launched"}).status_code == 400
    assert client.put("/v1/pilot/enrollment", headers=headers, json={"baseline_minutes_per_day": 2000}).status_code == 400


def test_pilot_feedback_is_tenant_scoped_and_role_protected(client):
    org_a, headers_a = register(client, "feedback-a@example.com", "Feedback A")
    org_b, headers_b = register(client, "feedback-b@example.com", "Feedback B")
    created = client.post("/v1/pilot/feedback", headers=headers_a, json={
        "category": "bug", "severity": "high", "message": "The inquiry filter does not retain its selection."
    })
    assert created.status_code == 201, created.text
    listed = client.get("/v1/pilot/feedback", headers=headers_a)
    assert listed.status_code == 200 and len(listed.json()) == 1
    assert listed.json()[0]["severity"] == "high"
    assert client.get("/v1/pilot/feedback", headers=headers_b).json() == []
    assert client.get("/v1/pilot/feedback").status_code == 401
    assert client.post("/v1/pilot/feedback", headers=headers_a, json={"category": "invalid", "message": "x"}).status_code == 400


def test_pilot_enrollment_is_tenant_isolated(client):
    org_a, headers_a = register(client, "tenant-pilot-a@example.com", "Pilot Tenant A")
    org_b, headers_b = register(client, "tenant-pilot-b@example.com", "Pilot Tenant B")
    changed = client.put("/v1/pilot/enrollment", headers=headers_a, json={"status": "active"})
    assert changed.status_code == 200
    assert client.get("/v1/pilot/enrollment", headers=headers_b).json()["status"] == "interested"
    cross = client.get("/v1/pilot/enrollment", headers={**headers_b, "X-Organization-ID": org_a})
    assert cross.status_code == 403
