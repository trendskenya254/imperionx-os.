from test_inquiries import register


def _setup_pair(client):
    source_id, source = register(client, "network-source@example.com", "Network Source")
    target_id, target = register(client, "network-target@example.com", "Network Target")
    client.put("/v1/business/profile", headers=target, json={
        "slug": "network-target", "tagline": "Trusted supplier", "city": "Mombasa",
        "capabilities": ["Solar installation", "Equipment supply"], "is_published": True
    })
    response = client.post("/v1/business/connections", headers=source, json={"target_slug": "network-target", "message": "Partnership"})
    assert response.status_code == 201, response.text
    return source_id, source, target_id, target, response.json()["id"]


def test_connection_decision_and_scoped_sharing(client):
    source_id, source, target_id, target, connection_id = _setup_pair(client)
    # Requester cannot decide its own incoming request.
    denied = client.post(f"/v1/business/connections/{connection_id}/decision", headers=source,
                         json={"decision": "accepted", "shared_fields": ["city"]})
    assert denied.status_code == 404
    accepted = client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                           json={"decision": "accepted", "shared_fields": ["city", "capabilities"]})
    assert accepted.status_code == 200, accepted.text
    shared = client.get("/v1/business/connections", headers=source).json()[0]
    assert shared["shared_profile"] == {"city": "Mombasa", "capabilities": ["Solar installation", "Equipment supply"]}
    # No target private email/account details are exposed.
    assert "public_email" not in shared["shared_profile"]
    repeat = client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                         json={"decision": "rejected"})
    assert repeat.status_code == 409


def test_connection_rejection_and_invalid_share_fields(client):
    source_id, source, target_id, target, connection_id = _setup_pair(client)
    invalid = client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                          json={"decision": "accepted", "shared_fields": ["password"]})
    assert invalid.status_code == 400
    rejected = client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                           json={"decision": "rejected"})
    assert rejected.status_code == 200 and rejected.json()["status"] == "rejected"


def test_referrals_require_accepted_connection_and_are_tenant_scoped(client):
    source_id, source, target_id, target, connection_id = _setup_pair(client)
    before = client.post("/v1/business/referrals", headers=source, json={"connection_id": connection_id, "description": "Introduce a buyer"})
    assert before.status_code == 404
    client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                json={"decision": "accepted", "shared_fields": []})
    created = client.post("/v1/business/referrals", headers=source, json={
        "connection_id": connection_id, "description": "Introduce a buyer to the supplier", "external_reference": "CRM-REF-42"
    })
    assert created.status_code == 201, created.text
    assert len(client.get("/v1/business/referrals", headers=source).json()) == 1
    assert len(client.get("/v1/business/referrals", headers=target).json()) == 1
    outsider_id, outsider = register(client, "network-outsider@example.com", "Network Outsider")
    assert client.get("/v1/business/referrals", headers=outsider).json() == []


def test_business_capabilities_are_validated(client):
    _, headers = register(client, "capability@example.com", "Capability Co")
    bad = client.put("/v1/business/profile", headers=headers, json={"slug": "capability-co", "capabilities": ["x"], "is_published": True})
    assert bad.status_code == 400
    good = client.put("/v1/business/profile", headers=headers, json={"slug": "capability-co", "capabilities": ["Wholesale supply", "Consulting"], "is_published": True})
    assert good.status_code == 200 and len(good.json()["capabilities"]) == 2
    assert client.get("/v1/discovery/businesses?q=Capability").json()["items"][0]["capabilities"] == ["Wholesale supply", "Consulting"]
