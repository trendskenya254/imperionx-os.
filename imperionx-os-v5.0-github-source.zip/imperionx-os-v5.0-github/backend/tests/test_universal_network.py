from test_inquiries import register
from test_business_network import _setup_pair


def test_unified_network_overview_is_tenant_scoped_and_excludes_private_data(client):
    source_id, source, target_id, target, connection_id = _setup_pair(client)
    before = client.get("/v1/network/overview", headers=source)
    assert before.status_code == 200, before.text
    overview = before.json()
    assert overview["api_version"] == "5.0.0"
    assert overview["network"]["pending_outgoing"] == 1
    assert overview["network"]["accepted_connections"] == 0
    assert overview["business"]["profile_published"] is False
    assert overview["commerce"]["funds_held_by_platform"] is False

    accepted = client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                           json={"decision": "accepted", "shared_fields": ["city"]})
    assert accepted.status_code == 200
    after = client.get("/v1/network/overview", headers=source).json()
    assert after["network"]["accepted_connections"] == 1
    assert len(after["network"]["nodes"]) == 1
    assert after["network"]["nodes"][0]["name"] == "Network Target"
    assert after["network"]["edges"][0]["shared_fields"] == ["city"]
    assert "public_email" not in after["network"]["nodes"][0]

    outsider_id, outsider = register(client, "overview-outsider@example.com", "Overview Outsider")
    outsider_view = client.get("/v1/network/overview", headers=outsider).json()
    assert outsider_view["network"]["accepted_connections"] == 0
    assert outsider_view["network"]["nodes"] == []


def test_network_overview_requires_authenticated_tenant(client):
    assert client.get("/v1/network/overview").status_code == 401
