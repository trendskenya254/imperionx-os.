from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[2]

def test_staging_smoke_targets_v48():
    source = (ROOT / "scripts" / "staging_smoke.py").read_text()
    assert 'EXPECTED_VERSION = "5.0.0"' in source
    assert 'imperionx-staging-smoke/5.0' in source


def test_pilot_gate_is_non_destructive_and_requires_evidence():
    source = (ROOT / "scripts" / "pilot_gate.py").read_text()
    assert '"mode": "non_destructive"' in source
    for key in ("APPROVED_STAGING_OWNER", "INCIDENT_CONTACT", "BACKUP_OFFSITE_URI", "RESTORE_DRILL_EVIDENCE", "SECURITY_REVIEW_EVIDENCE"):
        assert key in source
    assert "migrate" in source.lower()
    assert "never deploys" in source


def test_readiness_version_is_aligned():
    source = (ROOT / "backend" / "app" / "main.py").read_text()
    assert 'version="5.0.0"' in source
    assert '"version": "5.0.0"' in source
