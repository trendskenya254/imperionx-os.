from test_inquiries import register


def _publish(client, headers, slug, offers=None, seeks=None, capabilities=None):
    response = client.put("/v1/business/profile", headers=headers, json={
        "slug": slug, "tagline": "Published business profile", "is_published": True,
        "offers": offers or [], "seeks": seeks or [], "capabilities": capabilities or []
    })
    assert response.status_code == 200, response.text
    return response.json()


def test_supplier_matching_uses_published_offers_and_explains_overlap(client):
    _, buyer = register(client, "match-buyer@example.com", "Buyer Co")
    _, supplier = register(client, "match-supplier@example.com", "Supplier Co")
    _, hidden = register(client, "match-hidden@example.com", "Hidden Co")
    _publish(client, buyer, "match-buyer", seeks=["solar panels", "battery storage"])
    _publish(client, supplier, "match-supplier", offers=["solar panels", "battery storage", "installation"])
    client.put("/v1/business/profile", headers=hidden, json={
        "slug": "match-hidden", "offers": ["solar panels"], "is_published": False
    })

    response = client.get("/v1/discovery/matches?direction=find_suppliers", headers=buyer)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["total"] == 1
    match = body["items"][0]
    assert match["name"] == "Supplier Co"
    assert match["matching_capabilities"] == ["battery storage", "solar panels"]
    assert match["relevance"] == "strong"
    assert "Capability match: solar panels" in match["match_reasons"]
    assert "public_email" not in match
    assert "recipient approval" in body["privacy"]


def test_buyer_matching_uses_published_seeks(client):
    _, supplier = register(client, "match-supplier2@example.com", "Supplier Two")
    _, buyer = register(client, "match-buyer2@example.com", "Buyer Two")
    _publish(client, supplier, "match-supplier-two", offers=["Logistics", "cold storage"])
    _publish(client, buyer, "match-buyer-two", seeks=["logistics"])
    response = client.get("/v1/discovery/matches?direction=find_buyers", headers=supplier)
    assert response.status_code == 200, response.text
    assert response.json()["total"] == 1
    assert response.json()["items"][0]["name"] == "Buyer Two"
    assert response.json()["items"][0]["matching_capabilities"] == ["logistics"]


def test_matching_requires_auth_profile_and_valid_direction(client):
    assert client.get("/v1/discovery/matches").status_code == 401
    _, headers = register(client, "match-empty@example.com", "Empty Match Co")
    assert client.get("/v1/discovery/matches", headers=headers).status_code == 409
    _publish(client, headers, "match-empty", capabilities=["manufacturing"])
    assert client.get("/v1/discovery/matches?direction=unknown", headers=headers).status_code == 400
    assert client.get("/v1/discovery/matches?limit=51", headers=headers).status_code == 400


def test_profile_matching_labels_are_validated(client):
    _, headers = register(client, "match-validation@example.com", "Validation Co")
    bad = client.put("/v1/business/profile", headers=headers, json={
        "slug": "match-validation", "offers": ["x"], "is_published": True
    })
    assert bad.status_code == 400
