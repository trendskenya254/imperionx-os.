from pathlib import Path

import pytest
from pydantic import ValidationError
from sqlalchemy.dialects import postgresql

from app.config import Settings
from app.webhook_delivery import _claim_one

ROOT = Path(__file__).resolve().parents[2]


def test_compose_runs_migrations_as_a_one_shot_before_api_and_worker():
    compose = (ROOT / "docker-compose.yml").read_text()
    assert "  migrate:" in compose
    assert 'command: ["alembic", "upgrade", "head"]' in compose
    assert "service_completed_successfully" in compose
    assert "WEBHOOK_WORKER_ENABLED:-false" in compose
    assert "WEBHOOK_DELIVERY_ENABLED: \"false\"" in compose


def test_api_image_does_not_run_schema_migrations_on_each_replica():
    dockerfile = (ROOT / "backend" / "Dockerfile").read_text()
    assert "alembic upgrade" not in dockerfile
    assert '"app.main:app"' in dockerfile


def test_database_pool_settings_are_bounded():
    with pytest.raises(ValidationError):
        Settings(db_pool_size=0)
    with pytest.raises(ValidationError):
        Settings(db_max_overflow=101)
    with pytest.raises(ValidationError):
        Settings(db_pool_timeout_seconds=0)
    valid = Settings(db_pool_size=8, db_max_overflow=12, db_pool_timeout_seconds=20)
    assert valid.db_pool_size == 8


def test_worker_claim_query_uses_postgres_skip_locked():
    class NoRowsSession:
        statement = None

        def scalar(self, statement):
            self.statement = statement
            return None

    session = NoRowsSession()
    assert _claim_one(session, __import__("datetime").datetime.now(__import__("datetime").timezone.utc)) is None
    sql = str(session.statement.compile(dialect=postgresql.dialect()))
    assert "FOR UPDATE SKIP LOCKED" in sql
    assert "webhook_deliveries" in sql


def test_release_docs_explain_at_least_once_delivery_and_receiver_deduplication():
    docs = (ROOT / "docs" / "release-v3.5.md").read_text().lower()
    assert "at-least-once" in docs
    assert "idempotency-key" in docs
    assert "sqlite" in docs and "postgresql" in docs


def test_v36_staging_smoke_requires_https_and_checks_both_endpoints():
    script = (ROOT / "scripts" / "staging_smoke.py").read_text()
    assert 'startswith("https://")' in script
    assert 'check(base_url, "/health")' in script
    assert 'check(base_url, "/ready")' in script
    assert 'EXPECTED_VERSION = "5.0.0"' in script
    assert "timeout=TIMEOUT_SECONDS" in script


def test_backup_verification_is_non_destructive_and_checks_archive():
    script = (ROOT / "scripts" / "verify_backup.sh").read_text()
    assert "pg_restore --list" in script
    assert "sha256sum" in script
    assert "pg_restore --clean" not in script


def test_v36_docs_distinguish_archive_validation_from_restore_drill():
    docs = (ROOT / "docs" / "release-v3.6.md").read_text().lower()
    assert "pg_restore --list" in docs
    assert "restore" in docs
    assert "backup" in docs
    assert "canary" in docs
    assert "rollback" in docs
