from app.security import totp_code


def create_verified_owner(client, email, org_name):
    registered = client.post("/v1/auth/register", json={
        "email": email,
        "password": "correct-horse-battery-staple",
        "full_name": "Business Owner",
        "organization_name": org_name,
    })
    assert registered.status_code == 202
    body = client.app.state.test_mailbox[-1]["body"]
    token = body.split("token=", 1)[1].split("\n", 1)[0]
    assert client.post("/v1/auth/verify-email", json={"token": token}).status_code == 200
    login = client.post("/v1/auth/login", json={"email": email, "password": "correct-horse-battery-staple"})
    assert login.status_code == 200
    data = login.json()
    headers = {"Authorization": f"Bearer {data['access_token']}", "X-Organization-ID": data["organization_id"]}
    secret = client.post("/v1/auth/mfa/enroll", headers=headers).json()["secret"]
    assert client.post("/v1/auth/mfa/enable", headers=headers, json={"code": totp_code(secret)}).status_code == 200
    return headers


def test_sales_performance_and_insights_are_tenant_scoped(client):
    headers = create_verified_owner(client, "sales-owner@example.com", "Sales Business")
    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "Please send a quotation for 10 units."}).json()
    sale_payload = {"description": "Quotation converted to sale", "amount_minor": 125000, "currency": "KES", "inquiry_id": inquiry["id"]}
    recorded = client.post("/v1/sales", headers=headers, json=sale_payload)
    assert recorded.status_code == 201, recorded.text
    assert recorded.json()["amount_minor"] == 125000
    assert client.post("/v1/sales", headers=headers, json=sale_payload).status_code == 409

    metrics = client.get("/v1/performance/summary?days=30", headers=headers)
    assert metrics.status_code == 200
    data = metrics.json()
    assert data["inquiries_created"] == 1
    assert data["converted_inquiries"] == 1
    assert data["conversion_rate_percent"] == 100.0
    assert data["revenue_by_currency"] == [{"currency": "KES", "sales_count": 1, "revenue_minor": 125000, "average_sale_minor": 125000}]

    insights = client.get("/v1/performance/insights?days=30", headers=headers)
    assert insights.status_code == 200
    assert insights.json()["method"] == "transparent_rules_v1"
    assert insights.json()["insights"]

    other_headers = create_verified_owner(client, "other-sales@example.com", "Other Sales Business")
    assert client.get("/v1/sales", headers=other_headers).json() == []
    other_metrics = client.get("/v1/performance/summary", headers=other_headers).json()
    assert other_metrics["inquiries_created"] == 0
    assert other_metrics["converted_inquiries"] == 0
    assert client.post("/v1/sales", headers=other_headers, json=sale_payload).status_code == 404


def test_sales_validation_and_period_bounds(client):
    headers = create_verified_owner(client, "sales-validation@example.com", "Validation Business")
    assert client.post("/v1/sales", headers=headers, json={"description": "Bad currency", "amount_minor": 100, "currency": "KESX"}).status_code == 422
    assert client.post("/v1/sales", headers=headers, json={"description": "Zero sale", "amount_minor": 0, "currency": "KES"}).status_code == 422
    assert client.get("/v1/performance/summary?days=999", headers=headers).status_code == 400


def test_universal_intelligence_customer_product_trends_and_run_rate(client):
    headers = create_verified_owner(client, "intelligence-owner@example.com", "Intelligence Business")
    first = client.post("/v1/inquiries", headers=headers, json={
        "message": "I need a quotation for a laptop.", "customer_name": "A Customer", "customer_contact": "buyer@example.com"
    }).json()
    second = client.post("/v1/inquiries", headers=headers, json={
        "message": "I need another laptop.", "customer_name": "A Customer", "customer_contact": " BUYER@example.com "
    }).json()
    for inquiry, label, amount in [(first, "Laptop Pro", 250000), (second, "Laptop Pro", 150000)]:
        response = client.post("/v1/sales", headers=headers, json={
            "description": "Completed order", "product_or_service": label,
            "amount_minor": amount, "currency": "KES", "inquiry_id": inquiry["id"]
        })
        assert response.status_code == 201, response.text
        assert response.json()["product_or_service"] == label

    customers = client.get("/v1/intelligence/customers", headers=headers).json()
    assert customers["identified_customers"] == 1
    assert customers["repeat_customers"] == 1
    assert customers["repeat_customer_rate_percent"] == 100.0
    assert customers["customers_with_recorded_sales"] == 1
    assert customers["repeat_buyers"] == 1

    products = client.get("/v1/intelligence/products?days=90", headers=headers).json()
    assert products["items"] == [{
        "product_or_service": "Laptop Pro", "currency": "KES", "sales_count": 2,
        "revenue_minor": 400000, "average_sale_minor": 200000
    }]

    trends = client.get("/v1/intelligence/trends?days=30", headers=headers).json()
    assert trends["period_days"] == 30
    assert len(trends["series"]) == 1
    assert trends["series"][0]["currency"] == "KES"
    assert trends["series"][0]["revenue_minor"] == 400000

    projection = client.get("/v1/intelligence/forecast?days=30&horizon_days=30", headers=headers).json()
    assert projection["is_prediction"] is False
    assert projection["projections"][0]["run_rate_projection_minor"] == 400000

    other = create_verified_owner(client, "intelligence-other@example.com", "Other Intelligence Business")
    assert client.get("/v1/intelligence/customers", headers=other).json()["identified_customers"] == 0
    assert client.get("/v1/intelligence/products", headers=other).json()["items"] == []
    assert client.get("/v1/intelligence/trends", headers=other).json()["series"] == []
    assert client.get("/v1/intelligence/forecast", headers=other).json()["projections"] == []


def test_universal_intelligence_bounds_and_optional_product_label(client):
    headers = create_verified_owner(client, "intelligence-bounds@example.com", "Bounds Business")
    assert client.get("/v1/intelligence/products?days=999", headers=headers).status_code == 400
    assert client.get("/v1/intelligence/trends?days=0", headers=headers).status_code == 400
    assert client.get("/v1/intelligence/forecast?horizon_days=999", headers=headers).status_code == 400
    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "Service request from customer"}).json()
    sale = client.post("/v1/sales", headers=headers, json={
        "description": "Consulting session", "amount_minor": 10000, "currency": "KES", "inquiry_id": inquiry["id"]
    })
    assert sale.status_code == 201
    assert sale.json()["product_or_service"] is None
    products = client.get("/v1/intelligence/products", headers=headers).json()
    assert products["items"][0]["product_or_service"] == "Consulting session"


def test_large_sale_amount_uses_64_bit_minor_units(client):
    headers = create_verified_owner(client, "large-sale@example.com", "Large Sale Business")
    response = client.post("/v1/sales", headers=headers, json={
        "description": "Enterprise annual contract", "amount_minor": 4_500_000_000, "currency": "KES"
    })
    assert response.status_code == 201, response.text
    assert response.json()["amount_minor"] == 4_500_000_000


def test_growth_action_queue_is_explainable_and_tenant_scoped(client):
    headers = create_verified_owner(client, "growth-owner@example.com", "Growth Business")
    inquiry = client.post("/v1/inquiries", headers=headers, json={
        "message": "Please provide a quotation", "subject": "Bulk order quotation"
    }).json()
    queue = client.get("/v1/growth/action-queue", headers=headers)
    assert queue.status_code == 200
    data = queue.json()
    assert data["method"] == "transparent_rules_v1"
    assert data["external_actions_executed"] is False
    assert data["total_actions"] == 1
    action = data["items"][0]
    assert action["inquiry_id"] == inquiry["id"]
    assert action["subject"] == "Bulk order quotation"
    assert action["reason"] == "No team member is assigned"
    assert "Assign an owner" in action["recommended_action"]

    other = create_verified_owner(client, "growth-other@example.com", "Other Growth Business")
    assert client.get("/v1/growth/action-queue", headers=other).json()["items"] == []

    user_id = client.get("/v1/auth/me", headers=headers).json()["id"]
    assert client.patch(f"/v1/inquiries/{inquiry['id']}/assignment", headers=headers,
                        json={"user_id": user_id}).status_code == 200
    assert client.patch(f"/v1/inquiries/{inquiry['id']}/status", headers=headers,
                        json={"status": "resolved"}).status_code == 200
    assert client.get("/v1/growth/action-queue", headers=headers).json()["items"] == []


def test_growth_action_queue_escalates_stale_inquiries(client):
    from datetime import datetime, timedelta, timezone
    from app.db import get_db
    from app.models import Inquiry
    headers = create_verified_owner(client, "growth-stale@example.com", "Stale Growth Business")
    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "An old unanswered request"}).json()
    db = next(client.app.dependency_overrides[get_db]())
    try:
        record = db.get(Inquiry, inquiry["id"])
        record.updated_at = datetime.now(timezone.utc) - timedelta(days=4)
        db.commit()
    finally:
        db.close()
    queue = client.get("/v1/growth/action-queue", headers=headers).json()
    assert queue["items"][0]["priority"] == "high"
    assert "No update for" in queue["items"][0]["reason"]
    assert queue["items"][0]["age_hours"] >= 72
