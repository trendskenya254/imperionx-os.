import pytest
from app.ai import AIGateway, SafeDemoProvider, build_ai_gateway

class BadProvider:
    name = "bad"
    def __init__(self, payload): self.payload = payload
    def generate(self, inquiry, business_context): return self.payload

def test_safe_demo_classifies_urgent_complaint_and_requires_review():
    result = AIGateway(SafeDemoProvider()).propose_inquiry_response("URGENT: damaged order, please refund")
    assert result["category"] == "complaint"
    assert result["priority"] == "urgent"
    assert result["requires_human_review"] is True
    assert result["external_action_executed"] is False

def test_gateway_rejects_unknown_category():
    payload = {"category": "send_money", "priority": "normal", "summary": "x", "draft_response": "y", "suggested_next_step": "z"}
    with pytest.raises(ValueError): AIGateway(BadProvider(payload)).propose_inquiry_response("hello")

def test_gateway_rejects_oversized_inquiry():
    with pytest.raises(ValueError): AIGateway().propose_inquiry_response("x" * 10001)

def test_live_provider_requires_explicit_credentials():
    with pytest.raises(RuntimeError): build_ai_gateway("openai-compatible")

def test_unknown_provider_fails_closed():
    with pytest.raises(RuntimeError): build_ai_gateway("unknown")
