from test_inquiries import register


def test_pilot_readiness_is_tenant_scoped_and_reports_setup_steps(client):
    org_id, headers = register(client, "pilot-owner@example.com", "Pilot Business")
    response = client.get("/v1/pilot/readiness", headers=headers)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["organization_id"] == org_id
    assert body["pilot_status"] == "setup_in_progress"
    assert body["completion_percent"] == 0
    assert body["total_steps"] == 4
    assert body["external_actions_enabled"] is False

    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "Please send details about your services."})
    assert inquiry.status_code == 201
    refreshed = client.get("/v1/pilot/readiness", headers=headers).json()
    assert refreshed["steps"][2]["complete"] is True
    assert refreshed["completion_percent"] == 25


def test_pilot_readiness_requires_authenticated_tenant(client):
    assert client.get("/v1/pilot/readiness").status_code == 401
    org_id, headers = register(client, "pilot-a@example.com", "Pilot A")
    other_org, other_headers = register(client, "pilot-b@example.com", "Pilot B")
    denied = client.get("/v1/pilot/readiness", headers={**other_headers, "X-Organization-ID": org_id})
    assert denied.status_code == 403
    own = client.get("/v1/pilot/readiness", headers=other_headers)
    assert own.status_code == 200 and own.json()["organization_id"] == other_org


def test_registration_captures_industry_neutral_business_profile(client):
    response = client.post("/v1/auth/register", json={
        "email": "profile-owner@example.com",
        "password": "correct-horse-battery-staple",
        "full_name": "Profile Owner",
        "organization_name": "Universal Trade House",
        "industry": "Wholesale and distribution",
        "country_code": "KE",
    })
    assert response.status_code == 202, response.text
    assert response.json()["email_sent"] is True
    token = client.app.state.test_mailbox[-1]["body"].split("#token=", 1)[1].split()[0]
    verified = client.post("/v1/auth/verify-email", json={"token": token})
    assert verified.status_code == 200
    login = client.post("/v1/auth/login", json={"email": "profile-owner@example.com", "password": "correct-horse-battery-staple"})
    assert login.status_code == 200, login.text
    data = login.json()
    headers = {"Authorization": f"Bearer {data['access_token']}", "X-Organization-ID": data["organization_id"]}
    readiness = client.get("/v1/pilot/readiness", headers=headers).json()
    assert readiness["steps"][0]["complete"] is True
    assert "Wholesale and distribution" not in str(readiness)  # checklist does not expose profile data


def test_pilot_metrics_are_aggregated_tenant_scoped_and_bounded(client):
    org_a, headers_a = register(client, "metrics-a@example.com", "Metrics A")
    org_b, headers_b = register(client, "metrics-b@example.com", "Metrics B")
    created = client.post("/v1/inquiries", headers=headers_a, json={
        "customer_name": "Private Customer", "customer_contact": "private@example.com",
        "subject": "Private subject", "message": "Private message content"
    })
    assert created.status_code == 201, created.text
    response = client.get("/v1/pilot/metrics?days=30", headers=headers_a)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["inquiries_created"] == 1
    assert body["inquiries_open"] == 1
    assert body["active_team_members"] >= 1
    assert body["external_actions_executed"] is False
    assert "Private Customer" not in str(body)
    assert "private@example.com" not in str(body)
    assert "Private message content" not in str(body)
    other = client.get("/v1/pilot/metrics", headers=headers_b).json()
    assert other["inquiries_created"] == 0
    assert other["sales_count"] == 0
    assert client.get("/v1/pilot/metrics?days=6", headers=headers_a).status_code == 400
    assert client.get("/v1/pilot/metrics?days=91", headers=headers_a).status_code == 400
    assert client.get("/v1/pilot/metrics").status_code == 401
