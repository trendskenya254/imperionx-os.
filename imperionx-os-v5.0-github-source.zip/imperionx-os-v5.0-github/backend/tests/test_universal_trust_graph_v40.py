from test_inquiries import register


def _connect(client, requester_headers, target_headers, target_slug):
    response = client.post("/v1/business/connections", headers=requester_headers,
                           json={"target_slug": target_slug, "message": "Network link"})
    assert response.status_code == 201, response.text
    connection_id = response.json()["id"]
    accepted = client.post(f"/v1/business/connections/{connection_id}/decision",
                           headers=target_headers,
                           json={"decision": "accepted", "shared_fields": []})
    assert accepted.status_code == 200, accepted.text
    return connection_id


def _publish(client, headers, slug, discoverable=False):
    response = client.put("/v1/business/profile", headers=headers, json={
        "slug": slug, "tagline": "Independent business", "is_published": True
    })
    assert response.status_code == 200, response.text
    if discoverable:
        enabled = client.put("/v1/business/network-discovery", headers=headers,
                             json={"enabled": True})
        assert enabled.status_code == 200, enabled.text


def test_trust_graph_exposes_direct_links_and_only_opted_in_second_degree(client):
    a_id, a = register(client, "graph-a@example.com", "Graph A")
    b_id, b = register(client, "graph-b@example.com", "Graph B")
    c_id, c = register(client, "graph-c@example.com", "Graph C")
    d_id, d = register(client, "graph-d@example.com", "Graph D")
    _publish(client, b, "graph-b")
    _publish(client, c, "graph-c", discoverable=True)
    _publish(client, d, "graph-d", discoverable=False)
    _connect(client, a, b, "graph-b")
    _connect(client, b, c, "graph-c")
    _connect(client, b, d, "graph-d")

    first = client.get("/v1/network/trust-graph?depth=1", headers=a)
    assert first.status_code == 200, first.text
    assert [n["organization_id"] for n in first.json()["nodes"]] == [b_id]

    second = client.get("/v1/network/trust-graph?depth=2", headers=a)
    assert second.status_code == 200, second.text
    body = second.json()
    by_id = {n["organization_id"]: n for n in body["nodes"]}
    assert set(by_id) == {b_id, c_id}
    assert by_id[c_id]["relationship"] == "second_degree"
    assert by_id[c_id]["mutual_connection_count"] == 1
    assert "Graph B" not in str(body["edges"])
    assert body["summary"]["composite_trust_score"] is None
    assert body["summary"]["discovery_requires_opt_in"] is True
    assert "private relationship paths" in body["privacy"]


def test_network_discovery_is_opt_in_and_requires_published_profile(client):
    _, headers = register(client, "graph-preference@example.com", "Graph Preference")
    missing = client.put("/v1/business/network-discovery", headers=headers,
                         json={"enabled": True})
    assert missing.status_code == 409
    _publish(client, headers, "graph-preference", discoverable=False)
    enabled = client.put("/v1/business/network-discovery", headers=headers,
                         json={"enabled": True})
    assert enabled.status_code == 200
    assert enabled.json()["network_discoverable"] is True
    disabled = client.put("/v1/business/network-discovery", headers=headers,
                          json={"enabled": False})
    assert disabled.status_code == 200
    assert disabled.json()["network_discoverable"] is False


def test_trust_graph_rejects_invalid_depth_and_limits(client):
    _, headers = register(client, "graph-validation@example.com", "Graph Validation")
    assert client.get("/v1/network/trust-graph?depth=3", headers=headers).status_code == 400
    assert client.get("/v1/network/trust-graph?limit=201", headers=headers).status_code == 400
    assert client.get("/v1/network/trust-graph").status_code == 401
