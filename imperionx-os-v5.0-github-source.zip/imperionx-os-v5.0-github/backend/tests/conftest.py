import os
os.environ["DATABASE_URL"] = "sqlite://"

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient
from app.main import app
import app.main as main_module
from app.config import settings
from cryptography.fernet import Fernet
from app.db import Base, get_db

@pytest.fixture()
def client(monkeypatch):
    test_database_url = os.getenv("TEST_DATABASE_URL", "sqlite://")
    connect_args = {"check_same_thread": False} if test_database_url.startswith("sqlite") else {}
    engine_options = {"connect_args": connect_args}
    if test_database_url in ("sqlite://", "sqlite:///:memory:"):
        engine_options["poolclass"] = StaticPool
    engine = create_engine(test_database_url, **engine_options)
    TestingSession = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(bind=engine)
    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()
    app.dependency_overrides[get_db] = override_get_db
    app.state.test_mailbox = []
    monkeypatch.setattr(settings, "mfa_encryption_key", Fernet.generate_key().decode())
    def fake_deliver(recipient, subject, body):
        app.state.test_mailbox.append({"recipient": recipient, "subject": subject, "body": body})
        return True
    monkeypatch.setattr(main_module, "deliver_email", fake_deliver)
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=engine)
    engine.dispose()
