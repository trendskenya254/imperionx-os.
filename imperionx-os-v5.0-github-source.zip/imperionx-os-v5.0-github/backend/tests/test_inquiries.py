def register(client, email="owner@example.com", organization="Acme Services", name="Owner Person"):
    response = client.post("/v1/auth/register", json={
        "email": email, "password": "correct-horse-battery-staple", "full_name": name,
        "organization_name": organization,
    })
    assert response.status_code == 202, response.text
    body = client.app.state.test_mailbox[-1]["body"]
    token = body.split("token=", 1)[1].split("\n", 1)[0]
    verified = client.post("/v1/auth/verify-email", json={"token": token})
    assert verified.status_code == 200, verified.text
    login = client.post("/v1/auth/login", json={"email": email, "password": "correct-horse-battery-staple"})
    assert login.status_code == 200, login.text
    data = login.json()
    headers = {"Authorization": f"Bearer {data['access_token']}", "X-Organization-ID": data["organization_id"]}
    from app.security import totp_code
    secret = client.post("/v1/auth/mfa/enroll", headers=headers).json()["secret"]
    enabled = client.post("/v1/auth/mfa/enable", headers=headers, json={"code": totp_code(secret)})
    assert enabled.status_code == 200, enabled.text
    return data["organization_id"], headers

def test_inquiry_draft_and_approval_flow(client):
    org_id, headers = register(client)
    headers["Idempotency-Key"] = "inquiry-001"
    created = client.post("/v1/inquiries", headers=headers, json={"message": "What is your product price and delivery cost?", "customer_name": "A customer"})
    assert created.status_code == 201
    inquiry = created.json()
    duplicate = client.post("/v1/inquiries", headers=headers, json={"message": "Different payload should not duplicate"})
    assert duplicate.status_code == 201 and duplicate.json()["id"] == inquiry["id"]
    run_response = client.post(f"/v1/inquiries/{inquiry['id']}/draft", headers=headers)
    assert run_response.status_code == 201
    run = run_response.json()
    assert run["status"] == "pending_approval"
    assert run["proposed_action"]["provider"] == "safe-demo"
    assert run["proposed_action"]["requires_human_review"] is True
    assert run["proposed_action"]["external_action_executed"] is False
    approved = client.post(f"/v1/runs/{run['id']}/approve", headers=headers, json={"note": "Reviewed"})
    assert approved.status_code == 200 and approved.json()["status"] == "approved"
    assert client.get("/v1/inquiries", headers=headers).json()[0]["status"] == "approved"
    audit = client.get("/v1/audit", headers=headers)
    assert audit.status_code == 200
    assert any(item["action"] == "workflow_run.approved" for item in audit.json())

def test_cross_tenant_access_is_denied(client):
    org_a, headers_a = register(client, "a@example.com", "Business A")
    org_b, headers_b = register(client, "b@example.com", "Business B")
    created = client.post("/v1/inquiries", headers=headers_a, json={"message": "Please send me a quotation."})
    inquiry_id = created.json()["id"]
    denied_list = client.get("/v1/inquiries", headers={**headers_b, "X-Organization-ID": org_a})
    assert denied_list.status_code == 403
    denied_draft = client.post(f"/v1/inquiries/{inquiry_id}/draft", headers=headers_b)
    assert denied_draft.status_code == 404
    assert client.get("/v1/inquiries", headers=headers_b).json() == []

def test_reject_decision_updates_inquiry(client):
    org_id, headers = register(client)
    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "I need help with a damaged order."}).json()
    run = client.post(f"/v1/inquiries/{inquiry['id']}/draft", headers=headers).json()
    rejected = client.post(f"/v1/runs/{run['id']}/reject", headers=headers, json={"note": "Needs investigation"})
    assert rejected.status_code == 200
    assert client.get("/v1/inquiries", headers=headers).json()[0]["status"] == "rejected"

def test_inquiry_assignment_and_status_lifecycle(client):
    org_id, headers = register(client)
    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "Please help me with an order."}).json()
    current_user_id = client.get("/v1/auth/me", headers=headers).json()["id"]
    assigned = client.patch(f"/v1/inquiries/{inquiry['id']}/assignment", headers=headers, json={"user_id": current_user_id})
    assert assigned.status_code == 200, assigned.text
    assert assigned.json()["assigned_to_user_id"] == current_user_id
    mine = client.get("/v1/inquiries?assigned_to_me=true", headers=headers)
    assert [row["id"] for row in mine.json()] == [inquiry["id"]]
    changed = client.patch(f"/v1/inquiries/{inquiry['id']}/status", headers=headers, json={"status": "in_progress"})
    assert changed.status_code == 200
    assert changed.json()["status"] == "in_progress"
    filtered = client.get("/v1/inquiries?status=in_progress", headers=headers)
    assert [row["id"] for row in filtered.json()] == [inquiry["id"]]
    assert client.get("/v1/inquiries?status=not-a-status", headers=headers).status_code == 400


def test_inquiry_cannot_be_assigned_to_non_member(client):
    org_id, headers = register(client)
    other_org, other_headers = register(client, "outside@example.com", "Outside Org")
    inquiry = client.post("/v1/inquiries", headers=headers, json={"message": "Need a quotation."}).json()
    denied = client.patch(f"/v1/inquiries/{inquiry['id']}/assignment", headers=headers, json={"user_id": "not-a-member-id"})
    assert denied.status_code == 400
    cross_tenant = client.patch(f"/v1/inquiries/{inquiry['id']}/status", headers=other_headers, json={"status": "resolved"})
    assert cross_tenant.status_code == 404


def test_operations_summary_and_activity_are_tenant_scoped(client):
    org_id, headers = register(client)
    first = client.post("/v1/inquiries", headers=headers, json={"message": "First customer question"}).json()
    second = client.post("/v1/inquiries", headers=headers, json={"message": "Second customer question"}).json()
    user_id = client.get("/v1/auth/me", headers=headers).json()["id"]
    assigned = client.patch(f"/v1/inquiries/{first['id']}/assignment", headers=headers, json={"user_id": user_id})
    assert assigned.status_code == 200
    summary = client.get("/v1/operations/summary", headers=headers)
    assert summary.status_code == 200
    data = summary.json()
    assert data["total_inquiries"] == 2
    assert data["open_inquiries"] == 2
    assert data["unassigned_open"] == 1
    assert data["status_counts"]["new"] == 2
    assert data["team_workload"][0]["open_assigned"] == 1
    activity = client.get("/v1/operations/activity?limit=10", headers=headers)
    assert activity.status_code == 200
    assert any(event["action"] == "inquiry.assigned" for event in activity.json())
    assert client.get("/v1/operations/activity?limit=100", headers=headers).status_code == 400
    other_org, other_headers = register(client, "other-ops@example.com", "Other Ops")
    assert client.get("/v1/operations/summary", headers=other_headers).json()["total_inquiries"] == 0
    other_activity = client.get("/v1/operations/activity", headers=other_headers).json()
    assert all(event["action"] != "inquiry.created" for event in other_activity)
    assert all(event["action"] != "inquiry.assigned" for event in other_activity)
