from test_inquiries import register


def test_pilot_activation_requires_all_readiness_steps(client):
    _, headers = register(client, "activate-gate@example.com", "Activation Gate Co")
    response = client.post("/v1/pilot/activate", headers=headers)
    assert response.status_code == 409
    body = response.json()["detail"]
    assert body["message"] == "Pilot prerequisites are incomplete"
    assert set(body["incomplete_steps"]) == {"business_profile", "team_access", "first_inquiry", "workflow"}
    enrollment = client.get("/v1/pilot/enrollment", headers=headers)
    assert enrollment.json()["status"] == "interested"


def test_pilot_activation_is_owner_admin_only(client):
    _, headers = register(client, "activate-role@example.com", "Activation Role Co")
    # The registered owner is allowed to inspect readiness but activation is not
    # possible until the tenant completes its setup checklist.
    assert client.get("/v1/pilot/readiness", headers=headers).status_code == 200
    assert client.post("/v1/pilot/activate", headers={}).status_code == 401


def test_pilot_activation_records_audit_when_ready(client):
    from app.models import Membership, Inquiry, Workflow, User, Organization
    from app.db import get_db
    from sqlalchemy import select

    org_id, headers = register(client, "activate-ready@example.com", "Activation Ready Co")
    # Add a second active member and the first inquiry/workflow as persisted setup evidence.
    db_gen = client.app.dependency_overrides[get_db]()
    db = next(db_gen)
    try:
        owner_membership = db.scalar(select(Membership).where(Membership.organization_id == org_id))
        org = db.get(Organization, org_id)
        org.industry = "Services"
        org.country_code = "KE"
        second_user = User(email="pilot-second-member@example.com", password_hash="test-hash", full_name="Pilot Operator")
        db.add(second_user)
        db.flush()
        db.add(Membership(organization_id=org_id, user_id=second_user.id, role="operator"))
        db.add(Inquiry(organization_id=org_id, source="manual", message="Pilot test inquiry", status="new"))
        db.add(Workflow(organization_id=org_id, name="Pilot response workflow", description="Human reviewed draft", trigger_type="manual", action_type="draft_response", config={"human_approval_required": True}))
        db.commit()
    finally:
        try: next(db_gen)
        except StopIteration: pass
    response = client.post("/v1/pilot/activate", headers=headers)
    assert response.status_code == 200, response.text
    assert response.json()["status"] == "active"
    audit = client.get("/v1/audit", headers=headers).json()
    assert any(item["action"] == "pilot.activated" for item in audit)
