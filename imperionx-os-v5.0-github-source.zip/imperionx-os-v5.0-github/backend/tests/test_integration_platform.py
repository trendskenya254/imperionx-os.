import hashlib
import hmac
from test_inquiries import register


def test_scoped_integration_key_and_revocation_are_tenant_safe(client):
    org_id, owner = register(client, "integrations-a@example.com", "Integrations A")
    other_id, other = register(client, "integrations-b@example.com", "Integrations B")
    created = client.post("/v1/integrations/credentials", headers=owner, json={
        "name": "Read-only network sync", "scopes": ["network:read"], "expires_in_days": 30
    })
    assert created.status_code == 201, created.text
    body = created.json()
    key = body["api_key"]
    assert key.startswith("ixx_live_")
    assert "api_key" not in client.get("/v1/integrations/credentials", headers=owner).json()[0]

    access = client.get("/v1/integrations/network/overview", headers={"X-API-Key": key})
    assert access.status_code == 200, access.text
    assert access.json()["organization_id"] == org_id
    assert access.json()["api_version"] == "5.0.0"
    assert client.get("/v1/integrations/credentials", headers=owner).json()[0]["last_used_at"] is not None
    assert client.get("/v1/integrations/commerce/summary", headers={"X-API-Key": key}).status_code == 403
    commerce_key = client.post("/v1/integrations/credentials", headers=owner, json={"name": "Commerce sync", "scopes": ["commerce:read"]}).json()["api_key"]
    commerce = client.get("/v1/integrations/commerce/summary", headers={"X-API-Key": commerce_key})
    assert commerce.status_code == 200 and commerce.json()["funds_held_by_platform"] is False

    denied_scope = client.get("/v1/integrations/network/overview", headers={"X-API-Key": "bad"})
    assert denied_scope.status_code == 401
    foreign_revoke = client.post(f"/v1/integrations/credentials/{body['id']}/revoke", headers=other)
    assert foreign_revoke.status_code == 404
    revoked = client.post(f"/v1/integrations/credentials/{body['id']}/revoke", headers=owner)
    assert revoked.status_code == 200
    denied_after_revoke = client.get("/v1/integrations/network/overview", headers={"X-API-Key": key})
    assert denied_after_revoke.status_code == 401


def test_integration_credentials_validate_scopes_and_expiry(client):
    _, owner = register(client, "integrations-validation@example.com", "Integrations Validation")
    assert client.post("/v1/integrations/credentials", headers=owner, json={
        "name": "Bad scope", "scopes": ["admin:all"]
    }).status_code == 400
    assert client.post("/v1/integrations/credentials", headers=owner, json={
        "name": "Too long", "scopes": ["network:read"], "expires_in_days": 366
    }).status_code == 400


def test_webhook_queue_signing_idempotency_and_tenant_isolation(client):
    org_id, owner = register(client, "webhook-a@example.com", "Webhook A")
    other_id, other = register(client, "webhook-b@example.com", "Webhook B")
    created = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Commerce listener", "endpoint_url": "https://hooks.example.com/imperionx",
        "events": ["commerce.transaction.updated"]
    })
    assert created.status_code == 201, created.text
    body = created.json()
    assert body["signing_secret"]
    assert "signing_secret" not in client.get("/v1/integrations/webhooks", headers=owner).json()[0]

    bad_url = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Internal", "endpoint_url": "https://127.0.0.1/hook", "events": ["commerce.transaction.updated"]
    })
    assert bad_url.status_code == 400

    event = {"event_type": "commerce.transaction.updated", "idempotency_key": "test-evt-001"}
    queued = client.post(f"/v1/integrations/webhooks/{body['id']}/test-event", headers=owner, json=event)
    assert queued.status_code == 202, queued.text
    assert queued.json()["status"] == "queued"
    assert queued.json()["delivery_enabled"] is False
    assert queued.json()["signature"].startswith("sha256=")
    duplicate = client.post(f"/v1/integrations/webhooks/{body['id']}/test-event", headers=owner, json=event)
    assert duplicate.status_code == 202 and duplicate.json()["duplicate"] is True
    assert duplicate.json()["id"] == queued.json()["id"]

    deliveries = client.get("/v1/integrations/webhooks/deliveries", headers=owner).json()
    assert len(deliveries) == 1 and deliveries[0]["attempts"] == 0
    assert client.get("/v1/integrations/webhooks/deliveries", headers=other).json() == []
    assert client.post(f"/v1/integrations/webhooks/{body['id']}/test-event", headers=owner,
                       json={"event_type": "unknown.event"}).status_code == 400

    revoked = client.post(f"/v1/integrations/webhooks/{body['id']}/revoke", headers=owner)
    assert revoked.status_code == 200
    after = client.post(f"/v1/integrations/webhooks/{body['id']}/test-event", headers=owner, json=event)
    assert after.status_code == 404


def test_domain_events_fan_out_to_both_tenants_atomically(client):
    from test_business_network import _setup_pair
    source_id, source, target_id, target, connection_id = _setup_pair(client)
    for headers, email in ((source, "source-hook@example.com"), (target, "target-hook@example.com")):
        created = client.post("/v1/integrations/webhooks", headers=headers, json={
            "name": "Connection events", "endpoint_url": "https://hooks.example.com/events",
            "events": ["network.connection.accepted"]
        })
        assert created.status_code == 201, created.text
    accepted = client.post(f"/v1/business/connections/{connection_id}/decision", headers=target,
                           json={"decision": "accepted", "shared_fields": []})
    assert accepted.status_code == 200
    source_events = client.get("/v1/integrations/webhooks/deliveries", headers=source).json()
    target_events = client.get("/v1/integrations/webhooks/deliveries", headers=target).json()
    assert len(source_events) == len(target_events) == 1
    assert source_events[0]["event_type"] == target_events[0]["event_type"] == "network.connection.accepted"
    assert source_events[0]["status"] == target_events[0]["status"] == "queued"
    assert source_events[0]["id"] != target_events[0]["id"]


def test_webhook_dead_letter_replay_is_tenant_scoped_and_requires_active_subscription(client):
    _, owner = register(client, "webhook-replay-a@example.com", "Webhook Replay A")
    _, other = register(client, "webhook-replay-b@example.com", "Webhook Replay B")
    created = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Replay hook", "endpoint_url": "https://hooks.example.com/replay",
        "events": ["commerce.transaction.updated"]
    }).json()
    queued = client.post(f"/v1/integrations/webhooks/{created['id']}/test-event", headers=owner,
                         json={"event_type": "commerce.transaction.updated", "idempotency_key": "replay-1"}).json()
    from app.db import get_db
    from app.models import WebhookDelivery
    from app.main import app
    db_gen = app.dependency_overrides[get_db]()
    db = next(db_gen)
    try:
        row = db.get(WebhookDelivery, queued["id"])
        row.status = "dead_lettered"
        row.dead_lettered_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
        row.attempts = 8
        db.commit()
    finally:
        db_gen.close()
    path = f"/v1/integrations/webhooks/deliveries/{queued['id']}/replay"
    assert client.post(path, headers=other).status_code == 404
    replayed = client.post(path, headers=owner)
    assert replayed.status_code == 202 and replayed.json()["status"] == "queued"
    assert client.post(path, headers=owner).status_code == 409


def test_webhook_transport_rejects_private_and_mixed_dns_answers():
    import socket
    from app.webhook_delivery import resolve_public_target, UnsafeWebhookTarget
    public = (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("8.8.8.8", 443))
    private = (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443))
    assert resolve_public_target("https://hooks.example.com/a", resolver=lambda *a, **k: [public])[3] == ["8.8.8.8"]
    import pytest
    with pytest.raises(UnsafeWebhookTarget):
        resolve_public_target("https://hooks.example.com/a", resolver=lambda *a, **k: [public, private])
    with pytest.raises(UnsafeWebhookTarget):
        resolve_public_target("http://hooks.example.com/a")
    with pytest.raises(UnsafeWebhookTarget):
        resolve_public_target("https://127.0.0.1/a")


def test_webhook_worker_success_retry_and_signature_verification(client, monkeypatch):
    from app.db import get_db
    from app.main import app
    from app.models import WebhookDelivery
    from app.webhook_delivery import deliver_one
    _, owner = register(client, "webhook-worker@example.com", "Webhook Worker")
    created = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Worker hook", "endpoint_url": "https://hooks.example.com/worker",
        "events": ["commerce.transaction.updated"]
    }).json()
    queued = client.post(f"/v1/integrations/webhooks/{created['id']}/test-event", headers=owner,
                         json={"event_type": "commerce.transaction.updated", "idempotency_key": "worker-1"}).json()
    calls = []
    def ok_sender(url, body, headers):
        calls.append((url, body, headers))
        return 204, 0
    db_gen = app.dependency_overrides[get_db]()
    db = next(db_gen)
    try:
        assert deliver_one(db=db, sender=ok_sender) is True
        row = db.get(WebhookDelivery, queued["id"])
        assert row.status == "delivered" and row.attempts == 1 and row.response_status == 204
        assert calls[0][2]["X-ImperionX-Signature"].startswith("sha256=")
    finally:
        db_gen.close()


def test_webhook_worker_retries_non_2xx_without_following_redirects(client):
    from app.db import get_db
    from app.main import app
    from app.models import WebhookDelivery
    from app.webhook_delivery import deliver_one
    _, owner = register(client, "webhook-retry@example.com", "Webhook Retry")
    created = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Retry hook", "endpoint_url": "https://hooks.example.com/retry",
        "events": ["commerce.transaction.updated"]
    }).json()
    queued = client.post(f"/v1/integrations/webhooks/{created['id']}/test-event", headers=owner,
                         json={"event_type": "commerce.transaction.updated", "idempotency_key": "retry-1"}).json()
    db_gen = app.dependency_overrides[get_db]()
    db = next(db_gen)
    try:
        assert deliver_one(db=db, sender=lambda *a, **k: (503, 0)) is True
        row = db.get(WebhookDelivery, queued["id"])
        assert row.status == "retry" and row.attempts == 1
        assert row.response_status == 503 and row.next_attempt_at is not None
    finally:
        db_gen.close()


def test_webhook_attempt_history_metrics_and_tenant_isolation(client):
    from app.db import get_db
    from app.main import app
    from app.models import WebhookDelivery, WebhookWorkerHeartbeat
    from app.webhook_delivery import deliver_one, WORKER_ID
    org_id, owner = register(client, "webhook-observe-a@example.com", "Webhook Observe A")
    _, other = register(client, "webhook-observe-b@example.com", "Webhook Observe B")
    sub = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Observe hook", "endpoint_url": "https://hooks.example.com/observe",
        "events": ["commerce.transaction.updated"]
    }).json()
    queued = client.post(f"/v1/integrations/webhooks/{sub['id']}/test-event", headers=owner, json={
        "event_type": "commerce.transaction.updated", "idempotency_key": "observe-1"
    }).json()
    db_gen = app.dependency_overrides[get_db]()
    db = next(db_gen)
    try:
        assert deliver_one(db=db, sender=lambda *a, **k: (503, 0)) is True
        row = db.get(WebhookDelivery, queued["id"])
        assert row.status == "retry"
        heartbeat = db.get(WebhookWorkerHeartbeat, WORKER_ID)
        assert heartbeat is not None and heartbeat.processed_count >= 1
    finally:
        db_gen.close()
    history = client.get(f"/v1/integrations/webhooks/deliveries/{queued['id']}/attempts", headers=owner)
    assert history.status_code == 200
    assert len(history.json()) == 1
    assert history.json()[0]["outcome"] == "retry"
    assert history.json()[0]["response_status"] == 503
    assert history.json()[0]["duration_ms"] >= 0
    assert client.get(f"/v1/integrations/webhooks/deliveries/{queued['id']}/attempts", headers=other).status_code == 404
    metrics = client.get("/v1/integrations/webhooks/metrics", headers=owner)
    assert metrics.status_code == 200
    assert metrics.json()["organization_id"] == org_id
    assert metrics.json()["queue"]["retry"] == 1
    assert metrics.json()["last_24h"]["attempts"] == 1
    assert metrics.json()["worker_presence"] == "active"
    assert client.get("/v1/integrations/webhooks/metrics", headers=other).json()["last_24h"]["attempts"] == 0


def test_webhook_worker_dead_letters_tampered_signature_without_network_call(client):
    from app.db import get_db
    from app.main import app
    from app.models import WebhookDelivery, WebhookDeliveryAttempt
    from app.webhook_delivery import deliver_one
    _, owner = register(client, "webhook-tamper@example.com", "Webhook Tamper")
    sub = client.post("/v1/integrations/webhooks", headers=owner, json={
        "name": "Tamper hook", "endpoint_url": "https://hooks.example.com/tamper",
        "events": ["commerce.transaction.updated"]
    }).json()
    queued = client.post(f"/v1/integrations/webhooks/{sub['id']}/test-event", headers=owner, json={
        "event_type": "commerce.transaction.updated", "idempotency_key": "tamper-1"
    }).json()
    db_gen = app.dependency_overrides[get_db]()
    db = next(db_gen)
    calls = []
    try:
        row = db.get(WebhookDelivery, queued["id"])
        row.signature = "sha256=" + ("0" * 64)
        db.commit()
        assert deliver_one(db=db, sender=lambda *a, **k: calls.append(a)) is True
        db.refresh(row)
        attempt = db.scalar(__import__("sqlalchemy").select(WebhookDeliveryAttempt).where(
            WebhookDeliveryAttempt.delivery_id == row.id))
        assert row.status == "dead_lettered"
        assert row.last_error == "stored_signature_invalid"
        assert attempt is not None and attempt.outcome == "dead_lettered"
        assert attempt.error_code == "stored_signature_invalid"
        assert calls == []
    finally:
        db_gen.close()
