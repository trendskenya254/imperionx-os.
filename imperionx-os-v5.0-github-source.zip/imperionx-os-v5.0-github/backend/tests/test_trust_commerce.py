import os
from test_inquiries import register
from test_business_network import _setup_pair


def test_verification_requires_allowlisted_platform_reviewer(client, monkeypatch):
    org_id, owner = register(client, "verify-owner@example.com", "Verify Co")
    submitted = client.post("/v1/business/verification", headers=owner, json={
        "evidence_type": "Business registration certificate",
        "evidence_reference": "https://evidence.example/registration/123",
        "note": "Submitted for manual review"
    })
    assert submitted.status_code == 201, submitted.text
    assert client.get("/v1/business/verification", headers=owner).json()["status"] == "pending"
    reviewer_id, reviewer_headers = register(client, "platform-reviewer@example.com", "Platform Operations")
    reviewer_user_id = client.get("/v1/auth/me", headers=reviewer_headers).json()["id"]
    monkeypatch.setenv("IMPERIONX_PLATFORM_REVIEWER_USER_IDS", reviewer_user_id)
    queue = client.get("/v1/platform/verifications", headers=reviewer_headers)
    assert queue.status_code == 200 and queue.json()[0]["organization_id"] == org_id
    decision = client.post(f"/v1/platform/verifications/{org_id}/decision", headers=reviewer_headers,
                           json={"decision": "verified", "note": "Evidence reviewed by platform operator"})
    assert decision.status_code == 200 and decision.json()["status"] == "verified"
    repeated = client.post(f"/v1/platform/verifications/{org_id}/decision", headers=reviewer_headers,
                           json={"decision": "rejected"})
    assert repeated.status_code == 404


def test_verification_reviewer_is_deny_by_default(client):
    org_id, owner = register(client, "verify-deny@example.com", "Verify Deny Co")
    submitted = client.post("/v1/business/verification", headers=owner, json={"evidence_type": "Registration certificate"})
    assert submitted.status_code == 201
    assert client.get("/v1/platform/verifications", headers=owner).status_code == 403


def test_connected_business_quote_and_transaction_lifecycle(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    accepted = client.post(f"/v1/business/connections/{connection_id}/decision", headers=supplier,
                           json={"decision": "accepted", "shared_fields": []})
    assert accepted.status_code == 200
    request = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Solar panel supply", "description": "Supply 20 commercial solar panels", "quantity": "20 units"
    })
    assert request.status_code == 201, request.text
    request_id = request.json()["id"]
    quote = client.post(f"/v1/business/purchase-requests/{request_id}/quotes", headers=supplier, json={
        "amount_minor": 25000000, "currency": "KES", "terms": "Delivery within 14 days", "validity_days": 14
    })
    assert quote.status_code == 201, quote.text
    assert client.get("/v1/business/quotes", headers=buyer).json()[0]["id"] == quote.json()["id"]
    transaction = client.post(f"/v1/business/quotes/{quote.json()['id']}/accept", headers=buyer)
    assert transaction.status_code == 201, transaction.text
    tx_id = transaction.json()["id"]
    assert transaction.json()["funds_held_by_imperionx"] is False
    buyer_start = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "in_progress"})
    assert buyer_start.status_code == 403
    supplier_start = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=supplier, json={"status": "in_progress"})
    assert supplier_start.status_code == 200
    buyer_complete = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"})
    assert buyer_complete.status_code == 200
    closed = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=supplier, json={"status": "cancelled"})
    assert closed.status_code == 409
    outsider_id, outsider = register(client, "commerce-outsider@example.com", "Commerce Outsider")
    assert client.get("/v1/business/transactions", headers=outsider).json() == []


def test_purchase_request_requires_accepted_connection(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    denied = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Equipment", "description": "Please quote for equipment"
    })
    assert denied.status_code == 404


def _make_transaction(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    accepted = client.post(f"/v1/business/connections/{connection_id}/decision", headers=supplier,
                           json={"decision": "accepted", "shared_fields": []})
    assert accepted.status_code == 200
    request = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Equipment supply", "description": "Supply industrial equipment", "quantity": "4 units"
    })
    assert request.status_code == 201
    quote = client.post(f"/v1/business/purchase-requests/{request.json()['id']}/quotes", headers=supplier,
                        json={"amount_minor": 125000, "currency": "KES", "validity_days": 10})
    assert quote.status_code == 201
    transaction = client.post(f"/v1/business/quotes/{quote.json()['id']}/accept", headers=buyer)
    assert transaction.status_code == 201
    tx_id = transaction.json()["id"]
    started = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=supplier, json={"status": "in_progress"})
    assert started.status_code == 200
    return buyer_id, buyer, supplier_id, supplier, tx_id


def test_fulfillment_milestones_are_supplier_only_and_ordered(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    first = client.post(f"/v1/business/transactions/{tx_id}/fulfillment", headers=supplier,
                        json={"milestone": "prepared", "note": "Items packed"})
    assert first.status_code == 201
    skipped = client.post(f"/v1/business/transactions/{tx_id}/fulfillment", headers=supplier,
                          json={"milestone": "delivered"})
    assert skipped.status_code == 409
    buyer_write = client.post(f"/v1/business/transactions/{tx_id}/fulfillment", headers=buyer,
                               json={"milestone": "dispatched"})
    assert buyer_write.status_code == 404
    dispatched = client.post(f"/v1/business/transactions/{tx_id}/fulfillment", headers=supplier,
                             json={"milestone": "dispatched", "tracking_reference": "SHIP-001"})
    assert dispatched.status_code == 201
    history = client.get(f"/v1/business/transactions/{tx_id}/fulfillment", headers=buyer)
    assert [x["milestone"] for x in history.json()] == ["prepared", "dispatched"]


def test_dispute_opening_is_participant_scoped_and_single_open_dispute(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    opened = client.post(f"/v1/business/transactions/{tx_id}/disputes", headers=buyer,
                         json={"category": "delivery", "description": "The delivery date has passed and goods have not arrived."})
    assert opened.status_code == 201
    duplicate = client.post(f"/v1/business/transactions/{tx_id}/disputes", headers=supplier,
                            json={"category": "other", "description": "A second dispute should not be allowed."})
    assert duplicate.status_code == 409
    assert len(client.get("/v1/business/disputes", headers=supplier).json()) == 1
    outsider_id, outsider = register(client, "dispute-outsider@example.com", "Dispute Outsider")
    assert client.get("/v1/business/disputes", headers=outsider).json() == []
    hidden = client.post(f"/v1/business/transactions/{tx_id}/disputes", headers=outsider,
                         json={"category": "other", "description": "Trying to access another company's transaction."})
    assert hidden.status_code == 404


def test_platform_dispute_review_is_deny_by_default(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    opened = client.post(f"/v1/business/transactions/{tx_id}/disputes", headers=buyer,
                         json={"category": "quality", "description": "The supplied goods do not meet the agreed specification."})
    assert opened.status_code == 201
    assert client.get("/v1/platform/disputes", headers=buyer).status_code == 403


def test_commerce_insights_group_currencies_without_conversion(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    buyer_metrics = client.get("/v1/business/commerce/insights?days=90", headers=buyer)
    supplier_metrics = client.get("/v1/business/commerce/insights?days=90", headers=supplier)
    assert buyer_metrics.status_code == 200
    assert buyer_metrics.json()["buyer"]["purchase_count"] == 1
    assert buyer_metrics.json()["transactions_by_currency"][0]["currency"] == "KES"
    assert supplier_metrics.json()["supplier"]["awarded_orders"] == 1
    assert supplier_metrics.json()["supplier"]["completion_rate_percent"] == 0
    assert "No foreign-exchange conversion" in buyer_metrics.json()["currency_note"]
    assert client.get("/v1/business/commerce/insights?days=500", headers=buyer).status_code == 400


def test_open_dispute_prevents_transaction_closure(client):
    buyer_id, buyer, supplier_id, supplier, tx_id = _make_transaction(client)
    opened = client.post(f"/v1/business/transactions/{tx_id}/disputes", headers=buyer,
                         json={"category": "quality", "description": "The product quality does not match the agreed specification."})
    assert opened.status_code == 201
    closed = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=buyer, json={"status": "completed"})
    cancelled = client.patch(f"/v1/business/transactions/{tx_id}/status", headers=supplier, json={"status": "cancelled"})
    assert closed.status_code == 409
    assert cancelled.status_code == 409


def test_quote_withdrawal_and_buyer_rejection_are_role_scoped(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    assert client.post(f"/v1/business/connections/{connection_id}/decision", headers=supplier,
                       json={"decision": "accepted", "shared_fields": []}).status_code == 200
    request = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Office furniture", "description": "Supply desks and chairs"
    })
    request_id = request.json()["id"]
    quote = client.post(f"/v1/business/purchase-requests/{request_id}/quotes", headers=supplier,
                        json={"amount_minor": 450000, "currency": "KES"})
    quote_id = quote.json()["id"]
    wrong_role = client.post(f"/v1/business/quotes/{quote_id}/decision", headers=buyer,
                             json={"decision": "withdraw"})
    assert wrong_role.status_code == 404
    withdrawn = client.post(f"/v1/business/quotes/{quote_id}/decision", headers=supplier,
                            json={"decision": "withdraw"})
    assert withdrawn.status_code == 200 and withdrawn.json()["status"] == "withdrawn"


def test_buyer_can_reject_quote_and_close_open_request(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    assert client.post(f"/v1/business/connections/{connection_id}/decision", headers=supplier,
                       json={"decision": "accepted", "shared_fields": []}).status_code == 200
    request = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Packaging materials", "description": "Supply recyclable cartons"
    })
    request_id = request.json()["id"]
    quote = client.post(f"/v1/business/purchase-requests/{request_id}/quotes", headers=supplier,
                        json={"amount_minor": 125000, "currency": "KES"})
    quote_id = quote.json()["id"]
    rejected = client.post(f"/v1/business/quotes/{quote_id}/decision", headers=buyer,
                           json={"decision": "reject"})
    assert rejected.status_code == 200 and rejected.json()["status"] == "rejected"
    closed = client.post(f"/v1/business/purchase-requests/{request_id}/close", headers=buyer)
    assert closed.status_code == 200 and closed.json()["status"] == "cancelled"
    assert client.post(f"/v1/business/purchase-requests/{request_id}/close", headers=buyer).status_code == 409


def test_supplier_cannot_close_buyers_purchase_request(client):
    buyer_id, buyer, supplier_id, supplier, connection_id = _setup_pair(client)
    assert client.post(f"/v1/business/connections/{connection_id}/decision", headers=supplier,
                       json={"decision": "accepted", "shared_fields": []}).status_code == 200
    request = client.post("/v1/business/purchase-requests", headers=buyer, json={
        "connection_id": connection_id, "title": "Industrial valves", "description": "Supply industrial valves"
    })
    denied = client.post(f"/v1/business/purchase-requests/{request.json()['id']}/close", headers=supplier)
    assert denied.status_code == 404
